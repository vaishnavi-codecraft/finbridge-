<?php
// Admin creates accounts for tutors, mentors, students or other admins.
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');
$pageTitle = 'Add user';
$activeNav = 'user_create';

$roles = [];   // id => label
$rr = db()->query('SELECT id, label FROM roles ORDER BY id');
while ($r = $rr->fetch_assoc()) {
    $roles[(int) $r['id']] = $r['label'];
}

$errors = [];
$old = ['full_name' => '', 'email' => '', 'phone' => '', 'role_id' => 2];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $errors[] = 'Your session expired. Please try again.';
    } else {
        $old['full_name'] = trim($_POST['full_name'] ?? '');
        $old['email']     = strtolower(trim($_POST['email'] ?? ''));
        $old['phone']     = preg_replace('/\D/', '', $_POST['phone'] ?? '');
        $old['role_id']   = (int) ($_POST['role_id'] ?? 0);
        $password         = $_POST['password'] ?? '';

        if (strlen($old['full_name']) < 2 || strlen($old['full_name']) > 100) {
            $errors[] = 'Enter the full name (2 to 100 characters).';
        }
        if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Enter a valid email address.';
        }
        if (strlen($old['phone']) < 10 || strlen($old['phone']) > 15) {
            $errors[] = 'Enter a phone number with 10 to 15 digits.';
        }
        if (!isset($roles[$old['role_id']])) {
            $errors[] = 'Choose a role.';
        }
        if (strlen($password) < 8) {
            $errors[] = 'The password must be at least 8 characters.';
        }

        if (!$errors) {
            $duplicate = 'An account with this email or phone number already exists.';
            $check = db()->prepare('SELECT id FROM users WHERE email = ? OR phone = ? LIMIT 1');
            $check->bind_param('ss', $old['email'], $old['phone']);
            $check->execute();
            $check->store_result();
            $exists = $check->num_rows > 0;
            $check->close();

            if ($exists) {
                $errors[] = $duplicate;
            } else {
                try {
                    $hash = password_hash($password, PASSWORD_DEFAULT);
                    $ins = db()->prepare('INSERT INTO users (role_id, full_name, email, phone, password_hash) VALUES (?, ?, ?, ?, ?)');
                    $ins->bind_param('issss', $old['role_id'], $old['full_name'], $old['email'], $old['phone'], $hash);
                    $ins->execute();
                    $ins->close();
                    flash_set($old['full_name'] . ' was added as ' . $roles[$old['role_id']] . '.');
                    redirect('admin/users.php');
                } catch (mysqli_sql_exception $ex) {
                    $errors[] = $ex->getCode() === 1062 ? $duplicate : 'Something went wrong. Please try again.';
                }
            }
        }
    }
}

include __DIR__ . '/../includes/layout_top.php';
?>
<section class="panel narrow-panel">
    <div class="panel-head"><h3>New user</h3></div>
    <?php if ($errors): ?>
        <div class="alert error">
            <?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?>
        </div>
    <?php endif; ?>
    <form method="post" novalidate>
        <?= csrf_field() ?>
        <label for="full_name">Full name</label>
        <input id="full_name" name="full_name" type="text" value="<?= e($old['full_name']) ?>" required>

        <label for="email">Email</label>
        <input id="email" name="email" type="email" value="<?= e($old['email']) ?>" required>

        <label for="phone">Phone number</label>
        <input id="phone" name="phone" type="tel" value="<?= e($old['phone']) ?>" required>

        <label for="role_id">Role</label>
        <select id="role_id" name="role_id" required>
            <?php foreach ($roles as $id => $label): ?>
                <option value="<?= $id ?>"<?= $old['role_id'] === $id ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>

        <label for="password">Temporary password (at least 8 characters)</label>
        <div class="pw-field">
            <input id="password" name="password" type="password" autocomplete="new-password" required>
            <button type="button" class="pw-toggle" data-target="password" aria-label="Show password">Show</button>
        </div>

        <button type="submit" class="btn btn-primary" data-loading="Saving...">Create user</button>
    </form>
</section>
<?php include __DIR__ . '/../includes/layout_bottom.php'; ?>
