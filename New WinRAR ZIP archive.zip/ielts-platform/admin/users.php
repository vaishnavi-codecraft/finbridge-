<?php
// List of everyone with an account. Admin can filter by role and block or unblock people.
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');
$pageTitle = 'Users';
$activeNav = 'users';

$roles = [];
$rr = db()->query('SELECT name, label FROM roles ORDER BY id');
while ($r = $rr->fetch_assoc()) {
    $roles[$r['name']] = $r['label'];
}
$filter = $_GET['role'] ?? '';
if (!isset($roles[$filter])) {
    $filter = '';
}

$sql = 'SELECT u.id, u.full_name, u.email, u.phone, u.status, u.created_at, r.label AS role_label
        FROM users u JOIN roles r ON r.id = u.role_id';
if ($filter !== '') {
    $stmt = db()->prepare($sql . ' WHERE r.name = ? ORDER BY u.id DESC');
    $stmt->bind_param('s', $filter);
} else {
    $stmt = db()->prepare($sql . ' ORDER BY u.id DESC');
}
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$myId = current_user()['id'];

include __DIR__ . '/../includes/layout_top.php';
?>
<section class="panel">
    <div class="panel-head">
        <h3>All users (<?= count($users) ?>)</h3>
        <a class="btn btn-small btn-primary" href="<?= e(url('admin/user_create.php')) ?>">Add user</a>
    </div>

    <div class="filters">
        <a class="chip<?= $filter === '' ? ' on' : '' ?>" href="<?= e(url('admin/users.php')) ?>">Everyone</a>
        <?php foreach ($roles as $name => $label): ?>
            <a class="chip<?= $filter === $name ? ' on' : '' ?>" href="<?= e(url('admin/users.php?role=' . $name)) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </div>

    <div class="table-wrap">
        <table>
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Joined</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= e($u['full_name']) ?></td>
                    <td><?= e($u['email']) ?></td>
                    <td><?= e($u['phone']) ?></td>
                    <td><span class="badge"><?= e($u['role_label']) ?></span></td>
                    <td><span class="badge <?= $u['status'] === 'active' ? 'badge-ok' : 'badge-err' ?>"><?= e(ucfirst($u['status'])) ?></span></td>
                    <td><?= e(date('d M Y', strtotime($u['created_at']))) ?></td>
                    <td>
                        <?php if ((int) $u['id'] === $myId): ?>
                            <small class="muted">You</small>
                        <?php else: ?>
                            <form method="post" action="<?= e(url('admin/user_status.php')) ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                                <input type="hidden" name="action" value="<?= $u['status'] === 'active' ? 'block' : 'unblock' ?>">
                                <button type="submit" class="btn btn-small btn-ghost"><?= $u['status'] === 'active' ? 'Block' : 'Unblock' ?></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$users): ?><tr><td colspan="7" class="muted">No users found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php include __DIR__ . '/../includes/layout_bottom.php'; ?>
