<?php
// Blocks or unblocks one user. Only the admin can do this, and never on their own account.
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valid()) {
    $id     = (int) ($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($id > 0 && $id !== current_user()['id'] && in_array($action, ['block', 'unblock'], true)) {
        $status = $action === 'block' ? 'blocked' : 'active';
        $stmt = db()->prepare('UPDATE users SET status = ? WHERE id = ?');
        $stmt->bind_param('si', $status, $id);
        $stmt->execute();
        $stmt->close();
        flash_set($action === 'block' ? 'User blocked.' : 'User unblocked.');
    }
}
redirect('admin/users.php');
