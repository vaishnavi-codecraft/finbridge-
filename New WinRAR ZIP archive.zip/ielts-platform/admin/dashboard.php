<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');
$pageTitle = 'Dashboard';
$activeNav = 'dashboard';

// Real numbers from the database: how many people hold each role
$counts = [];
$res = db()->query('SELECT r.name, COUNT(u.id) AS total FROM roles r LEFT JOIN users u ON u.role_id = r.id GROUP BY r.id, r.name');
while ($row = $res->fetch_assoc()) {
    $counts[$row['name']] = (int) $row['total'];
}
$cards = ['student' => 'Students', 'tutor' => 'Tutors', 'mentor' => 'Mentors', 'admin' => 'Admins'];

$recent = db()->query(
    'SELECT u.full_name, u.email, u.created_at, r.label
     FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.id DESC LIMIT 5'
)->fetch_all(MYSQLI_ASSOC);

include __DIR__ . '/../includes/layout_top.php';
?>
<section class="welcome">
    <h2>Welcome, <?= e(current_user()['name']) ?></h2>
    <p>Here is a quick look at the people on <?= e(APP_NAME) ?>.</p>
</section>

<section class="stats">
    <?php foreach ($cards as $name => $label): ?>
        <div class="stat">
            <span class="stat-num" data-count="<?= (int) ($counts[$name] ?? 0) ?>"><?= (int) ($counts[$name] ?? 0) ?></span>
            <span class="stat-label"><?= e($label) ?></span>
        </div>
    <?php endforeach; ?>
</section>

<section class="panel">
    <div class="panel-head">
        <h3>Newest accounts</h3>
        <a class="btn btn-small btn-ghost" href="<?= e(url('admin/users.php')) ?>">View all users</a>
    </div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
            <tbody>
            <?php foreach ($recent as $r): ?>
                <tr>
                    <td><?= e($r['full_name']) ?></td>
                    <td><?= e($r['email']) ?></td>
                    <td><span class="badge"><?= e($r['label']) ?></span></td>
                    <td><?= e(date('d M Y', strtotime($r['created_at']))) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="panel">
    <div class="panel-head"><h3>Quick actions</h3></div>
    <a class="btn btn-primary btn-inline" href="<?= e(url('admin/user_create.php')) ?>">Add a tutor or mentor</a>
</section>
<?php include __DIR__ . '/../includes/layout_bottom.php'; ?>
