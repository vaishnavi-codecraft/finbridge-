-- SkyPrep Part 2 database. Import this file in phpMyAdmin (Import tab).
CREATE DATABASE IF NOT EXISTS ielts_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ielts_platform;

-- Every person has one role.
CREATE TABLE IF NOT EXISTS roles (
    id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name  VARCHAR(40) NOT NULL UNIQUE,    -- used by code, e.g. student
    label VARCHAR(60) NOT NULL            -- shown on screen, e.g. Student
) ENGINE=InnoDB;

-- Everyone who can log in (students, tutors, mentors, admin).
-- UNIQUE email and phone mean the same student can never be saved twice.
CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_id       INT UNSIGNED NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    phone         VARCHAR(20)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    status        ENUM('active','blocked') NOT NULL DEFAULT 'active',
    last_login_at DATETIME NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id)
) ENGINE=InnoDB;

INSERT IGNORE INTO roles (id, name, label) VALUES
    (1, 'admin',   'Admin'),
    (2, 'tutor',   'Tutor'),
    (3, 'student', 'Student'),
    (4, 'mentor',  'Mentor');
