<?php
// Sends each person to the dashboard of their own role.
require_once __DIR__ . '/includes/auth.php';
require_login();
redirect(dashboard_path(current_user()['role']));
