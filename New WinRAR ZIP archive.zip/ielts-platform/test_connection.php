<?php
// Part 1 check (still available): open localhost/ielts-platform/test_connection.php
require_once __DIR__ . '/config/database.php';
$tables = [];
$result = $conn->query('SHOW TABLES');
while ($row = $result->fetch_row()) {
    $tables[] = $row[0];
}
echo '<h2 style="color:green">Database connected successfully!</h2>';
echo '<p>Tables found: ' . htmlspecialchars($tables ? implode(', ', $tables) : 'none yet') . '</p>';
