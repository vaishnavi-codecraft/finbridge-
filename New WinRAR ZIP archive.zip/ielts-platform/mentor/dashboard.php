<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('mentor');
$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
include __DIR__ . '/../includes/layout_top.php';
?>
<section class="welcome">
    <h2>Welcome, <?= e(current_user()['name']) ?></h2>
    <p>The students you guide will appear here.</p>
</section>
<section class="card-grid">
    <?= empty_card('My students', 'No students are assigned to you yet. They appear here after the admin allocates them.', 'Part 4') ?>
    <?= empty_card('Student progress', 'Test scores and attendance for each of your students will show here.', 'Part 8') ?>
</section>
<?php include __DIR__ . '/../includes/layout_bottom.php'; ?>
