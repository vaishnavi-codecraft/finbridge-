SHADOW GROUP(S) - IELTS & OET learning platform

WHAT'S NEW
- index.php is now the public homepage (carousel, programmes, skills, resources, footer).
  Visitors see it first; the Login / Join buttons go to auth/login.php and auth/register.php.
  If you are already logged in, the Login button becomes "Dashboard".
- The public homepage is branded for SHADOW GROUP(S), with IELTS and OET programme pathways. It uses assets/css/home.css and assets/js/home.js. The supplied brand logo is stored in assets/images/shadow-groups-logo.png.
  The application screens still use assets/css/style.css and assets/js/app.js (unchanged).
- test_connection.php was removed (it was public and held database credentials).

INSTALL
1. Copy this "ielts-platform" folder over your existing one in C:\xampp\htdocs\ (choose Replace).
   No database change is needed. If create_admin.php is still in the folder, delete it.
2. Start Apache and MySQL.
3. Open http://localhost/ielts-platform/ (homepage) and http://localhost/ielts-platform/auth/login.php

NOTES
- The homepage loads Google Fonts and Unsplash photos, so it needs an internet connection.
- The homepage works without the database. It is an independent preparation site and does not use IDP's logo or imply affiliation.

TEST
- Homepage opens, the banner slides change, and the menu works on a narrow window.
- Login button -> login page. Join now -> Create account page.
- Log in as admin -> Admin dashboard; go back to the homepage -> button says "Dashboard".
