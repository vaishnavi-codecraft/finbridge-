<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('student');
$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
include __DIR__ . '/../includes/layout_top.php';
?>
<section class="welcome">
    <h2>Welcome, <?= e(current_user()['name']) ?></h2>
    <p>Your course, tests and results will appear here.</p>
</section>
<section class="card-grid">
    <?= empty_card('My course and batch', 'You are not in a batch yet. Your course appears here after the institute enrols you.', 'Part 4') ?>
    <?= empty_card('Mock tests', 'Timed Listening, Reading, Writing and Speaking tests will be listed here.', 'Part 6') ?>
    <?= empty_card('My results', 'Your band scores and tutor feedback will show here after each test.', 'Part 6') ?>
</section>
<?php include __DIR__ . '/../includes/layout_bottom.php'; ?>
