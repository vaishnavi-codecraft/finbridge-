<?php
// Small pieces used to build screens: menu per role, message box, empty cards.

// Left menu for each role. [label, page, key]. A page of null means "coming in a later part".
function nav_items(string $role): array
{
    $home = ['Dashboard', $role . '/dashboard.php', 'dashboard'];

    switch ($role) {
        case 'admin':
            return [
                $home,
                ['Users', 'admin/users.php', 'users'],
                ['Add user', 'admin/user_create.php', 'user_create'],
                ['Courses and batches', null, 'courses'],
                ['Question bank', null, 'questions'],
                ['Mock tests', null, 'tests'],
                ['Fees and reports', null, 'fees'],
            ];
        case 'tutor':
            return [
                $home,
                ['My batches', null, 'batches'],
                ['Question bank', null, 'questions'],
                ['Evaluations', null, 'evaluations'],
            ];
        case 'mentor':
            return [
                $home,
                ['My students', null, 'students'],
                ['Progress', null, 'progress'],
            ];
        default: // student
            return [
                $home,
                ['My course', null, 'course'],
                ['Mock tests', null, 'tests'],
                ['My results', null, 'results'],
            ];
    }
}

// Message box built from a flash array (see flash_get in auth.php).
function flash_html(?array $flash): string
{
    if (!$flash) {
        return '';
    }
    $type = $flash['type'] === 'error' ? 'error' : 'ok';
    return '<div class="alert ' . $type . '"><p>' . e($flash['msg']) . '</p></div>';
}

// A card for a feature that is not built yet.
function empty_card(string $title, string $text, string $tag): string
{
    return '<article class="empty-card"><h3>' . e($title) . '</h3><p>' . e($text) . '</p><span class="tag">' . e($tag) . '</span></article>';
}
