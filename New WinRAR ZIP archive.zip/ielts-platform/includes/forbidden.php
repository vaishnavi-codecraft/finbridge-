<?php
// Shown when a person opens a page their role is not allowed to see.
$pageTitle = 'Access denied';
$u = current_user();
include __DIR__ . '/header.php';
?>
<main class="denied">
    <?php include __DIR__ . '/logo.php'; ?>
    <h1>You do not have access to this page</h1>
    <p>Your account (<?= e($u['role_label']) ?>) cannot open it. Go back to your own dashboard.</p>
    <a class="btn btn-primary" href="<?= e(url(dashboard_path($u['role']))) ?>">Go to my dashboard</a>
</main>
<?php include __DIR__ . '/footer.php'; ?>
