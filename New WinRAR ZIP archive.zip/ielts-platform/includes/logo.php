<svg class="logo" viewBox="0 0 32 32" width="32" height="32" aria-hidden="true">
    <rect width="32" height="32" rx="8" fill="#2B7DE9"/>
    <rect x="7" y="17" width="4" height="8" rx="1.5" fill="#fff"/>
    <rect x="14" y="12" width="4" height="13" rx="1.5" fill="#fff"/>
    <rect x="21" y="7" width="4" height="18" rx="1.5" fill="#F2A93B"/>
</svg>
