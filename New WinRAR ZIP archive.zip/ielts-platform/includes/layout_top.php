<?php
// Shared screen for every role after login: left menu, top bar, then the page content.
// The page sets $pageTitle and $activeNav before including this file.
$user = current_user();
$navs = nav_items($user['role']);
$initial = mb_strtoupper(mb_substr($user['name'], 0, 1));
include __DIR__ . '/header.php';
?>
<div class="shell">
    <aside class="sidebar" id="sidebar">
        <div class="side-brand"><?php include __DIR__ . '/logo.php'; ?><span><?= e(APP_NAME) ?></span></div>
        <nav aria-label="Main menu">
            <?php foreach ($navs as [$label, $path, $key]): ?>
                <?php if ($path): ?>
                    <a class="nav-link<?= ($activeNav ?? '') === $key ? ' active' : '' ?>" href="<?= e(url($path)) ?>"><?= e($label) ?></a>
                <?php else: ?>
                    <span class="nav-link soon"><?= e($label) ?><em>Soon</em></span>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
        <a class="side-logout" href="<?= e(url('auth/logout.php')) ?>">Log out</a>
    </aside>
    <div class="backdrop" id="backdrop"></div>

    <div class="main">
        <header class="topbar">
            <button type="button" class="menu-btn" id="menuBtn" aria-label="Open menu">Menu</button>
            <h1 class="page-title"><?= e($pageTitle) ?></h1>
            <div class="user-chip">
                <span class="avatar"><?= e($initial) ?></span>
                <span class="who"><strong><?= e($user['name']) ?></strong><small><?= e($user['role_label']) ?></small></span>
            </div>
        </header>
        <main class="content">
            <?= flash_html(flash_get()) ?>
