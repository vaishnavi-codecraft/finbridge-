<script src="<?= e(url('assets/js/app.js')) ?>" defer></script>
</body>
</html>
