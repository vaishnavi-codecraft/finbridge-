<?php
// Helpers used on every page: session, safe output, login checks, roles, form protection.
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';   // creates $conn (the database connection)

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

// Gives any page the database connection from config/database.php
function db(): mysqli
{
    global $conn;
    return $conn;
}

// Safely print text on a page (stops malicious HTML/JS).
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

// Hidden code placed in every form so other websites cannot submit it for the user.
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user']);
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

// Each role has its own folder: admin/dashboard.php, student/dashboard.php, ...
function dashboard_path(string $role): string
{
    return $role . '/dashboard.php';
}

// Page needs a logged-in person. Also checks the account is still active.
function require_login(): void
{
    if (!is_logged_in()) {
        redirect('auth/login.php');
    }

    $stmt = db()->prepare('SELECT status FROM users WHERE id = ?');
    $id = current_user()['id'];
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || $row['status'] !== 'active') {
        $_SESSION = [];
        flash_set('Your account is not active. Please contact the institute.', 'error');
        redirect('auth/login.php');
    }
}

// Page needs a logged-in person with one of these roles, for example require_role('admin').
function require_role(string ...$roles): void
{
    require_login();
    if (!in_array(current_user()['role'], $roles, true)) {
        http_response_code(403);
        include __DIR__ . '/forbidden.php';
        exit;
    }
}

// One-time message shown on the next page (example: "Account created").
function flash_set(string $message, string $type = 'ok'): void
{
    $_SESSION['flash'] = ['msg' => $message, 'type' => $type];
}

function flash_get(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

require_once __DIR__ . '/ui.php';
