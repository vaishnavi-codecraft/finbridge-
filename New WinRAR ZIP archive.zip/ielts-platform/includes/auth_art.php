<aside class="auth-art">
    <div class="art-brand"><?php include __DIR__ . '/logo.php'; ?><span><?= e(APP_NAME) ?></span></div>
    <div class="art-body">
        <h1>Climb to your target band.</h1>
        <p>Listening, Reading, Writing and Speaking practice, with tutors and mentors who follow every step.</p>
        <div class="ladder" aria-hidden="true">
            <div class="rung top" style="--w:100%;--i:3"><span>Band 8.0</span></div>
            <div class="rung" style="--w:80%;--i:2"><span>Band 7.0</span></div>
            <div class="rung" style="--w:60%;--i:1"><span>Band 6.0</span></div>
            <div class="rung" style="--w:40%;--i:0"><span>Band 5.0</span></div>
        </div>
    </div>
</aside>
