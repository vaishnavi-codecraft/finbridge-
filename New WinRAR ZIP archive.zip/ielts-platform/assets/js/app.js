(function () {
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Left menu on phones
    var menuBtn = document.getElementById('menuBtn');
    var backdrop = document.getElementById('backdrop');
    if (menuBtn) {
        menuBtn.addEventListener('click', function () {
            document.body.classList.toggle('menu-open');
        });
    }
    if (backdrop) {
        backdrop.addEventListener('click', function () {
            document.body.classList.remove('menu-open');
        });
    }

    // Show / hide password
    document.querySelectorAll('.pw-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.getElementById(btn.dataset.target);
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Hide' : 'Show';
            btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        });
    });

    // Button text changes while the form is being sent
    document.querySelectorAll('form').forEach(function (form) {
        form.addEventListener('submit', function () {
            var btn = form.querySelector('button[data-loading]');
            if (!btn) { return; }
            btn.textContent = btn.dataset.loading;
            btn.classList.add('is-loading');
            setTimeout(function () { btn.disabled = true; }, 0);
        });
    });

    // Numbers on the admin dashboard count up once
    document.querySelectorAll('[data-count]').forEach(function (el) {
        var end = parseInt(el.dataset.count, 10) || 0;
        if (reduce || end === 0) { el.textContent = end; return; }
        var start = null;
        var duration = 800;
        el.textContent = '0';
        function step(t) {
            if (start === null) { start = t; }
            var p = Math.min((t - start) / duration, 1);
            el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3)));
            if (p < 1) { requestAnimationFrame(step); }
        }
        requestAnimationFrame(step);
    });
})();
