(() => {
  const menu = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  if (menu && nav) menu.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menu.setAttribute('aria-expanded', String(open));
    menu.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  document.querySelectorAll('.main-nav a').forEach(link => link.addEventListener('click', () => {
    nav?.classList.remove('open'); menu?.setAttribute('aria-expanded', 'false');
  }));
  const tabs = document.querySelectorAll('.finder-tab');
  const panels = {study: document.getElementById('panel-study'), healthcare: document.getElementById('panel-healthcare')};
  tabs.forEach(tab => tab.addEventListener('click', () => {
    tabs.forEach(item => { item.classList.remove('active'); item.setAttribute('aria-selected', 'false'); });
    tab.classList.add('active'); tab.setAttribute('aria-selected', 'true');
    Object.values(panels).forEach(panel => panel?.classList.remove('active'));
    panels[tab.dataset.panel]?.classList.add('active');
  }));
  const top = document.querySelector('.back-top');
  const updateTop = () => top?.classList.toggle('show', window.scrollY > 450);
  window.addEventListener('scroll', updateTop, {passive:true}); updateTop();
  top?.addEventListener('click', () => window.scrollTo({top:0, behavior:'smooth'}));
  const year = document.getElementById('year'); if (year) year.textContent = new Date().getFullYear();
})();

// SKYPrep hero course finder: progressively reveal relevant choices.
(() => {
  const type = document.getElementById('testType');
  const format = document.getElementById('testFormat');
  const mode = document.getElementById('testCity');
  const form = document.getElementById('courseFinder');
  if (!type || !format || !mode || !form) return;
  const options = {
    IELTS: [['Academic', 'IELTS Academic'], ['General Training', 'IELTS General Training']],
    OET: [['Nursing', 'OET for Nurses'], ['Medicine', 'OET for Doctors'], ['Other healthcare professions', 'OET for other healthcare professions']]
  };
  type.addEventListener('change', () => {
    format.innerHTML = '<option value="" selected disabled>Test format</option>';
    (options[type.value] || []).forEach(([value, label]) => {
      const option = document.createElement('option'); option.value = value; option.textContent = label; format.appendChild(option);
    });
    format.disabled = false; mode.disabled = true; mode.value = '';
  });
  format.addEventListener('change', () => { mode.disabled = false; });
  form.addEventListener('submit', event => {
    event.preventDefault();
    const params = new URLSearchParams({test: type.value, pathway: format.value, mode: mode.value});
    window.location.href = 'index.php?'+params.toString()+'#contact';
  });
})();


// SKYPrep accessible mega-menu controls (desktop hover + click, mobile accordion).
(() => {
  const items = [...document.querySelectorAll('.idp-nav .nav-item')];
  const closeAll = except => items.forEach(item => {
    if (item === except) return;
    item.classList.remove('is-open');
    item.querySelector('.nav-trigger')?.setAttribute('aria-expanded', 'false');
  });
  items.forEach(item => {
    const trigger = item.querySelector('.nav-trigger');
    if (!trigger) return;
    trigger.addEventListener('click', event => {
      event.preventDefault();
      const opening = !item.classList.contains('is-open');
      closeAll(item);
      item.classList.toggle('is-open', opening);
      trigger.setAttribute('aria-expanded', String(opening));
    });
  });
  document.addEventListener('click', event => {
    if (!event.target.closest('.idp-nav')) closeAll();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      closeAll();
      document.querySelector('.menu-toggle')?.focus();
    }
  });
  const nav = document.querySelector('.idp-nav');
  const menuButton = document.querySelector('.menu-toggle');
  nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    closeAll();
    nav.classList.remove('open');
    menuButton?.setAttribute('aria-expanded', 'false');
  }));
})();

// Subtle reveal motion as content enters the viewport; accessible reduced-motion fallback.
(() => {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !('IntersectionObserver' in window)) return;
  const targets = document.querySelectorAll('.proof-item,.quick-grid>a,.test-card,.skills-grid>a,.resource-card,.success-card');
  targets.forEach(el => { el.classList.add('sky-reveal'); });
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: .12, rootMargin: '0px 0px -25px 0px'});
  targets.forEach(el => observer.observe(el));
})();
