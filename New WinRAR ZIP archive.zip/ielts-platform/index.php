<?php
require_once __DIR__ . '/config/config.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$u = fn($p) => BASE_URL . '/' . ltrim($p, '/');
$loggedIn = !empty($_SESSION['user']);
$loginUrl = $u($loggedIn ? 'dashboard.php' : 'auth/login.php');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="SKYPrep offers expert IELTS and OET coaching, online classes, mock exams, tutor feedback and guided learning for your next step.">
<meta name="theme-color" content="#0756c9">
<title>SKYPrep | IELTS &amp; OET Coaching, Practice and Mock Tests</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700;800&family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= $h($u('assets/css/home.css')) ?>">
</head>
<body id="top">
<div class="sky-promo-bar" role="region" aria-label="Diwali special offer">
  <div class="sky-promo-inner">
    <span class="promo-spark" aria-hidden="true">✦</span>
    <p><strong>DIWALI SPECIAL</strong><span class="promo-divider">•</span> Enjoy <b>25% OFF</b> package upgrades <span class="promo-divider">+</span> every 5th package is <b>50% OFF</b></p>
    <a href="#contact">Explore offer <span aria-hidden="true">↗</span></a>
  </div>
</div>
<header class="site-header idp-header">
  <div class="container header-inner">
    <a class="brand idp-brand" href="<?= $h($u('index.php')) ?>" aria-label="SKYPrep home">
      <span class="brand-mark"><svg viewBox="0 0 44 44" aria-hidden="true"><path d="M5 28.5 18.5 8l5.8 9.2L38 5 23.5 36l-6.1-9.3L5 28.5Z" fill="url(#sky)"/><defs><linearGradient id="sky" x1="5" y1="36" x2="38" y2="5"><stop stop-color="#7044dc"/><stop offset=".52" stop-color="#087be8"/><stop offset="1" stop-color="#05c7ed"/></linearGradient></defs></svg></span>
      <span class="brand-word">SKY<span>PREP</span></span>
    </a>
    <button class="menu-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="skyMainNav"><span></span><span></span><span></span></button>
    <nav class="main-nav idp-nav" id="skyMainNav" aria-label="Main navigation">
      <a class="nav-simple" href="#about">About</a>
      <div class="nav-item has-mega">
        <button class="nav-trigger" type="button" aria-expanded="false" aria-controls="coursesMega">Courses <span class="nav-arrow" aria-hidden="true"><svg viewBox="0 0 16 16"><path d="m3 6 5 5 5-5"/></svg></span></button>
        <div class="dropdown mega-menu" id="coursesMega">
          <div class="mega-course-card">
            <div class="mega-card-heading"><span class="mega-icon"><svg viewBox="0 0 24 24"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 5.5v16M8 7h8M8 11h7"/></svg></span><span><b>IELTS</b><small>For study, work &amp; migration</small></span></div>
            <a href="#ielts"><span class="mega-link-icon"><svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M16 4v4h4M8 12h8M8 16h6"/></svg></span>IELTS Academic <i>↗</i></a>
            <a href="#ielts"><span class="mega-link-icon"><svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M16 4v4h4M8 12h8M8 16h6"/></svg></span>IELTS General Training <i>↗</i></a>
          </div>
          <div class="mega-course-card">
            <div class="mega-card-heading"><span class="mega-icon"><svg viewBox="0 0 24 24"><path d="M12 21s8-4 8-10V5l-8-3-8 3v6c0 6 8 10 8 10Z"/><path d="M9 12h6M12 9v6"/></svg></span><span><b>OET</b><small>English for healthcare professionals</small></span></div>
            <a href="#oet"><span class="mega-link-icon"><svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M16 4v4h4M8 12h8M8 16h6"/></svg></span>OET for Nurses <i>↗</i></a>
            <a href="#oet"><span class="mega-link-icon"><svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M16 4v4h4M8 12h8M8 16h6"/></svg></span>OET for Doctors <i>↗</i></a>
            <a href="#oet"><span class="mega-link-icon"><svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M16 4v4h4M8 12h8M8 16h6"/></svg></span>Other healthcare professions <i>↗</i></a>
          </div>
        </div>
      </div>
      <div class="nav-item">
        <button class="nav-trigger" type="button" aria-expanded="false">Preparation <span class="nav-arrow" aria-hidden="true"><svg viewBox="0 0 16 16"><path d="m3 6 5 5 5-5"/></svg></span></button>
        <div class="dropdown simple-dropdown"><a href="#skills">Four skills training</a><a href="#mock-tests">Mock examinations</a><a href="#classes">Live &amp; recorded classes</a></div>
      </div>
      <a class="nav-simple" href="#resources">Resources</a>
      <a class="nav-simple" href="#contact">Contact Us</a>
    </nav>
    <div class="header-actions idp-actions">
      <a class="login-link" href="<?= $h($loginUrl) ?>"><span class="user-circle" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2"/><path d="M5.5 20c.7-3.5 3-5.2 6.5-5.2s5.8 1.7 6.5 5.2"/></svg></span><?= $loggedIn ? 'Dashboard' : 'Sign In' ?></a>
      <a class="primary-btn header-cta" href="#contact">Get started free</a>
    </div>
  </div>
</header>
<main>
<section class="hero idp-hero" aria-label="SKYPrep IELTS and OET introduction">
  <div class="hero-card">
    <div class="hero-visual">
      <div class="hero-photo"></div><div class="hero-photo-wash"></div>
      <div class="hero-copy">
        <span class="hero-kicker">YOUR FUTURE. YOUR NEXT STEP.</span>
        <h1>Introducing<br><em>IELTS &amp; OET</em></h1>
        <p>Prepare with confidence. Achieve your global goals with expert-led learning and personal guidance from SKYPrep.</p>
        <a class="hero-explore" href="#tests">Explore courses <b>→</b></a>
      </div>
      <div class="hero-stamp"><span>SKYPREP</span><b>IELTS<br>&amp; OET</b><small>LEARN • PRACTISE • ACHIEVE</small></div>
    </div>
    <div class="hero-booking">
      <div class="booking-accent"></div>
      <h2>Success starts with SKYPrep</h2>
      <form class="availability-form" id="courseFinder">
        <label class="sr-only" for="testType">Test type</label>
        <select id="testType" name="test_type" required><option value="" selected disabled>Test type</option><option value="IELTS">IELTS</option><option value="OET">OET</option></select>
        <label class="sr-only" for="testFormat">Test format</label>
        <select id="testFormat" name="test_format" required disabled><option value="" selected>Test format</option></select>
        <label class="sr-only" for="testCity">Course mode</label>
        <select id="testCity" name="course_mode" required disabled><option value="" selected>Course mode</option><option value="Online">Online</option><option value="Classroom">Classroom</option><option value="Hybrid">Hybrid</option></select>
        <button type="submit">Check availability</button>
      </form>
      <p class="booking-note">Find the right preparation pathway for your goals.</p>
    </div>
  </div>
</section>
<section class="proof-section idp-lead-section"><div class="container"><h2>Leading English test preparation for <span>study, work and migration</span></h2><p>Choose the right pathway, build your skills and prepare for your next opportunity with SKYPrep.</p></div></section>
<section class="quick-links" id="quick-links"><div class="container quick-grid"><a href="#test-finder"><span class="quick-icon">⌕</span><span><b>Find the right test</b><small>Not sure whether IELTS or OET?</small></span><i>↗</i></a><a href="#mock-tests"><span class="quick-icon">▣</span><span><b>Practise for your exam</b><small>Build confidence with mock tests</small></span><i>↗</i></a><a href="#contact"><span class="quick-icon">☏</span><span><b>Speak to our team</b><small>Get help planning your preparation</small></span><i>↗</i></a></div></section>
<section class="test-finder-section" id="test-finder"><div class="container finder-layout"><div class="finder-intro"><span class="section-kicker">LET'S FIND YOUR PATH</span><h2>Which English test<br>do you <em>need?</em></h2><p>Your goal helps determine the right preparation route. Choose the pathway that best describes you to explore the right course.</p></div><div class="finder-panel"><div class="finder-tabs" role="tablist" aria-label="Choose your pathway"><button class="finder-tab active" data-panel="study" role="tab" aria-selected="true">Study / Work / Migration</button><button class="finder-tab" data-panel="healthcare" role="tab" aria-selected="false">Healthcare profession</button></div><div class="finder-content active" id="panel-study"><div class="finder-symbol">✈</div><div><small>YOUR PATHWAY</small><h3>IELTS preparation</h3><p>For higher education, professional registration, work and migration goals.</p><a href="#ielts">Explore IELTS courses <b>→</b></a></div></div><div class="finder-content" id="panel-healthcare"><div class="finder-symbol">✚</div><div><small>YOUR PATHWAY</small><h3>OET preparation</h3><p>For nurses, doctors and other healthcare professionals communicating in clinical settings.</p><a href="#oet">Explore OET courses <b>→</b></a></div></div></div></div></section>
<section class="tests-section" id="tests"><div class="container"><div class="section-heading"><div><span class="section-kicker">EXPLORE OUR PROGRAMMES</span><h2>Choose the test<br>that takes you <em>forward.</em></h2></div><p>Focused coaching for your exam and your ambition. Learn the format, build the right skills and practise with a plan.</p></div><div class="test-cards">
<article class="test-card" id="ielts"><div class="test-photo ielts-photo"><span class="photo-chip">GLOBAL ENGLISH PROFICIENCY</span><div class="photo-word">IELTS</div><span class="photo-caption">International English Language Testing System</span></div><div class="test-info"><div class="test-meta"><span>STUDY • WORK • MIGRATION</span><span class="meta-arrow">↗</span></div><h3>IELTS preparation</h3><p>Build confidence across all four skills with structured lessons, exam strategies, practice and expert feedback.</p><div class="test-options"><a href="#contact"><span><b>IELTS Academic</b><small>For higher education and professional goals</small></span><i>→</i></a><a href="#contact"><span><b>IELTS General Training</b><small>For work, migration and everyday contexts</small></span><i>→</i></a></div><a class="outline-link" href="#contact">EXPLORE IELTS <b>↗</b></a></div></article>
<article class="test-card" id="oet"><div class="test-photo oet-photo"><span class="photo-chip">ENGLISH FOR HEALTHCARE</span><div class="photo-word">OET</div><span class="photo-caption">Occupational English Test</span></div><div class="test-info"><div class="test-meta"><span>HEALTHCARE PROFESSIONALS</span><span class="meta-arrow">↗</span></div><h3>OET preparation</h3><p>Develop the language and communication skills needed for safe, clear and confident clinical interactions.</p><div class="test-options"><a href="#contact"><span><b>OET for Nurses</b><small>Patient-centred communication and writing</small></span><i>→</i></a><a href="#contact"><span><b>OET for Doctors &amp; other professions</b><small>Profession-specific clinical scenarios</small></span><i>→</i></a></div><a class="outline-link" href="#contact">EXPLORE OET <b>↗</b></a></div></article>
</div></div></section>
<section class="feature-band" id="prepare"><div class="container feature-layout"><div class="feature-copy"><span class="section-kicker light-kicker">PREPARATION THAT FITS YOUR LIFE</span><h2>Everything you need<br>to feel <em>exam-ready.</em></h2><p>From your first lesson to your final practice test, SKYPrep brings your learning journey into one connected experience.</p><a class="white-btn" href="<?= $h($u('auth/register.php')) ?>">Start learning <span>↗</span></a></div><div class="feature-steps"><a href="#classes"><span>01</span><div><b>Learn with expert tutors</b><small>Live online lessons and structured learning plans</small></div><i>↗</i></a><a href="#mock-tests"><span>02</span><div><b>Practise in exam-style conditions</b><small>Timed mock tests and realistic question formats</small></div><i>↗</i></a><a href="#feedback"><span>03</span><div><b>Get personal feedback</b><small>Writing and speaking evaluation from tutors</small></div><i>↗</i></a><a href="#progress"><span>04</span><div><b>Track your improvement</b><small>Understand strengths and plan what comes next</small></div><i>↗</i></a></div></div></section>
<section class="skills-section" id="skills"><div class="container"><div class="section-heading"><div><span class="section-kicker">BUILD YOUR FOUR CORE SKILLS</span><h2>Practise every part<br>of the <em>test.</em></h2></div><p>Get dedicated support for Listening, Reading, Writing and Speaking, with IELTS question types and OET clinical communication practice.</p></div><div class="skills-grid"><a href="#contact"><span class="skill-number">01 / LISTENING</span><div class="skill-symbol">♫</div><h3>Listening</h3><p>Improve focus, understand different accents and identify key information.</p><b>EXPLORE PRACTICE <i>↗</i></b></a><a href="#contact"><span class="skill-number">02 / READING</span><div class="skill-symbol">▤</div><h3>Reading</h3><p>Build comprehension, vocabulary, scanning skills and time management.</p><b>EXPLORE PRACTICE <i>↗</i></b></a><a href="#contact"><span class="skill-number">03 / WRITING</span><div class="skill-symbol">✎</div><h3>Writing</h3><p>Learn response structure, task achievement and clear professional writing.</p><b>EXPLORE PRACTICE <i>↗</i></b></a><a href="#contact"><span class="skill-number">04 / SPEAKING</span><div class="skill-symbol">◉</div><h3>Speaking</h3><p>Develop fluency, confidence and natural communication in test situations.</p><b>EXPLORE PRACTICE <i>↗</i></b></a></div></div></section>
<section class="resources-section" id="resources"><div class="container"><div class="section-heading"><div><span class="section-kicker">YOUR PREPARATION HUB</span><h2>Make every study<br>session <em>count.</em></h2></div><p>Access useful materials and practice opportunities to help you prepare with confidence, at your own pace.</p></div><div class="resources-grid"><article class="resource-card"><div class="resource-visual resource-library"><span>01</span><div class="resource-graphic">▤</div><b>LEARNING<br>LIBRARY</b></div><div class="resource-copy"><small>READ • REVISE • REPEAT</small><h3>Study materials &amp; guides</h3><p>Explore notes, PDFs, vocabulary support and learning resources for your course.</p><a href="<?= $h($loginUrl) ?>">Explore the library <b>→</b></a></div></article><article class="resource-card" id="mock-tests"><div class="resource-visual resource-mock"><span>02</span><div class="resource-graphic">◷</div><b>MOCK<br>EXAMS</b></div><div class="resource-copy"><small>TEST YOUR READINESS</small><h3>Mock tests &amp; practice</h3><p>Get familiar with question formats, exam timing and the experience of test day.</p><a href="<?= $h($loginUrl) ?>">Start practising <b>→</b></a></div></article><article class="resource-card" id="classes"><div class="resource-visual resource-classes"><span>03</span><div class="resource-graphic">▷</div><b>LIVE<br>LEARNING</b></div><div class="resource-copy"><small>LEARN WITH EXPERTS</small><h3>Live &amp; recorded classes</h3><p>Join tutor-led sessions and revisit lessons whenever you need a refresher.</p><a href="<?= $h($loginUrl) ?>">View learning hub <b>→</b></a></div></article></div></div></section>
<section class="support-section" id="feedback"><div class="container support-layout"><div class="support-visual"><div class="support-image"></div><div class="support-note"><span>✦</span><b>Guidance at every step</b><small>Learn • Practise • Improve</small></div></div><div class="support-copy"><span class="section-kicker">PERSONAL SUPPORT, REAL PROGRESS</span><h2>Your goal.<br>Your tutor.<br><em>Your next step.</em></h2><p>Preparation should never feel like guesswork. Work with tutors and mentors who help you understand your strengths, focus on areas to improve and keep moving towards your target.</p><ul><li>Individual learning guidance and study plans</li><li>Writing and speaking feedback</li><li>Progress reviews and targeted practice</li><li>Support for IELTS and healthcare-focused OET</li></ul><a class="text-arrow" href="#contact">Talk to our academic team <b>→</b></a></div></div></section>
<section class="success-section" id="results"><div class="container"><div class="section-heading"><div><span class="section-kicker">STUDENT JOURNEYS</span><h2>Every milestone<br>starts with <em>one step.</em></h2></div><p>Every learner has a different destination. We're here to support the effort, practice and progress that move you closer.</p></div><div class="success-grid"><article class="success-card"><div class="quote-mark">“</div><p>Consistent practice and clear feedback can turn a difficult goal into a plan you know how to follow.</p><div class="success-person"><span class="person-avatar">S</span><span><b>SKYPrep learner</b><small>IELTS pathway</small></span><span class="stars">★★★★★</span></div></article><article class="success-card featured-success"><div class="quote-mark">“</div><p>Building confidence in clinical communication takes practice. The right guidance helps every step feel more manageable.</p><div class="success-person"><span class="person-avatar">O</span><span><b>SKYPrep learner</b><small>OET pathway</small></span><span class="stars">★★★★★</span></div></article><article class="success-card"><div class="quote-mark">“</div><p>A focused study routine, realistic mock tests and regular review help you see how far you have come.</p><div class="success-person"><span class="person-avatar">I</span><span><b>SKYPrep learner</b><small>IELTS pathway</small></span><span class="stars">★★★★★</span></div></article></div><p class="testimonial-note">Illustrative learner stories. Replace with verified student testimonials and approved results before launch.</p></div></section>
<section class="about-strip" id="about"><div class="container about-layout"><div><span class="section-kicker light-kicker">WELCOME TO SKYPrep</span><h2>A learning partner<br>for your <em>next chapter.</em></h2></div><div><p>SKYPrep brings IELTS and OET preparation together through structured courses, expert teaching, realistic examination practice and personal support. Whether your ambition is academic, professional or healthcare-focused, we're here to help you prepare with purpose.</p><a class="white-text-link" href="#contact">Get to know us <b>→</b></a></div></div></section>
<section class="faq-section" id="faq"><div class="container faq-layout"><div><span class="section-kicker">GOOD TO KNOW</span><h2>Questions?<br>We've got <em>answers.</em></h2><p>Need help choosing a course or understanding how online preparation works? Start here or speak to our team.</p><a class="text-arrow" href="#contact">Ask us a question <b>→</b></a></div><div class="faq-list"><details><summary>What is the difference between IELTS and OET?<i>+</i></summary><p>IELTS is a general English proficiency test used for study, work and migration. OET is designed for healthcare professionals and uses clinical and workplace-related scenarios.</p></details><details><summary>Do you offer IELTS Academic and General Training?<i>+</i></summary><p>Yes. SKYPrep's learning pathways cover IELTS Academic and IELTS General Training preparation.</p></details><details><summary>Which healthcare professions can prepare for OET?<i>+</i></summary><p>OET preparation can be tailored for nurses, doctors and other eligible healthcare professions, with profession-relevant communication practice.</p></details><details><summary>Can I attend classes online?<i>+</i></summary><p>The platform is designed to support online learning, recorded lessons, assignments and guided practice. Contact the team for current class schedules.</p></details><details><summary>Will I receive feedback on writing and speaking?</summary><p>Yes. Tutor-led writing and speaking feedback is part of the planned learning experience, alongside objective practice and progress reviews.</p></details></div></div></section>
<section class="contact-section" id="contact"><div class="container contact-layout"><div><span class="section-kicker light-kicker">LET'S PLAN YOUR NEXT STEP</span><h2>Your journey starts<br>with a <em>conversation.</em></h2><p>Tell us whether you're preparing for IELTS or OET. Our team can help you explore the right pathway and plan your next step.</p></div><div class="contact-actions"><a class="white-btn" href="<?= $h($u('auth/register.php')) ?>">Enquire now <span>↗</span></a><a href="<?= $h($loginUrl) ?>">Already learning with us? <b>Log in →</b></a></div></div></section>
</main>
<footer class="site-footer"><div class="container footer-main"><div class="footer-brand"><a class="footer-logo" href="#top"><span class="brand-mark"><svg viewBox="0 0 44 44"><path d="M5 28.5 18.5 8l5.8 9.2L38 5 23.5 36l-6.1-9.3L5 28.5Z" fill="url(#footSky)"/><defs><linearGradient id="footSky" x1="5" y1="36" x2="38" y2="5"><stop stop-color="#8c5aff"/><stop offset=".55" stop-color="#087be8"/><stop offset="1" stop-color="#05c7ed"/></linearGradient></defs></svg></span><span class="brand-word">SKY<span>PREP</span><small>LEARN • PRACTISE • ACHIEVE</small></span></a><p>Expert-led IELTS and OET preparation, practical learning resources and personal guidance for your next step.</p></div><div class="footer-col"><h4>OUR TESTS</h4><a href="#ielts">IELTS Academic</a><a href="#ielts">IELTS General Training</a><a href="#oet">OET for Nurses</a><a href="#oet">OET for Doctors</a></div><div class="footer-col"><h4>PREPARATION</h4><a href="#skills">Four skills training</a><a href="#mock-tests">Mock examinations</a><a href="#resources">Learning resources</a><a href="#classes">Online classes</a></div><div class="footer-col"><h4>SKYPrep</h4><a href="#about">About us</a><a href="#results">Student stories</a><a href="#contact">Contact</a><a href="<?= $h($loginUrl) ?>">Student login</a></div></div><div class="container footer-bottom"><span>© <span id="year"></span> SKYPrep. All rights reserved.</span><span>IELTS &amp; OET preparation • Learn with purpose. Achieve with confidence.</span></div></footer>
<button class="back-top" aria-label="Back to top">↑</button>
<script src="<?= $h($u('assets/js/home.js')) ?>"></script>
</body></html>
