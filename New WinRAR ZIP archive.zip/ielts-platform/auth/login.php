<?php
// Login for every role.
require_once __DIR__ . '/../includes/auth.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$errors = [];
$email = '';
$notice = flash_get();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $errors[] = 'Your session expired. Please try again.';
    } else {
        $email    = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        $stmt = db()->prepare(
            'SELECT u.id, u.full_name, u.password_hash, u.status, r.name AS role, r.label AS role_label
             FROM users u JOIN roles r ON r.id = u.role_id
             WHERE u.email = ? LIMIT 1'
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $errors[] = 'Email or password is incorrect.';
        } elseif ($user['status'] !== 'active') {
            $errors[] = 'This account is blocked. Please contact the institute.';
        } else {
            session_regenerate_id(true);   // new session id after login (security)
            $_SESSION['user'] = [
                'id'         => (int) $user['id'],
                'name'       => $user['full_name'],
                'role'       => $user['role'],
                'role_label' => $user['role_label'],
            ];

            $upd = db()->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?');
            $upd->bind_param('i', $user['id']);
            $upd->execute();
            $upd->close();

            redirect(dashboard_path($user['role']));   // each role goes to its own dashboard
        }
    }
}

$pageTitle = 'Log in';
include __DIR__ . '/../includes/header.php';
?>
<main class="auth">
    <?php include __DIR__ . '/../includes/auth_art.php'; ?>
    <section class="auth-form">
        <div class="form-card">
            <h2>Welcome back</h2>
            <p class="lead">Log in to continue your preparation.</p>
            <?= flash_html($notice) ?>
            <?php if ($errors): ?>
                <div class="alert error">
                    <?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?>
                </div>
            <?php endif; ?>
            <form method="post" novalidate>
                <?= csrf_field() ?>
                <label for="email">Email</label>
                <input id="email" name="email" type="email" autocomplete="email" value="<?= e($email) ?>" required>

                <label for="password">Password</label>
                <div class="pw-field">
                    <input id="password" name="password" type="password" autocomplete="current-password" required>
                    <button type="button" class="pw-toggle" data-target="password" aria-label="Show password">Show</button>
                </div>

                <button type="submit" class="btn btn-primary" data-loading="Signing in...">Log in</button>
            </form>
            <p class="switch">New student? <a href="<?= e(url('auth/register.php')) ?>">Create an account</a></p>
        </div>
    </section>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
