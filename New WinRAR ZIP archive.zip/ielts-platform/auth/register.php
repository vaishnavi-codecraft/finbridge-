<?php
// Student registration.
require_once __DIR__ . '/../includes/auth.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$errors = [];
$old = ['full_name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $errors[] = 'Your session expired. Please try again.';
    } else {
        $old['full_name'] = trim($_POST['full_name'] ?? '');
        $old['email']     = strtolower(trim($_POST['email'] ?? ''));
        $old['phone']     = preg_replace('/\D/', '', $_POST['phone'] ?? '');   // keep digits only
        $password         = $_POST['password'] ?? '';
        $confirm          = $_POST['confirm_password'] ?? '';

        if (strlen($old['full_name']) < 2 || strlen($old['full_name']) > 100) {
            $errors[] = 'Enter your full name (2 to 100 characters).';
        }
        if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Enter a valid email address.';
        }
        if (strlen($old['phone']) < 10 || strlen($old['phone']) > 15) {
            $errors[] = 'Enter a phone number with 10 to 15 digits.';
        }
        if (strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        }
        if ($password !== $confirm) {
            $errors[] = 'The two passwords do not match.';
        }

        if (!$errors) {
            $duplicate = 'An account with this email or phone number already exists. Try logging in.';

            // 1. Look for an existing student with the same email or phone
            $check = db()->prepare('SELECT id FROM users WHERE email = ? OR phone = ? LIMIT 1');
            $check->bind_param('ss', $old['email'], $old['phone']);
            $check->execute();
            $check->store_result();
            $exists = $check->num_rows > 0;
            $check->close();

            if ($exists) {
                $errors[] = $duplicate;
            } else {
                try {
                    // 2. Find the id of the "student" role
                    $roleId = (int) db()->query("SELECT id FROM roles WHERE name = 'student'")->fetch_assoc()['id'];
                    $hash   = password_hash($password, PASSWORD_DEFAULT);   // scrambled password

                    // 3. Save the new student
                    $insert = db()->prepare(
                        'INSERT INTO users (role_id, full_name, email, phone, password_hash) VALUES (?, ?, ?, ?, ?)'
                    );
                    $insert->bind_param('issss', $roleId, $old['full_name'], $old['email'], $old['phone'], $hash);
                    $insert->execute();
                    $insert->close();

                    flash_set('Account created. You can log in now.');
                    redirect('auth/login.php');
                } catch (mysqli_sql_exception $ex) {
                    // 1062 = the database itself refused a duplicate
                    $errors[] = $ex->getCode() === 1062 ? $duplicate : 'Something went wrong. Please try again.';
                }
            }
        }
    }
}

$pageTitle = 'Create account';
include __DIR__ . '/../includes/header.php';
?>
<main class="auth">
    <?php include __DIR__ . '/../includes/auth_art.php'; ?>
    <section class="auth-form"><div class="form-card">
        <h2>Create your student account</h2><p class="lead">Start practising in a few minutes.</p>
        <?php if ($errors): ?>
            <div class="alert error">
                <?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="post" novalidate>
            <?= csrf_field() ?>
            <label for="full_name">Full name</label>
            <input id="full_name" name="full_name" type="text" value="<?= e($old['full_name']) ?>" required>

            <label for="email">Email</label>
            <input id="email" name="email" type="email" value="<?= e($old['email']) ?>" required>

            <label for="phone">Phone number</label>
            <input id="phone" name="phone" type="tel" value="<?= e($old['phone']) ?>" required>

            <label for="password">Password (at least 8 characters)</label>
            <input id="password" name="password" type="password" required>

            <label for="confirm_password">Confirm password</label>
            <input id="confirm_password" name="confirm_password" type="password" required>

            <button type="submit" class="btn btn-primary" data-loading="Creating account...">Create account</button>
        </form>
        <p class="switch">Already registered? <a href="<?= e(url('auth/login.php')) ?>">Log in</a></p>
    </div></section>
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
