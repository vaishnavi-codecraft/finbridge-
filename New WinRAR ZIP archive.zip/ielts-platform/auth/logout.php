<?php
// Ends the session and returns to login.
require_once __DIR__ . '/../includes/auth.php';
$_SESSION = [];
session_destroy();
header('Location: ' . url('auth/login.php'));
exit;
