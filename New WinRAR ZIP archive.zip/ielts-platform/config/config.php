<?php
// Project settings. The website name is kept here so it can be changed in one place.
define('APP_NAME', 'SkyPrep');
define('BASE_URL', '/ielts-platform');   // the folder name inside htdocs
