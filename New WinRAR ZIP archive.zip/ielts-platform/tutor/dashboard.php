<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('tutor');
$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
include __DIR__ . '/../includes/layout_top.php';
?>
<section class="welcome">
    <h2>Welcome, <?= e(current_user()['name']) ?></h2>
    <p>Your classes and student work will appear here.</p>
</section>
<section class="card-grid">
    <?= empty_card('My batches', 'You have no batches yet. They appear here once the admin assigns you to one.', 'Part 4') ?>
    <?= empty_card('Pending evaluations', 'Writing and Speaking work from your students will wait here for marking.', 'Part 7') ?>
    <?= empty_card('Question bank', 'Add and manage Listening, Reading, Writing and Speaking questions.', 'Part 5') ?>
</section>
<?php include __DIR__ . '/../includes/layout_bottom.php'; ?>
