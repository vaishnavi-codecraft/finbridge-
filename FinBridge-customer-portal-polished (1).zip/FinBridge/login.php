<?php
require __DIR__ . '/includes/bootstrap.php';
// Same browser = same session. If a user of a different portal is signed in, sign them out so this portal's login can be used.
if (current_user() && !in_array(current_user()['role'], ['customer'], true)) { $_SESSION = []; }
if (current_user()) redirect_to_home();

// Preserve only a product code that is currently active in the database.
$requestedLoan = strtoupper(trim((string)($_GET['loan'] ?? '')));
if ($requestedLoan !== '') {
    $productCheck = $pdo->prepare('SELECT code FROM loan_products WHERE code = ? AND is_active = 1 LIMIT 1');
    $productCheck->execute([$requestedLoan]);
    $validLoan = $productCheck->fetchColumn();
    if ($validLoan) $_SESSION['finbridge_selected_loan'] = $validLoan;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $error = attempt_login($pdo, trim($_POST['identifier'] ?? ''), $_POST['password'] ?? '', 'customer');
}
auth_start('customer', 'Sign In', null);
?>
      <h2 class="au-title">Sign In</h2>
      <p class="au-lead">Welcome back. Log in to track your loans.</p>
      <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="au-field">
          <label for="identifier">CUSTOMER ID, MOBILE OR EMAIL</label>
          <input type="text" id="identifier" name="identifier" placeholder="e.g. FBC000001" required autofocus>
        </div>
        <?php auth_password_field('password', 'PASSWORD', 'Enter your password'); ?>
        <a class="au-forgot" href="#" data-modal="forgot">Forgot password?</a>
        <button class="au-btn" type="submit">Sign In <span>→</span></button>
      </form>
<?php auth_end();
