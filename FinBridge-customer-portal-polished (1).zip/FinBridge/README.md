# FinBridge Loan Management System (demo prototype)

Fictional finance company with physical branches (Chennai, Coimbatore, Madurai out of the box; the admin can add more).
PHP + MySQL + HTML/CSS/JS. Uses simulated disbursement only. No real money or real customer data.

## Setup (XAMPP)
1. Start Apache and MySQL.
2. phpMyAdmin > Import > `database/finbridge.sql` (fresh install, includes everything).
   **Already have the database?** Do NOT re-import (it would erase your data). Open phpMyAdmin > `finbridge` > SQL and run
   `database/migration_003_two_part_apply.sql` once. It keeps your data and is safe to run twice. (XAMPP's MariaDB is required;
   plain MySQL does not support `ADD COLUMN IF NOT EXISTS`.)
3. Put this folder in `C:\xampp\htdocs\`.
4. Fresh install only: open `http://localhost/<folder-name>/database/seed_users.php` once, then delete that file.
5. Open `http://localhost/<folder-name>/`.
6. Uploaded documents are saved in `storage/documents/` (blocked from the web by `storage/.htaccess`; files are only
   served through `download_document.php` after a permission check). The folder must be writable (it is by default on XAMPP).

## Login pages (password for all demo users: Demo@123)
- Customers: `/login.php` - Customer ID (FBC000001), mobile 9876543210, or customer@finbridge.test
- Staff: `/staff/login.php` - OFF-CHN-001 (officer), MGR-CHN-001 (manager), ACC-001 (accounts); same pattern for CBE and MDU
- Admin: `/admin/login.php` - ADM-001

## How a loan application works
1. **Quick Apply** (`customer/apply.php`): a few loan-specific questions, live EMI and an indicative eligibility result
   ("May meet initial criteria" / "More information required" / "Does not meet the current demo criteria").
   Saved as a **draft**. The customer is never asked to pick a branch.
2. **Complete your application** (`customer/complete.php`): personal details (the **PIN code picks the branch** automatically),
   financial details, loan details, documents, then a review page with Edit links and the declaration. **Submit** gives the
   application number (FB2026-00001), sets the status to Submitted and assigns an officer of the matched branch.
3. **Branch officer** checks each document (accept / ask for re-upload), records **field verification** (in-person visit, call or
   document check, with notes) and forwards the case with a recommendation. A home loan cannot be forwarded without a recorded visit,
   and nothing can be forwarded while required documents are missing or marked "re-upload needed".
4. **Branch manager** reads the officer's findings and verification, then approves, rejects or returns it.
5. If the officer asks for more documents, the customer uploads them in **My Documents** and sends a response; the case goes back to the officer.
6. **Accounts officer** (ACC-001) prepares the agreement, marks it complete and runs the simulated disbursement (success or simulated failure with retry). A successful disbursement creates the loan account and the full EMI schedule.
7. **Accounts officer** records EMI payments; overdue EMIs are flagged automatically; the loan closes when the last EMI is paid. The customer sees balance, schedule and payment history under Loan Account.
8. **Admin** edits loan products (rates, amounts, tenures), and uses Overview for reports and the audit log.

Branch matching order: PIN code, then district, then city, then state, then the default branch (set by the admin in **Admin > Branches**).

## Test mode
`config/config.php` has `const TEST_MODE = true;` - documents become optional and any file type is accepted. Set it to `false` for strict rules.

## Passwords
Everyone can change their password from the **Change password** link in the top bar. Forgot password (all portals) verifies the ID and registered email and shows a reset link on screen (a real system would email it).

## Build stages
1-7. Database, logins, branches, customer portal, documents, officer review, manager approval, staff registration: done
8. Simulated disbursement: done
9. Loan accounts and EMI schedule: done
10. Repayments, overdue marking, loan closing: done
11. Admin loan products, overview/reports, audit log viewer: done
12. Forgot password, change password, employee ID unique index with retry: done

## UI and workflow notes
- The refreshed UI uses a brighter, responsive finance-dashboard style across customer, staff and admin pages.
- Customer loan applications are routed automatically from the entered PIN code; customers do not need to select an office location.
- Monthly income is entered as a typed amount rather than adjusted with number-spinner arrows. Selecting **Other** on supported loan questions reveals a required detail field.
- The bank name/account fields are the customer's own bank details for the demo disbursement workflow; there is no separate real or partner “dummy bank” integration. Seed users and all disbursement actions are fictional/simulated.
- Approval is a staff workflow: a branch officer verifies documents and records findings, then the branch manager makes the approve/reject/return decision. Accounts staff handle agreement and simulated disbursement after approval. The eligibility box is indicative only and never makes the final decision.


## End-to-end status troubleshooting
- `documents_required`: customer must upload requested files and respond from Customer > My Documents. The status returns to `under_review`; the officer rechecks and forwards.
- `pending_manager_decision`: the manager can Approve, Reject, or Return. If the decision controls are absent, the application is not in this status yet.
- `approved`: the Accounts Officer can see it in Disbursements and prepare the agreement.
- `agreement_pending`: customer accepts the agreement; accounts then marks it complete.
- `ready_for_disbursement`: accounts can run the Demo Bank transfer. A failed transfer can be retried.
- `active`: loan account and EMI schedule are created; customer can pay EMIs and accounts can record repayments.

**Demo Bank** is a fictional funding bank used to demonstrate disbursement and transaction outcomes. It does not connect to a real bank or move real money. The system does not bypass required document checks or manager approval.
