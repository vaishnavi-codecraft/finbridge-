<?php
// Change your own password (staff, admin and customers).
require __DIR__ . '/includes/bootstrap.php';
require_login();
$user = current_user();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $cur = $_POST['current'] ?? ''; $new = $_POST['password'] ?? ''; $new2 = $_POST['password2'] ?? '';
    $s = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
    $s->execute([$user['id']]);
    $hash = (string)$s->fetchColumn();
    if (!password_verify($cur, $hash)) $error = 'Your current password is not correct.';
    elseif (strlen($new) < 8) $error = 'New password must be at least 8 characters.';
    elseif ($new !== $new2) $error = 'New password and confirmation do not match.';
    elseif ($new === $cur) $error = 'Choose a password different from the current one.';
    else {
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
        session_regenerate_id(true);
        audit($pdo, (int)$user['id'], 'password_changed', 'user', (int)$user['id']);
        set_flash('Your password has been changed.');
        header('Location: change_password.php'); exit;
    }
}
page_header('Change Password');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
if ($error) echo '<div class="error">' . e($error) . '</div>';
?>
<div class="card" style="max-width:460px">
  <form method="post" autocomplete="off">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <label>Current password</label><input type="password" name="current" required>
    <label>New password (at least 8 characters)</label><input type="password" name="password" required minlength="8">
    <label>Confirm new password</label><input type="password" name="password2" required minlength="8">
    <p><button class="btn" type="submit">Change password</button></p>
  </form>
</div>
<?php page_footer();
