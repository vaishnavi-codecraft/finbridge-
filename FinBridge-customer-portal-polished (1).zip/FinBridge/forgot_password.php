<?php
// Forgot password (all portals). Demo: with no mail server, the reset link is shown on screen after the
// account is verified by ID/mobile/email AND the registered email.
require __DIR__ . '/includes/bootstrap.php';
$kind = in_array($_GET['portal'] ?? $_POST['portal'] ?? '', ['customer', 'staff', 'admin'], true) ? ($_GET['portal'] ?? $_POST['portal']) : 'customer';
$loginUrl = BASE_URL . ['customer' => '/login.php', 'staff' => '/staff/login.php', 'admin' => '/admin/login.php'][$kind];
ensure_password_resets_table($pdo);

$error = ''; $link = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $t = $pdo->prepare("SELECT COUNT(*) FROM audit_logs WHERE action = 'reset_failed' AND ip_address = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)");
    $t->execute([$_SERVER['REMOTE_ADDR'] ?? '']);
    if ((int)$t->fetchColumn() >= 10) {
        $error = 'Too many attempts. Please try again in 15 minutes.';
    } else {
        $u = find_user_for_reset($pdo, trim($_POST['identifier'] ?? ''), trim($_POST['email'] ?? ''), $kind);
        if (!$u) {
            audit($pdo, null, 'reset_failed', 'user', null, substr(trim($_POST['identifier'] ?? ''), 0, 100));
            $error = 'We could not match those details. Check them and try again.';
        } else {
            $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$u['id']]);
            $token = bin2hex(random_bytes(24));
            $pdo->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?,?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))')
                ->execute([$u['id'], hash('sha256', $token)]);
            audit($pdo, (int)$u['id'], 'reset_requested', 'user', (int)$u['id']);
            $link = BASE_URL . '/reset_password.php?portal=' . $kind . '&token=' . $token;
        }
    }
}
auth_start($kind, 'Reset password', ['Back to sign in', $loginUrl]);
?>
      <h2 class="au-title">Reset password</h2>
      <?php if ($link): ?>
        <p class="au-lead">Account verified. Use the link below within 30 minutes to choose a new password.</p>
        <a class="au-btn" style="display:block;text-align:center;text-decoration:none" href="<?= e($link) ?>">Set a new password</a>
        <p class="au-hint">Demo prototype: a real system would email this link instead of showing it here.</p>
      <?php else: ?>
        <p class="au-lead">Enter your details exactly as registered.</p>
        <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
        <form method="post">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="portal" value="<?= e($kind) ?>">
          <div class="au-field">
            <label for="identifier"><?= $kind === 'customer' ? 'CUSTOMER ID, MOBILE OR EMAIL' : 'EMPLOYEE ID OR WORK EMAIL' ?></label>
            <input type="text" id="identifier" name="identifier" required autofocus>
          </div>
          <div class="au-field">
            <label for="email">REGISTERED EMAIL</label>
            <input type="email" id="email" name="email" required>
          </div>
          <button class="au-btn" type="submit">Continue <span>→</span></button>
        </form>
      <?php endif; ?>
<?php auth_end();
