<?php
// includes/auth_layout.php - split-screen layout for login / sign up / welcome pages
// auth_start('customer'|'staff'|'admin', 'Page title', ['Link text', 'href'] or null) ... auth_end()

function auth_password_field(string $id, string $label, string $placeholder = ''): void { ?>
    <div class="au-field">
      <label for="<?= e($id) ?>"><?= e($label) ?></label>
      <input type="password" id="<?= e($id) ?>" name="<?= e($id) ?>" placeholder="<?= e($placeholder) ?>" required>
      <button class="au-eye" type="button" data-target="<?= e($id) ?>">Show</button>
    </div>
<?php }

function auth_start(string $variant, string $title, ?array $topLink = null): void {
    $b = BASE_URL;
    $cfg = [
        'customer' => [
            'badge'    => 'CUSTOMER PORTAL',
            'headline' => 'Your next step,<br>financed.',
            'sub'      => 'FinBridge is a finance company offering personal, home, vehicle, education, business and consumer durable loans. Apply online, upload your documents and follow every decision in one place.',
            'chips'    => ['Apply online', 'Track every step', 'Six loan types', 'Clear EMI details'],
        ],
        'staff' => [
            'badge'    => 'STAFF PORTAL',
            'headline' => 'Review. Decide.<br>Serve.',
            'sub'      => 'The FinBridge portal for branch officers, branch managers and the accounts team. Review applications, record decisions and manage disbursement.',
            'chips'    => ['Review queue', 'Priority cases', 'Decisions on record', 'Full audit trail'],
        ],
        'admin' => [
            'badge'    => 'ADMINISTRATION',
            'headline' => 'Every branch,<br>one view.',
            'sub'      => 'Manage branches, employees and loan products, and monitor applications across Chennai, Coimbatore and Madurai.',
            'chips'    => ['All branches', 'Employee accounts', 'Loan products', 'Reports'],
        ],
    ];
    $c = $cfg[$variant] ?? $cfg['customer'];
    $GLOBALS['au_variant'] = $variant;
    ?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= $b ?>/assets/css/auth.css">
</head>
<body class="au au-<?= e($variant) ?>">
<div class="au-shell">

  <section class="au-hero">
    <div class="au-orb au-orb1"></div><div class="au-orb au-orb2"></div>
    <span class="au-badge"><?= e($c['badge']) ?></span>
    <h2 class="au-headline"><?= $c['headline'] ?></h2>
    <p class="au-sub"><?= e($c['sub']) ?></p>
    <ul class="au-chips"><?php foreach ($c['chips'] as $chip): ?><li><?= e($chip) ?></li><?php endforeach; ?></ul>

    <div class="au-stage" aria-hidden="true">
      <div class="au-device"><div class="au-notch"></div><div class="au-screen">
        <?php if ($variant === 'staff'): ?>
          <div class="au-scr-top"><span>Review queue</span><span class="au-pill">3 new</span></div>
          <div class="au-q"><b>FB-0012 · Personal Loan</b><span>Priority review</span><em>Under review</em></div>
          <div class="au-q"><b>FB-0013 · Vehicle Loan</b><span>Documents received</span><em>Ready to forward</em></div>
          <div class="au-q"><b>FB-0014 · Home Loan</b><span>Waiting for customer</span><em>Documents required</em></div>
          <div class="au-prog" style="margin-top:14px"><i class="on"></i><i class="on"></i><i></i><i></i></div>
        <?php elseif ($variant === 'admin'): ?>
          <div class="au-scr-top"><span>Overview</span><span class="au-pill">3 branches</span></div>
          <div class="au-tiles">
            <div class="au-tile"><b>128</b>Applications</div><div class="au-tile"><b>12</b>Staff</div>
            <div class="au-tile"><b>6</b>Loan types</div><div class="au-tile"><b>3</b>Branches</div>
          </div>
          <div class="au-bars"><i style="height:40%"></i><i style="height:62%"></i><i style="height:48%"></i><i style="height:80%"></i><i style="height:66%"></i><i style="height:92%"></i></div>
        <?php else: ?>
          <div class="au-scr-top"><span>FinBridge</span><span class="au-pill">Approved</span></div>
          <div class="au-scr-label">Loan amount</div>
          <div class="au-scr-amt">₹2,50,000</div>
          <div class="au-bars"><i style="height:35%"></i><i style="height:55%"></i><i style="height:45%"></i><i style="height:70%"></i><i style="height:60%"></i><i style="height:88%"></i></div>
          <div class="au-scr-row"><span>Next EMI</span><b>₹8,334</b></div>
          <div class="au-prog"><i class="on"></i><i class="on"></i><i class="on"></i><i></i></div>
        <?php endif; ?>
      </div></div>
      <?php if ($variant === 'staff'): ?>
        <div class="au-float au-f1">✓ Documents checked</div><div class="au-float au-f2">Manager decision</div>
      <?php elseif ($variant === 'admin'): ?>
        <div class="au-float au-f1">✓ 3 branches live</div><div class="au-float au-f2">Employee accounts</div>
      <?php else: ?>
        <div class="au-float au-f1">✓ Documents received</div><div class="au-float au-f2">EMI ₹8,334 / month</div>
      <?php endif; ?>
    </div>
  </section>

  <section class="au-panel">
    <div class="au-top">
      <a class="au-logo" href="<?= $b ?>/index.php"><i>F</i><?= APP_NAME ?></a>
      <?php if ($topLink): ?><a class="au-toplink" href="<?= e($topLink[1]) ?>"><?= e($topLink[0]) ?></a><?php endif; ?>
    </div>
    <div class="au-body">
<?php
}

function auth_end(): void {
    $v = $GLOBALS['au_variant'] ?? 'customer';
    ?>
    </div>
    <div class="au-foot"><span>© <?= date('Y') ?> <?= APP_NAME ?>. Demo prototype.</span><a href="#" data-modal="contact">Contact Us</a></div>
  </section>
</div>

<div class="au-modal" id="auModal">
  <div class="au-modal-card" data-key="contact" hidden>
    <h3>Contact FinBridge</h3>
    <p><strong>Email:</strong> support@finbridge.test</p>
    <p><strong>Phone:</strong> 1800-000-0000 (demo number)</p>
    <p><strong>Branches:</strong> Chennai, Coimbatore and Madurai</p>
    <p><strong>Hours:</strong> Monday to Saturday, 9:30 AM to 5:30 PM</p>
    <p class="au-hint" style="text-align:left">FinBridge is a demo prototype. These details are fictional.</p>
    <button class="au-btn" type="button" data-close>Close</button>
  </div>
  <div class="au-modal-card" data-key="forgot" hidden>
    <h3>Forgot your password?</h3>
    <p>Verify your account details and we will give you a link to set a new password.</p>
    <a class="au-btn" style="display:block;text-align:center;text-decoration:none" href="<?= BASE_URL ?>/forgot_password.php?portal=<?= e($v) ?>">Reset my password</a>
    <button class="au-btn" type="button" data-close style="margin-top:10px">Cancel</button>
  </div>
</div>

<script>
(function () {
  var m = document.getElementById('auModal');
  function openModal(k) {
    m.querySelectorAll('[data-key]').forEach(function (c) { c.hidden = c.dataset.key !== k; });
    m.classList.add('show');
  }
  function closeModal() { m.classList.remove('show'); }
  document.querySelectorAll('[data-modal]').forEach(function (a) {
    a.addEventListener('click', function (e) { e.preventDefault(); openModal(a.dataset.modal); });
  });
  m.addEventListener('click', function (e) { if (e.target === m || e.target.hasAttribute('data-close')) closeModal(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
  document.querySelectorAll('.au-eye').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var i = document.getElementById(btn.dataset.target), show = i.type === 'password';
      i.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Hide' : 'Show';
    });
  });
})();
</script>
</body></html>
<?php
}
