<?php
// includes/header.php - page_header() prints the top bar, nav and <h1>
function page_header(string $title, bool $showTitle = true): void {
    global $pdo;
    $u = current_user();
    if ($u && $u['role'] === 'customer') { customer_layout_header($title, $showTitle); return; }
    $branch = '';
    if ($u && $u['branch_id']) {
        $s = $pdo->prepare('SELECT name FROM branches WHERE id = ?');
        $s->execute([$u['branch_id']]);
        $branch = (string)$s->fetchColumn();
    }
    $nav = [
        'customer' => [
            ['/customer/dashboard.php', 'Dashboard'],
            ['/customer/apply.php', 'Apply for Loan'],
            ['/customer/applications.php', 'My Applications'],
            ['/customer/documents.php', 'Documents'],
            ['/customer/loan_account.php', 'Loan Account'],
        ],
        'branch_officer' => [
            ['/staff/officer_dashboard.php', 'Dashboard'],
            ['/staff/applications.php', 'Applications'],
        ],
        'branch_manager' => [
            ['/staff/manager_dashboard.php', 'Dashboard'],
            ['/staff/applications.php', 'Applications'],
            ['/staff/manager_queue.php', 'Decision Queue'],
        ],
        'accounts_officer' => [
            ['/accounts/dashboard.php', 'Dashboard'],
            ['/accounts/disbursements.php', 'Disbursements'],
            ['/accounts/loan_accounts.php', 'Loan Accounts'],
            ['/accounts/repayments.php', 'Repayments'],
        ],
        'admin' => [
            ['/admin/dashboard.php', 'Dashboard'],
            ['/admin/overview.php', 'Overview'],
            ['/admin/branches.php', 'Branches'],
            ['/admin/employees.php', 'Employees'],
            ['/admin/loan_products.php', 'Loan Products'],
        ],
    ];
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
       . '<meta name="viewport" content="width=device-width, initial-scale=1">'
       . '<title>' . e($title) . ' - ' . APP_NAME . '</title>'
       . '<link rel="stylesheet" href="' . BASE_URL . '/assets/css/style.css"></head><body>';
    echo '<header class="topbar"><strong>' . APP_NAME . '</strong><span>';
    if ($u) {
        echo e($u['name']) . ' (' . e(str_replace('_', ' ', $u['role'])) . ($branch ? ' - ' . e($branch) : '') . ') '
           . '<a href="' . BASE_URL . '/change_password.php">Change password</a> '
           . '<a href="' . BASE_URL . '/logout.php">Logout</a>';
    }
    echo '</span></header>';
    if ($u && isset($nav[$u['role']])) {
        echo '<nav class="nav">';
        foreach ($nav[$u['role']] as [$href, $label]) {
            echo '<a href="' . BASE_URL . $href . '">' . e($label) . '</a>';
        }
        echo '</nav>';
    }
    echo '<main class="container"><h1>' . e($title) . '</h1>';
}


// ---------- Customer portal layout (sidebar design) ----------
function customer_layout_header(string $title, bool $showTitle = true): void {
    global $pdo;
    $u = current_user();
    $b = BASE_URL;
    $GLOBALS['cx_layout'] = true;

    $s = $pdo->prepare('SELECT customer_code FROM customers WHERE user_id = ?');
    $s->execute([$u['id']]);
    $code = (string)$s->fetchColumn();
    $n = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
    $n->execute([$u['id']]);
    $unread = (int)$n->fetchColumn();

    $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if ($script === 'application_details.php') $script = 'applications.php';

    // [group, link text, icon, href or null, file for highlight, toast message]
    $menu = [
        'MAIN MENU' => [
            ['Dashboard', '▦', '/customer/dashboard.php', 'dashboard.php'],
            ['Apply for a Loan', '＋', '/customer/apply.php', 'apply.php'],
            ['My Applications', '▤', '/customer/applications.php', 'applications.php'],
            ['Track Application', '◷', '/customer/applications.php', 'applications.php'],
            ['My Documents', '▧', '/customer/documents.php', 'documents.php'],
        ],
        'MY FINANCES' => [
            ['My Loan Account', '▣', '/customer/loan_account.php', 'loan_account.php'],
            ['EMI Schedule', '▦', '/customer/emi_schedule.php', 'emi_schedule.php'],
            ['Payment History', '↻', '/customer/payment_history.php', 'payment_history.php'],
        ],
        'ACCOUNT' => [
            ['Notifications', '♧', '/customer/notifications.php', 'notifications.php'],
            ['Help & Support', 'ⓘ', null, null, 'Customer support will be added in a later phase.'],
            ['My Profile', '◎', null, null, 'The profile page will be added in a later phase.'],
        ],
    ];
    ?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= $b ?>/assets/css/style.css">
<link rel="stylesheet" href="<?= $b ?>/assets/css/customer.css">
<link rel="stylesheet" href="<?= $b ?>/assets/css/apply-wizard.css">
</head>
<body class="cx">
<div class="cx-app">
  <div class="cx-overlay" id="cxOverlay"></div>
  <aside class="cx-sidebar" id="cxSidebar">
    <a class="cx-brand" href="<?= $b ?>/customer/dashboard.php">
      <div class="cx-brand-mark">F</div>
      <div><div class="cx-brand-name"><?= APP_NAME ?></div><div class="cx-brand-tagline">FINANCIAL SOLUTIONS</div></div>
    </a>
    <?php $matched = false; foreach ($menu as $group => $items): ?>
      <div class="cx-nav-label"><?= e($group) ?></div>
      <?php foreach ($items as $it):
          $isLink = $it[2] !== null;
          $active = $isLink && !$matched && $it[3] === $script;
          if ($active) $matched = true; ?>
        <?php if ($isLink): ?>
          <a class="cx-nav-link<?= $active ? ' active' : '' ?>" href="<?= $b . e($it[2]) ?>"><span class="cx-nav-icon"><?= $it[1] ?></span> <?= e($it[0]) ?></a>
        <?php else: ?>
          <a class="cx-nav-link" href="#" data-message="<?= e($it[4]) ?>"><span class="cx-nav-icon"><?= $it[1] ?></span> <?= e($it[0]) ?></a>
        <?php endif; ?>
      <?php endforeach; ?>
    <?php endforeach; ?>
    <a class="cx-nav-link" href="<?= $b ?>/logout.php"><span class="cx-nav-icon">⏻</span> Logout</a>

    <div class="cx-help">
      <strong>Need assistance?</strong>
      <p>Our support team is here to help with your application.</p>
      <a href="#" class="cx-help-link" data-message="Customer support will be added in a later phase.">Get Support →</a>
    </div>
  </aside>

  <main class="cx-main">
    <header class="cx-topbar">
      <div class="cx-breadcrumb">Customer Portal &nbsp; / &nbsp; <strong><?= e($title) ?></strong></div>
      <div class="cx-top-actions">
        <button class="cx-icon-btn cx-menu-btn" id="cxMenuBtn" type="button" aria-label="Show navigation">☰</button>
        <a class="cx-icon-btn" href="<?= $b ?>/customer/notifications.php" aria-label="Notifications">♧<?= $unread ? '<span class="cx-dot"></span>' : '' ?></a>
        <div class="cx-profile">
          <div class="cx-avatar"><?= e(strtoupper(mb_substr($u['name'], 0, 1))) ?></div>
          <div class="cx-profile-details">
            <div class="cx-profile-name"><?= e($u['name']) ?></div>
            <div class="cx-profile-role">Customer ID: <?= e($code) ?></div>
          </div>
        </div>
      </div>
    </header>
    <div class="cx-content">
<?php if ($showTitle) echo '<h1 class="cx-title">' . e($title) . '</h1>'; ?>
<?php
}
