<?php
// includes/functions.php - helpers: output, auth, CSRF, audit, loans

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function current_user(): ?array { return $_SESSION['user'] ?? null; }

function require_login(): void {
    if (!current_user()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function require_role(array $roles): void {
    if (!current_user()) {
        // send people to the right login page for the area they tried to open
        $to = '/login.php';
        if ($roles === ['admin']) $to = '/admin/login.php';
        elseif (!in_array('customer', $roles, true)) $to = '/staff/login.php';
        header('Location: ' . BASE_URL . $to);
        exit;
    }
    if (!in_array(current_user()['role'], $roles, true)) {
        http_response_code(403);
        exit('Access denied.');
    }
}

function redirect_to_home(): void {
    $role = current_user()['role'] ?? '';
    header('Location: ' . BASE_URL . (ROLE_HOME[$role] ?? '/login.php'));
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400);
        exit('Invalid request.');
    }
}

function audit(PDO $pdo, ?int $userId, string $action, ?string $entity = null, ?int $entityId = null, ?string $details = null): void {
    $pdo->prepare('INSERT INTO audit_logs (user_id, action, entity, entity_id, details, ip_address) VALUES (?,?,?,?,?,?)')
        ->execute([$userId, $action, $entity, $entityId, $details, $_SERVER['REMOTE_ADDR'] ?? null]);
}

// ---------- Loan helpers ----------
// includes/loan_helpers.php - shared loan logic

const STATUS_LABELS = [
    'draft' => 'Draft', 'submitted' => 'Submitted', 'documents_required' => 'Documents Required',
    'under_review' => 'Under Review', 'pending_manager_decision' => 'Pending Manager Decision',
    'approved' => 'Approved', 'rejected' => 'Rejected', 'withdrawn' => 'Withdrawn',
    'agreement_pending' => 'Agreement Pending', 'ready_for_disbursement' => 'Ready for Disbursement',
    'disbursement_failed' => 'Disbursement Failed', 'active' => 'Active Loan', 'closed' => 'Closed',
];

function status_badge(string $s): string {
    return '<span class="badge badge-' . e($s) . '">' . e(STATUS_LABELS[$s] ?? $s) . '</span>';
}

function money($v): string { return '₹' . number_format((float)$v, 2); }

// Reducing-balance EMI: P*r*(1+r)^n / ((1+r)^n - 1)
function calc_emi(float $principal, float $annualRate, int $months): float {
    if ($months <= 0) return 0;
    $r = $annualRate / 12 / 100;
    if ($r == 0) return round($principal / $months, 2);
    $f = pow(1 + $r, $months);
    return round($principal * $r * $f / ($f - 1), 2);
}

function customer_id_for_user(PDO $pdo, int $userId): ?int {
    $s = $pdo->prepare('SELECT id FROM customers WHERE user_id = ?');
    $s->execute([$userId]);
    $id = $s->fetchColumn();
    return $id ? (int)$id : null;
}

// Officer in the branch with the fewest open applications
function pick_officer(PDO $pdo, int $branchId): ?int {
    $s = $pdo->prepare(
        "SELECT u.id FROM users u
         LEFT JOIN loan_applications a ON a.assigned_officer_id = u.id
              AND a.status IN ('submitted','documents_required','under_review')
         WHERE u.role = 'branch_officer' AND u.branch_id = ? AND u.is_active = 1
         GROUP BY u.id ORDER BY COUNT(a.id), u.id LIMIT 1"
    );
    $s->execute([$branchId]);
    $id = $s->fetchColumn();
    return $id ? (int)$id : null;
}

function log_status(PDO $pdo, int $appId, ?string $from, string $to, int $by, ?string $note = null): void {
    $pdo->prepare('INSERT INTO application_history (application_id, from_status, to_status, changed_by, note) VALUES (?,?,?,?,?)')
        ->execute([$appId, $from, $to, $by, $note]);
}

function notify(PDO $pdo, int $userId, ?int $appId, string $message): void {
    $pdo->prepare('INSERT INTO notifications (user_id, application_id, message) VALUES (?,?,?)')
        ->execute([$userId, $appId, mb_substr($message, 0, 250)]);
}

// For these loans the financed amount = price - down payment
function loan_derived(string $code): ?array {
    return ['DURABLE' => ['product_price', 'down_payment'], 'VEHICLE' => ['vehicle_price', 'down_payment']][$code] ?? null;
}


// ---------- Flash messages (shown once) ----------
function set_flash(string $msg): void { $_SESSION['flash'] = $msg; }
function get_flash(): ?string {
    $m = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $m;
}

// Update an application's status, record who did it, and assign the officer if none yet
function change_status(PDO $pdo, array $app, string $to, int $by, ?string $note = null): void {
    $pdo->prepare('UPDATE loan_applications SET status = ?, assigned_officer_id = COALESCE(assigned_officer_id, ?) WHERE id = ?')
        ->execute([$to, $by, $app['id']]);
    log_status($pdo, (int)$app['id'], $app['status'], $to, $by, $note);
}


// Coloured status pill for the customer portal
function cx_pill(string $status): string {
    $groups = [
        'review' => ['submitted', 'under_review', 'pending_manager_decision'],
        'docs'   => ['documents_required'],
        'good'   => ['approved', 'agreement_pending', 'ready_for_disbursement', 'active', 'closed'],
        'bad'    => ['rejected', 'disbursement_failed', 'withdrawn'],
    ];
    $cls = '';
    foreach ($groups as $g => $list) { if (in_array($status, $list, true)) $cls = ' cx-st-' . $g; }
    return '<span class="cx-status' . $cls . '">' . e(STATUS_LABELS[$status] ?? $status) . '</span>';
}


// ---------- Login (used by the customer, staff and admin login pages) ----------
// $kind: 'customer' | 'staff' | 'admin'. Returns an error message, or redirects on success.
function attempt_login(PDO $pdo, string $ident, string $pass, string $kind): string {
    $roles = $kind === 'customer' ? ['customer']
           : ($kind === 'admin' ? ['admin'] : ['branch_officer', 'branch_manager', 'accounts_officer']);

    // Simple brute-force limit: 10 failed attempts per IP in 15 minutes
    $t = $pdo->prepare("SELECT COUNT(*) FROM audit_logs WHERE action = 'login_failed' AND ip_address = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)");
    $t->execute([$_SERVER['REMOTE_ADDR'] ?? '']);
    if ((int)$t->fetchColumn() >= 10) return 'Too many failed attempts. Please try again in 15 minutes.';

    $cols = 'u.id, u.full_name, u.role, u.branch_id, u.password_hash';
    if ($kind === 'customer') {
        if (preg_match('/^FBC[0-9]{6}$/i', $ident)) {            // Customer ID
            $sql = "SELECT $cols FROM users u JOIN customers c ON c.user_id = u.id WHERE c.customer_code = ? AND u.is_active = 1";
            $key = strtoupper($ident);
        } elseif (preg_match('/^[0-9]{10}$/', $ident)) {         // Mobile number
            $sql = "SELECT $cols FROM users u WHERE u.phone = ? AND u.is_active = 1";
            $key = $ident;
        } else {                                                 // Email
            $sql = "SELECT $cols FROM users u WHERE u.email = ? AND u.is_active = 1";
            $key = $ident;
        }
    } else {
        $cols .= ', u.is_active, u.employee_code';
        if (preg_match('/^[A-Za-z]{3}-[A-Za-z0-9-]+$/', $ident)) { // Employee ID
            $sql = "SELECT $cols FROM users u WHERE u.employee_code = ?";
            $key = strtoupper($ident);
        } else {                                                 // Work email
            $sql = "SELECT $cols FROM users u WHERE u.email = ?";
            $key = $ident;
        }
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$key]);
    $user = $stmt->fetch();

    // wrong role gets the same message, so the page never reveals who has an account
    if ($user && in_array($user['role'], $roles, true) && password_verify($pass, $user['password_hash'])) {
        if (isset($user['is_active']) && !(int)$user['is_active']) {
            return $user['employee_code'] === null
                ? 'Your access request is awaiting administrator approval.'
                : 'This account is disabled. Please contact the administrator.';
        }
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'        => (int)$user['id'],
            'name'      => $user['full_name'],
            'role'      => $user['role'],
            'branch_id' => $user['branch_id'] ? (int)$user['branch_id'] : null,
        ];
        audit($pdo, (int)$user['id'], 'login');
        if ($kind === 'customer' && !empty($_SESSION['finbridge_selected_loan'])) {
            $selected = strtoupper((string)$_SESSION['finbridge_selected_loan']);
            unset($_SESSION['finbridge_selected_loan']);
            $productCheck = $pdo->prepare('SELECT code FROM loan_products WHERE code = ? AND is_active = 1 LIMIT 1');
            $productCheck->execute([$selected]);
            $selected = $productCheck->fetchColumn();
            if ($selected) {
                header('Location: ' . BASE_URL . '/loan.php?type=' . rawurlencode($selected));
                exit;
            }
        }
        redirect_to_home();
    }
    audit($pdo, null, 'login_failed', 'user', null, substr($ident, 0, 100));
    return 'Invalid login details.';
}


// ---------- Employee IDs ----------
// e.g. OFF-CHN-002 (officer, Chennai, 2nd)
function next_employee_code(PDO $pdo, string $role, ?int $branchId): string {
    $prefix = ['branch_officer' => 'OFF', 'branch_manager' => 'MGR', 'accounts_officer' => 'ACC', 'admin' => 'ADM'][$role] ?? 'EMP';
    $bc = 'HO';
    if ($branchId) {
        $s = $pdo->prepare('SELECT code FROM branches WHERE id = ?');
        $s->execute([$branchId]);
        $bc = (string)($s->fetchColumn() ?: 'HO');
    }
    $s = $pdo->prepare("SELECT MAX(CAST(SUBSTRING_INDEX(employee_code, '-', -1) AS UNSIGNED)) FROM users WHERE employee_code LIKE ?");
    $s->execute(["$prefix-$bc-%"]);
    return sprintf('%s-%s-%03d', $prefix, $bc, (int)$s->fetchColumn() + 1);
}


// ---------- Loan accounts and EMI schedule ----------

// The amount actually sanctioned: the manager's approved amount, else what was requested
function sanctioned_amount(PDO $pdo, array $app): float {
    $q = $pdo->prepare("SELECT approved_amount FROM approval_records WHERE application_id = ? AND decision = 'approved' ORDER BY id DESC LIMIT 1");
    $q->execute([$app['id']]);
    $v = $q->fetchColumn();
    return ($v !== false && $v !== null && (float)$v > 0) ? (float)$v : (float)$app['requested_amount'];
}

// Same day next month, clamped to the month's last day (31 Jan -> 28/29 Feb)
function add_months_clamped(DateTimeImmutable $d, int $n): DateTimeImmutable {
    $day = (int)$d->format('j');
    $first = $d->modify('first day of this month')->modify('+' . $n . ' month');
    return $first->setDate((int)$first->format('Y'), (int)$first->format('n'), min($day, (int)$first->format('t')));
}

// Builds the reducing-balance schedule: [[no, due_date, emi, principal, interest, balance_after], ...]
function build_schedule(float $principal, float $annualRate, int $months, DateTimeImmutable $firstDue): array {
    $emi = calc_emi($principal, $annualRate, $months);
    $r = $annualRate / 12 / 100;
    $bal = round($principal, 2);
    $rows = [];
    $anchor = $firstDue;
    for ($i = 1; $i <= $months; $i++) {
        $interest = round($bal * $r, 2);
        if ($i === $months) { $prin = $bal; $thisEmi = round($prin + $interest, 2); }   // last instalment clears the balance exactly
        else { $prin = round($emi - $interest, 2); $thisEmi = $emi; }
        $bal = round($bal - $prin, 2);
        if ($bal < 0) $bal = 0.0;
        $rows[] = [$i, add_months_clamped($anchor, $i - 1)->format('Y-m-d'), $thisEmi, $prin, $interest, $bal];
    }
    return $rows;
}

// Creates the loan account + full schedule for a disbursed application. Safe to call twice. Call inside a transaction.
function create_loan_account(PDO $pdo, array $app, ?DateTimeImmutable $disbursedOn = null): int {
    $ex = $pdo->prepare('SELECT id FROM loan_accounts WHERE application_id = ?');
    $ex->execute([$app['id']]);
    if ($id = $ex->fetchColumn()) return (int)$id;

    $principal = sanctioned_amount($pdo, $app);
    $rate = (float)$app['interest_rate']; $months = (int)$app['tenure_months'];
    $on = $disbursedOn ?? new DateTimeImmutable('today');
    $first = add_months_clamped($on, 1);
    $emi = calc_emi($principal, $rate, $months);

    $pdo->prepare("INSERT INTO loan_accounts (account_no, application_id, customer_id, product_id, principal, interest_rate, tenure_months, emi_amount, first_emi_date, outstanding_balance, status)
                   VALUES (?,?,?,?,?,?,?,?,?,?, 'active')")
        ->execute(['TMP' . bin2hex(random_bytes(8)), $app['id'], $app['customer_id'], $app['product_id'], $principal, $rate, $months, $emi, $first->format('Y-m-d'), $principal]);
    $id = (int)$pdo->lastInsertId();
    $pdo->prepare('UPDATE loan_accounts SET account_no = ? WHERE id = ?')->execute(['LN' . $on->format('Y') . str_pad((string)$id, 6, '0', STR_PAD_LEFT), $id]);

    $ins = $pdo->prepare("INSERT INTO repayment_schedule (loan_account_id, installment_no, due_date, emi_amount, principal_part, interest_part, balance_after, status)
                          VALUES (?,?,?,?,?,?,?, 'due')");
    foreach (build_schedule($principal, $rate, $months, $first) as [$no, $due, $e, $pr, $in, $ba]) {
        $ins->execute([$id, $no, $due, $e, $pr, $in, $ba]);
    }
    return $id;
}

// Shared view: account summary + schedule + payments
function render_loan_account(PDO $pdo, array $acct): void {
    $sc = $pdo->prepare('SELECT * FROM repayment_schedule WHERE loan_account_id = ? ORDER BY installment_no');
    $sc->execute([$acct['id']]); $sched = $sc->fetchAll();
    $pay = $pdo->prepare('SELECT p.*, s.installment_no FROM payments p LEFT JOIN repayment_schedule s ON s.id = p.schedule_id WHERE p.loan_account_id = ? ORDER BY p.id DESC');
    $pay->execute([$acct['id']]); $pays = $pay->fetchAll();
    $paid = 0; $next = null;
    foreach ($sched as $r) { if ($r['status'] === 'paid') $paid++; elseif (!$next) $next = $r; }
    ?>
<div class="stats">
  <div class="stat"><b><?= money($acct['principal']) ?></b>Loan amount</div>
  <div class="stat"><b><?= money($acct['outstanding_balance']) ?></b>Outstanding balance</div>
  <div class="stat"><b><?= money($acct['emi_amount']) ?></b>Monthly EMI</div>
  <div class="stat"><b><?= $paid ?> / <?= (int)$acct['tenure_months'] ?></b>EMIs paid</div>
  <div class="stat"><b><?= $next ? e(date('d M Y', strtotime($next['due_date']))) : '-' ?></b>Next due date</div>
</div>
<p class="muted">Account <?= e($acct['account_no']) ?> &middot; <?= e($acct['interest_rate']) ?>% p.a. &middot; <?= (int)$acct['tenure_months'] ?> months &middot; <?= e(ucfirst($acct['status'])) ?></p>
<h3>EMI schedule</h3>
<div class="table-wrap"><table>
  <tr><th>#</th><th>Due date</th><th>EMI</th><th>Principal</th><th>Interest</th><th>Balance after</th><th>Status</th></tr>
  <?php foreach ($sched as $r): ?>
  <tr><td><?= (int)$r['installment_no'] ?></td><td><?= e(date('d M Y', strtotime($r['due_date']))) ?></td><td><?= money($r['emi_amount']) ?></td>
      <td><?= money($r['principal_part']) ?></td><td><?= money($r['interest_part']) ?></td><td><?= money($r['balance_after']) ?></td>
      <td><?= e(ucfirst($r['status'])) ?><?= $r['paid_on'] ? ' <span class="muted">(' . e(date('d M Y', strtotime($r['paid_on']))) . ')</span>' : '' ?></td></tr>
  <?php endforeach; ?>
</table></div>
<h3 style="margin-top:20px">Payment history</h3>
<?php if (!$pays): ?><p class="muted">No payments recorded yet.</p><?php else: ?>
<div class="table-wrap"><table>
  <tr><th>Date</th><th>EMI #</th><th>Amount</th><th>Mode</th><th>Reference</th></tr>
  <?php foreach ($pays as $p): ?>
  <tr><td><?= e($p['paid_at']) ?></td><td><?= $p['installment_no'] ? (int)$p['installment_no'] : '-' ?></td><td><?= money($p['amount']) ?></td><td><?= e($p['mode']) ?></td><td><?= e($p['reference'] ?? '-') ?></td></tr>
  <?php endforeach; ?>
</table></div>
<?php endif;
}


// ---------- Repayments ----------

// Flags unpaid instalments whose due date has passed as overdue, and tells each customer once.
function mark_overdue_installments(PDO $pdo): void {
    $q = $pdo->query("SELECT r.id, r.installment_no, r.emi_amount, la.account_no, la.application_id, c.user_id
                      FROM repayment_schedule r JOIN loan_accounts la ON la.id = r.loan_account_id
                      JOIN customers c ON c.id = la.customer_id
                      WHERE r.status = 'due' AND r.due_date < CURDATE() AND la.status = 'active'");
    foreach ($q->fetchAll() as $r) {
        $up = $pdo->prepare("UPDATE repayment_schedule SET status = 'overdue' WHERE id = ? AND status = 'due'");
        $up->execute([$r['id']]);
        if ($up->rowCount()) notify($pdo, (int)$r['user_id'], (int)$r['application_id'], 'EMI #' . $r['installment_no'] . ' of ' . money($r['emi_amount']) . ' on ' . $r['account_no'] . ' is overdue. Please pay as soon as possible.');
    }
}


// ---------- Employee ID safety (unique index + retry) ----------

// Makes sure users.employee_code has a UNIQUE index (older databases may lack it). Safe to call on every request.
function ensure_employee_code_unique(PDO $pdo): void {
    $q = $pdo->query("SHOW INDEX FROM users WHERE Column_name = 'employee_code' AND Non_unique = 0");
    if (!$q->fetch()) {
        try { $pdo->exec('ALTER TABLE users ADD UNIQUE INDEX employee_code (employee_code)'); } catch (PDOException $e) { /* duplicates exist: fix data first */ }
    }
}

// Generates the next employee code and runs $write($code). If two people got the same code at once the unique
// index rejects the second write, and we simply generate a fresh code and try again (up to 5 times).
function with_unique_employee_code(PDO $pdo, string $role, ?int $branchId, callable $write): string {
    for ($try = 1; ; $try++) {
        $code = next_employee_code($pdo, $role, $branchId);
        try { $write($code); return $code; }
        catch (PDOException $e) {
            $dupCode = $e->getCode() === '23000' && stripos($e->getMessage(), 'employee_code') !== false;
            if (!$dupCode || $try >= 5) throw $e;
        }
    }
}

// ---------- Password reset (demo: the reset link is shown on screen because there is no mail server) ----------

function ensure_password_resets_table(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token_hash CHAR(64) NOT NULL UNIQUE,
        expires_at DATETIME NOT NULL,
        used_at DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_reset_user (user_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
}

function portal_roles(string $kind): array {
    return $kind === 'customer' ? ['customer'] : ($kind === 'admin' ? ['admin'] : ['branch_officer', 'branch_manager', 'accounts_officer']);
}

// Finds the account only when the ID/mobile/email AND the registered email both match
function find_user_for_reset(PDO $pdo, string $ident, string $email, string $kind): ?array {
    if ($kind === 'customer') {
        if (preg_match('/^FBC[0-9]{6}$/i', $ident))      { $sql = 'SELECT u.* FROM users u JOIN customers c ON c.user_id = u.id WHERE c.customer_code = ?'; $key = strtoupper($ident); }
        elseif (preg_match('/^[0-9]{10}$/', $ident))     { $sql = 'SELECT u.* FROM users u WHERE u.phone = ?'; $key = $ident; }
        else                                              { $sql = 'SELECT u.* FROM users u WHERE u.email = ?'; $key = $ident; }
    } else {
        if (preg_match('/^[A-Za-z]{3}-[A-Za-z0-9-]+$/', $ident)) { $sql = 'SELECT u.* FROM users u WHERE u.employee_code = ?'; $key = strtoupper($ident); }
        else                                                      { $sql = 'SELECT u.* FROM users u WHERE u.email = ?'; $key = $ident; }
    }
    $s = $pdo->prepare($sql . ' AND u.is_active = 1');
    $s->execute([$key]);
    $u = $s->fetch();
    if (!$u || !in_array($u['role'], portal_roles($kind), true)) return null;
    return strcasecmp($u['email'], $email) === 0 ? $u : null;
}
