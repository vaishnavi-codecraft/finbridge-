<?php
// includes/site_chrome.php - shared public-site header, footer and icon helpers (home page + loan pages)
function site_icons(): array {
    return [
      'PERSONAL' => '<path d="M12 12a4 4 0 100-8 4 4 0 000 8zM4 20c0-4 3.6-6 8-6s8 2 8 6"/>',
      'HOME'     => '<path d="M3 11l9-7 9 7M5 10v10h14V10M10 20v-6h4v6"/>',
      'VEHICLE'  => '<path d="M4 15l1.5-5A2 2 0 017.4 8.5h9.2a2 2 0 011.9 1.5L20 15M3 15h18v3H3zM7 18v2M17 18v2"/><circle cx="7.5" cy="15" r=".6"/><circle cx="16.5" cy="15" r=".6"/>',
      'EDUCATION'=> '<path d="M2 9l10-5 10 5-10 5zM6 11.5V16c0 1.5 2.7 3 6 3s6-1.5 6-3v-4.5"/>',
      'BUSINESS' => '<path d="M3 9h18v11H3zM8 9V6a2 2 0 012-2h4a2 2 0 012 2v3M3 14h18"/>',
      'DURABLE'  => '<rect x="4" y="3" width="16" height="12" rx="2"/><path d="M8 21h8M12 15v6"/>',
    ];
}
function svgi(array $ic, string $code, int $s = 28): string {
    return '<svg viewBox="0 0 24 24" width="' . $s . '" height="' . $s . '" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($ic[$code] ?? '') . '</svg>';
}
function hm($n): string {
    $n = (float)$n;
    if ($n >= 10000000) return '₹' . rtrim(rtrim(number_format($n / 10000000, 2), '0'), '.') . ' crore';
    if ($n >= 100000)   return '₹' . rtrim(rtrim(number_format($n / 100000, 2), '0'), '.') . ' lakh';
    return '₹' . number_format($n);
}
function yrs(int $m): string { return $m % 12 === 0 ? ($m / 12) . ' yr' . ($m / 12 > 1 ? 's' : '') : $m . ' months'; }
function loan_url(string $code): string {
    // guests sign in (or sign up) first; customers go straight to the loan page inside the portal
    $u = current_user();
    if ($u && $u['role'] === 'customer') return BASE_URL . '/loan.php?type=' . rawurlencode($code);
    return BASE_URL . '/login.php?loan=' . rawurlencode($code);
}

function site_header(array $P): void {
    $B = BASE_URL; $ic = site_icons(); $cat = loan_catalog(); $u = current_user();
    $isCust = $u && $u['role'] === 'customer';
    ?>
<div class="promo" id="promo"><span>✨ Instant indicative offer on every loan. Check your EMI in seconds.</span><button type="button" id="promoX" aria-label="Dismiss">×</button></div>
<header class="hd" id="top">
  <div class="wrap hd-in">
    <a class="logo" href="<?= e($B) ?>/index.php"><span class="logo-mark">F</span><span>FinBridge</span></a>
    <button class="burger" id="burger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
    <nav class="nav" id="nav">
      <div class="mega-wrap">
        <button type="button" class="mega-btn" id="megaBtn" aria-expanded="false">Loans <i>▾</i></button>
        <div class="mega" id="mega" hidden>
          <?php foreach ($P as $c => $p): ?>
          <a href="<?= e(loan_url($c)) ?>"><span class="mg-ic"><?= svgi($ic, $c, 22) ?></span><span><b><?= e($p['name']) ?></b><small>From <?= e($p['interest_rate']) ?>% p.a.</small></span></a>
          <?php endforeach; ?>
        </div>
      </div>
      <a href="<?= e($B) ?>/index.php#calculator">EMI Calculator</a>
      <a href="<?= e($B) ?>/index.php#how">How it works</a>
      <a href="<?= e($B) ?>/index.php#faqs">Help</a>
      <div class="nav-auth">
        <?php if ($isCust): ?>
          <a class="btn btn-line btn-sm" href="<?= e($B) ?>/customer/dashboard.php">My dashboard</a>
          <a class="btn btn-solid btn-sm" href="<?= e($B) ?>/logout.php">Logout</a>
        <?php else: ?>
          <a class="btn btn-line btn-sm" href="<?= e($B) ?>/login.php">Login</a>
          <a class="btn btn-solid btn-sm" href="<?= e($B) ?>/register.php">Sign up</a>
        <?php endif; ?>
      </div>
    </nav>
  </div>
</header>
<?php }

function site_footer(array $P): void {
    $B = BASE_URL; ?>
<footer class="ft" id="contact"><div class="wrap">
  <div class="ft-grid">
    <div><a class="logo logo-w" href="<?= e($B) ?>/index.php"><span class="logo-mark">F</span><span>FinBridge</span></a><p>Clear information. Responsible financing.</p></div>
    <div><h4>Loans</h4><?php foreach ($P as $c => $p): ?><a href="<?= e(loan_url($c)) ?>"><?= e($p['name']) ?></a><?php endforeach; ?></div>
    <div><h4>Customers</h4><a href="<?= e($B) ?>/login.php">Login</a><a href="<?= e($B) ?>/register.php">Sign up</a><a href="<?= e($B) ?>/forgot_password.php">Forgot password</a><a href="<?= e($B) ?>/index.php#calculator">EMI calculator</a></div>
    <div><h4>Staff</h4><a href="<?= e($B) ?>/staff/login.php">Employee login</a><a href="<?= e($B) ?>/admin/login.php">Admin login</a></div>
    <div><h4>Branches</h4><span>Chennai</span><span>Coimbatore</span><span>Madurai</span></div>
  </div>
  <p class="ft-note">FinBridge is a demonstration project for a loan management system. All data is fictional and no real money is lent. Loan amounts, rates and tenure are indicative and subject to eligibility review.</p>
  <p class="ft-copy">© <?= date('Y') ?> FinBridge. All rights reserved.</p>
</div></footer>
<button class="totop" id="toTop" aria-label="Back to top">↑</button>
<div class="help-fab" id="helpFab">
  <div class="help-panel" id="helpPanel" hidden>
    <strong>Hi! How can we help? 👋</strong>
    <a href="<?= e($B) ?>/index.php#types">🏦 Browse loans</a>
    <a href="<?= e($B) ?>/index.php#calculator">🧮 Calculate my EMI</a>
    <a href="<?= e($B) ?>/index.php#faqs">❓ Read FAQs</a>
    <a href="<?= e($B) ?>/login.php">🔐 Customer login</a>
  </div>
  <button type="button" id="helpBtn" aria-expanded="false">💬 Help</button>
</div>
<script src="<?= e($B) ?>/assets/js/site.js"></script>
<?php }
