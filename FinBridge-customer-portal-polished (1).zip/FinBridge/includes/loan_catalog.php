<?php
// includes/loan_catalog.php - per-loan content for the public loan pages (titles, choices, perks, steps).
// 'choices' map to existing application fields so the selection pre-fills the application form.
function loan_catalog(): array {
    $std = fn(string $t2, string $d2) => [
        ['Personal & employment details', 'Tell us a bit about yourself, your work and your income.'],
        [$t2, $d2],
        ['See your indicative offer', 'Get an instant EMI estimate and eligibility check. No hard enquiry.'],
        ['Upload your documents', 'Add your KYC and loan documents online, from home.'],
        ['Review, submit & track', 'Submit for branch review and follow every decision from your dashboard.'],
    ];
    return [
    'VEHICLE' => [
        'emoji' => '🚗', 'tag' => 'VEHICLE LOAN', 'headline' => 'Drive home your dream ride',
        'sub' => 'Two-wheeler, car or commercial vehicle. New or used, we finance it with a simple, fast process.',
        'choices' => [
            ['label' => 'What are you buying?', 'field' => 'vehicle_type', 'opts' => ['two_wheeler' => ['Two-wheeler', '🏍️'], 'car' => ['Car', '🚗'], 'commercial' => ['Commercial', '🚚']]],
            ['label' => 'New or used?', 'field' => 'vehicle_condition', 'opts' => ['new' => ['New', '✨'], 'used' => ['Used', '🔁']]],
        ],
        'perks' => [['⚡', 'Quick processing', 'Indicative offer in minutes'], ['🛣️', 'Flexible tenure', 'Pick a repayment plan that fits'], ['🔁', 'New or used', 'Finance either kind of vehicle'], ['📄', 'Minimal paperwork', 'Upload everything online']],
        'steps' => $std('Add vehicle and dealer details', 'Tell us about the vehicle, its price, your down payment and the dealer.'),
        'docs' => ['Identity proof (Aadhaar / Passport)', 'PAN card', 'Address proof', 'Income proof / bank statement', 'Vehicle quotation or invoice'],
    ],
    'HOME' => [
        'emoji' => '🏠', 'tag' => 'HOME LOAN', 'headline' => 'Build the home you have dreamed of',
        'sub' => 'Buy, build or renovate with long tenures, a clear repayment plan and a guided online process.',
        'choices' => [
            ['label' => 'What do you need the loan for?', 'field' => 'property_type', 'opts' => ['purchase' => ['Buy a home', '🔑'], 'construction' => ['Construction', '🏗️'], 'renovation' => ['Renovation', '🛠️']]],
        ],
        'perks' => [['📆', 'Long tenures', 'Affordable monthly EMIs'], ['🏡', 'Buy, build, renovate', 'One loan for every home plan'], ['🔍', 'Transparent terms', 'See rate and tenure upfront'], ['🧭', 'Track online', 'Status updates in your dashboard']],
        'steps' => $std('Add property details', 'Tell us about the property or project, its value, stage and location.'),
        'docs' => ['Identity proof (Aadhaar / Passport)', 'PAN card', 'Address proof', 'Income proof / bank statement', 'Property papers'],
    ],
    'EDUCATION' => [
        'emoji' => '🎓', 'tag' => 'EDUCATION LOAN', 'headline' => 'Study first, repay later',
        'sub' => 'Cover course fees and related costs with repayment terms designed around a student’s timeline.',
        'choices' => [],
        'perks' => [['🎓', 'Course fee cover', 'Tuition and related costs'], ['⏳', 'Student-friendly terms', 'Repayment planned around your course'], ['👨‍👩‍👧', 'Co-applicant option', 'Parents can support your application'], ['📄', 'Simple documents', 'Admission letter and fee structure']],
        'steps' => $std('Add course and institution details', 'Tell us about your course, its duration, the total fee and your institution.'),
        'docs' => ['Identity proof (Aadhaar / Passport)', 'PAN card', 'Address proof', 'Admission letter', 'Fee structure'],
    ],
    'BUSINESS' => [
        'emoji' => '💼', 'tag' => 'BUSINESS LOAN', 'headline' => 'Capital for your next stage',
        'sub' => 'Working capital, equipment or expansion: fuel the growth of your business with simple income checks.',
        'choices' => [
            ['label' => 'What will you use it for?', 'field' => 'business_purpose', 'opts' => ['working_capital' => ['Working capital', '💰'], 'equipment' => ['Equipment', '⚙️'], 'expansion' => ['Expansion', '📈']]],
        ],
        'perks' => [['💰', 'Working capital', 'Keep operations running smoothly'], ['⚙️', 'Equipment finance', 'Upgrade machinery and tools'], ['📈', 'Growth funding', 'Expand to new locations'], ['🧾', 'Simple checks', 'Business and income verification']],
        'steps' => $std('Add business details', 'Tell us about your business type, years in business and annual turnover.'),
        'docs' => ['Identity proof (Aadhaar / Passport)', 'PAN card', 'Business registration', 'Bank statements', 'Income / turnover proof'],
    ],
    'DURABLE' => [
        'emoji' => '📺', 'tag' => 'CONSUMER DURABLE LOAN', 'headline' => 'Upgrade today, pay monthly',
        'sub' => 'Bring home TVs, refrigerators, phones and more with a small down payment and easy instalments.',
        'choices' => [],
        'perks' => [['🛒', 'Shop what you love', 'Appliances, gadgets and more'], ['💳', 'Small down payment', 'Spread the rest over easy EMIs'], ['⚡', 'Fast approval', 'Quick online process'], ['📄', 'Few documents', 'Invoice or quotation and KYC']],
        'steps' => $std('Add product and dealer details', 'Tell us about the product, its price, your down payment and the dealer.'),
        'docs' => ['Identity proof (Aadhaar / Passport)', 'PAN card', 'Address proof', 'Income proof / bank statement', 'Invoice or quotation'],
    ],
    'PERSONAL' => [
        'emoji' => '💸', 'tag' => 'PERSONAL LOAN', 'headline' => 'Money when life needs it',
        'sub' => 'No collateral and minimal paperwork. For weddings, travel, medical needs or anything in between.',
        'choices' => [
            ['label' => 'What is the loan for?', 'field' => 'purpose_type', 'opts' => ['medical' => ['Medical', '🏥'], 'wedding' => ['Wedding', '💍'], 'travel' => ['Travel', '✈️'], 'home_improvement' => ['Home upgrade', '🛋️']]],
        ],
        'perks' => [['🔓', 'No collateral', 'No security needed'], ['🕒', 'Quick decision', 'Guided online application'], ['🎯', 'Use it your way', 'Weddings, travel, medical and more'], ['📄', 'Minimal paperwork', 'Identity, address and income proof']],
        'steps' => $std('Tell us your purpose', 'Tell us what the loan is for and how much you need.'),
        'docs' => ['Identity proof (Aadhaar / Passport)', 'PAN card', 'Address proof', 'Income proof / bank statement'],
    ],
    ];
}
