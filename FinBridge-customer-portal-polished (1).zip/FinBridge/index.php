<?php
// FinBridge public home page. Login / Sign up buttons are in the header; every loan opens its own loan page.
require __DIR__ . '/includes/bootstrap.php';
if (current_user()) redirect_to_home();

$rows = $pdo->query("SELECT code, name, min_amount, max_amount, interest_rate, min_tenure_months, max_tenure_months FROM loan_products WHERE is_active = 1 ORDER BY id")->fetchAll();
$P = []; foreach ($rows as $r) $P[$r['code']] = $r;
$emo = ['PERSONAL'=>'💸','HOME'=>'🏠','VEHICLE'=>'🚗','EDUCATION'=>'🎓','BUSINESS'=>'💼','DURABLE'=>'📺'];

$blurb = [
  'PERSONAL' => 'No collateral, minimal paperwork. For weddings, travel, medical needs or anything in between.',
  'HOME'     => 'Buy, build or renovate your home with long tenures and a clear repayment plan.',
  'VEHICLE'  => 'Finance a two-wheeler, car or commercial vehicle with a simple, fast process.',
  'EDUCATION'=> 'Fund your course fees with repayment terms designed around a student’s timeline.',
  'BUSINESS' => 'Working capital, equipment or expansion: fuel the next stage of your business.',
  'DURABLE'  => 'Bring home appliances and gadgets today and pay in easy monthly instalments.',
];
$needs = [  // tab label, product code, headline, bullets
  ['Buy a house',        'HOME',     'Build your dream home',            ['Purchase, construction or renovation', 'Long tenure, affordable EMIs']],
  ['Buy a vehicle',      'VEHICLE',  'Drive home your dream ride',       ['Two-wheelers, cars and commercial vehicles', 'New or used, quick processing']],
  ['Higher studies',     'EDUCATION','Study first, repay later',         ['Cover course fees and related costs', 'Repayment planned around your course']],
  ['Grow my business',   'BUSINESS', 'Capital for your next stage',      ['Working capital, equipment or expansion', 'Simple income and business checks']],
  ['Buy gadgets & appliances', 'DURABLE', 'Upgrade today, pay monthly',  ['TVs, refrigerators, phones and more', 'Small down payment, easy instalments']],
  ['Personal needs',     'PERSONAL', 'Money when life needs it',        ['No collateral required', 'Weddings, travel, medical and more']],
];
$loginUrl = fn(string $code) => loan_url($code);   // every loan opens its own loan page (mobile + OTP first)

$B = BASE_URL;
$faqs = [
  ['What types of loans does FinBridge offer?', 'FinBridge offers six loan types: Personal, Home / Construction, Vehicle, Education, Business and Consumer Durable loans.'],
  ['How do I apply for a loan?', 'Pick a loan on this page, verify your mobile number with an OTP, then log in or sign up to follow the guided steps: enter your details, see your indicative offer, upload documents and submit.'],
  ['How long does a decision take?', 'Your application goes to the branch matched to your PIN code. An officer verifies your documents and a manager approves the loan. You can follow every status change from your dashboard.'],
  ['Are interest rates fixed?', 'Rates shown on this page are indicative and depend on the loan type and your profile. The final rate is confirmed in your sanction letter.'],
  ['What documents do I need?', 'Typically identity proof, address proof and income proof. Each loan adds its own documents, for example property papers for a home loan or an admission letter for an education loan.'],
  ['Is applying a guarantee of approval?', 'No. An eligibility check is only indicative. Approval depends on document verification and manager review.'],
];
$ic = site_icons();
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0b1f5c">
<title>FinBridge Loans | Finance every dream</title>
<link rel="stylesheet" href="<?= e($B) ?>/assets/css/home.css">
</head>
<body>
<?php site_header($P); ?>

<section class="hero">
  <span class="blob b1"></span><span class="blob b2"></span>
  <span class="fl f1">🚗</span><span class="fl f2">🏠</span><span class="fl f3">🎓</span><span class="fl f4">💼</span>
  <div class="wrap hero-in">
    <div class="hero-copy">
      <span class="eyebrow">TRUSTED DIGITAL LENDING</span>
      <h1>Finance every dream<br>with <span id="typed" data-words="FinBridge|confidence|ease|clarity">FinBridge</span></h1>
      <p>Personal, home, vehicle, education, business and consumer durable loans. Apply online, upload documents and follow every decision in one place.</p>
      <div class="chips"><span>Digital process</span><span>Flexible repayments</span><span>Transparent terms</span></div>
      <div class="hero-cta">
        <a class="btn btn-solid btn-lg" href="#types">Explore loans →</a>
        <a class="btn btn-line btn-lg" href="#calculator">Calculate EMI</a>
        <a class="btn btn-ghost" href="<?= e($B) ?>/login.php">I already have an account</a>
      </div>
    </div>

    <aside class="qo" id="qo">
      <div class="qo-head"><span>⚡</span><div><h2>Get an instant estimate</h2><p>Pick a loan, set an amount, see your EMI</p></div></div>
      <div class="qo-chips" id="qoChips">
        <?php $i = 0; foreach ($P as $c => $p): ?><button type="button" class="qo-chip<?= $i++ === 0 ? ' on' : '' ?>" data-c="<?= e($c) ?>"><span><?= $emo[$c] ?? '💰' ?></span><?= e(str_replace(' Loan', '', $p['name'])) ?></button><?php endforeach; ?>
      </div>
      <label>Loan amount <b id="qoA"></b></label><input type="range" id="qoAmt">
      <label>Tenure <b id="qoT"></b></label><input type="range" id="qoTen">
      <div class="qo-out"><div><small>Monthly EMI</small><strong id="qoE">-</strong></div><div><small>Rate</small><strong id="qoR">-</strong></div></div>
      <a class="btn btn-solid btn-block" id="qoGo" href="#">Check eligibility →</a>
      <p class="secure">Indicative estimate. Not an offer.</p>
    </aside>
  </div>
</section>

<div class="marq" aria-hidden="true"><div class="marq-in">
  <?php for ($k = 0; $k < 2; $k++): foreach (['⚡ Quick digital process', '🔍 Transparent rates', '📄 Minimal documentation', '🧭 Track every step', '🔒 Secure and private', '🤝 Branch support', '📱 Apply from any device'] as $m): ?><span><?= $m ?></span><?php endforeach; endfor; ?>
</div></div>

<main>
<section class="sec" id="types"><div class="wrap">
  <h2 class="sec-t">Many types of loans</h2>
  <p class="sec-s">Pick the loan that matches your plan. Rates are indicative.</p>
  <div class="tiles">
    <?php foreach ($P as $c => $p): ?>
    <article class="tile rv">
      <span class="tile-top"><span class="tile-ic"><?= svgi($ic, $c) ?></span><span class="tile-em"><?= $emo[$c] ?? '' ?></span></span>
      <h3><?= e($p['name']) ?></h3>
      <p><?= e($blurb[$c] ?? '') ?></p>
      <ul><li>From <b><?= e($p['interest_rate']) ?>% p.a.</b></li><li><?= hm($p['min_amount']) ?> – <?= hm($p['max_amount']) ?></li><li>Up to <?= yrs((int)$p['max_tenure_months']) ?></li></ul>
      <div class="tile-actions"><a class="tile-go" href="<?= e($loginUrl($c)) ?>">Check eligibility <i>→</i></a><a class="tile-secondary" href="<?= e($loginUrl($c)) ?>">Apply now</a></div>
    </article>
    <?php endforeach; ?>
  </div>
</div></section>

<section class="sec sec-tint" id="find"><div class="wrap">
  <h2 class="sec-t">Find a loan as per your need</h2>
  <div class="tabs" role="tablist">
    <?php foreach ($needs as $i => $n): if (!isset($P[$n[1]])) continue; ?>
      <button role="tab" class="tab<?= $i === 0 ? ' on' : '' ?>" data-t="<?= $i ?>"><?= e($n[0]) ?></button>
    <?php endforeach; ?>
  </div>
  <?php foreach ($needs as $i => $n): if (!isset($P[$n[1]])) continue; $p = $P[$n[1]]; ?>
  <div class="panel<?= $i === 0 ? ' on' : '' ?>" data-p="<?= $i ?>">
    <div class="panel-l">
      <span class="tag"><?= e($p['name']) ?></span>
      <h3><?= e($n[2]) ?></h3>
      <ul class="ticks"><?php foreach ($n[3] as $b): ?><li><?= e($b) ?></li><?php endforeach; ?></ul>
      <div class="facts"><div><small>Interest from</small><b><?= e($p['interest_rate']) ?>% p.a.</b></div><div><small>Loan amount</small><b><?= hm($p['min_amount']) ?> – <?= hm($p['max_amount']) ?></b></div><div><small>Tenure</small><b><?= yrs((int)$p['min_tenure_months']) ?> – <?= yrs((int)$p['max_tenure_months']) ?></b></div></div>
      <div class="panel-cta"><a class="btn btn-solid" href="<?= e($loginUrl($n[1])) ?>">Check eligibility →</a><a class="btn btn-line" href="#calculator" data-calc="<?= e($n[1]) ?>">Calculate EMI</a></div>
    </div>
    <div class="panel-r"><span class="big-ic"><?= svgi($ic, $n[1], 96) ?></span><span class="pr-e p1"><?= $emo[$n[1]] ?? '' ?></span><span class="pr-e p2">✨</span><span class="pr-e p3">💙</span></div>
  </div>
  <?php endforeach; ?>
</div></section>

<section class="sec" id="how"><div class="wrap">
  <h2 class="sec-t">Apply in 5 simple steps</h2>
  <p class="sec-s">Tap a step to see what happens.</p>
  <div class="how" id="how5">
    <?php foreach ([['📱','Choose & verify','Pick a loan and verify your mobile number with a one-time password.'],['📝','Share your details','Fill in personal, work and loan details in a guided form.'],['🎯','See your offer','Get an instant EMI estimate and indicative eligibility.'],['📤','Upload documents','Add your KYC and loan documents online.'],['🚀','Submit & track','Your branch reviews it. Follow every status in your dashboard.']] as $i => $h): ?>
      <button type="button" class="how-s<?= $i === 0 ? ' on' : '' ?>" data-i="<?= $i ?>"><span><?= $h[0] ?></span><b><?= $i + 1 ?></b><em><?= e($h[1]) ?></em></button>
    <?php endforeach; ?>
  </div>
  <div class="how-d" id="howD"><h3></h3><p></p></div>
  <script type="application/json" id="howData"><?= json_encode([['Choose & verify','Pick a loan and verify your mobile number with a one-time password.'],['Share your details','Fill in personal, work and loan details in a guided form. You can save a draft and return later.'],['See your offer','Get an instant EMI estimate and an indicative eligibility result before you commit.'],['Upload documents','Add your identity, address, income and loan-specific documents online.'],['Submit & track','Your application goes to the branch for your PIN code. An officer verifies it and a manager decides. Track it all from your dashboard.']], JSON_UNESCAPED_UNICODE) ?></script>
</div></section>

<section class="sec sec-tint" id="why"><div class="wrap">
  <h2 class="sec-t">Why get it from us?</h2>
  <div class="why">
    <div class="rv"><span>⚡</span><h3>Quick process</h3><p>Apply in a few guided steps and see an indicative offer straight away.</p></div>
    <div class="rv"><span>📄</span><h3>Minimal documentation</h3><p>A clear checklist for each loan, and you upload everything online.</p></div>
    <div class="rv"><span>％</span><h3>Transparent rates</h3><p>See rate, amount and tenure before you apply, with a live EMI estimate.</p></div>
    <div class="rv"><span>🧭</span><h3>Track every step</h3><p>Follow your application from submission to disbursement in your dashboard.</p></div>
  </div>
</div></section>

<section class="sec" id="calculator"><div class="wrap">
  <h2 class="sec-t">Need help finding the right EMI?</h2>
  <p class="sec-s">Move the sliders to see your monthly instalment. This is an estimate, not an offer.</p>
  <div class="calc" id="calc">
    <div class="calc-l">
      <label>Loan type</label>
      <select id="cType"><?php foreach ($P as $c => $p): ?><option value="<?= e($c) ?>" data-rate="<?= e($p['interest_rate']) ?>" data-min="<?= (int)$p['min_amount'] ?>" data-max="<?= (int)$p['max_amount'] ?>" data-tmin="<?= (int)$p['min_tenure_months'] ?>" data-tmax="<?= (int)$p['max_tenure_months'] ?>"><?= e($p['name']) ?></option><?php endforeach; ?></select>
      <label>Loan amount <b id="vA"></b></label><input type="range" id="cA">
      <label>Tenure <b id="vT"></b></label><input type="range" id="cT">
      <label>Interest rate <b id="vR"></b></label><input type="range" id="cR" min="6" max="24" step="0.25">
    </div>
    <div class="calc-r">
      <small>Monthly EMI</small><div class="emi" id="oE">-</div>
      <div class="bar"><i id="bP"></i></div>
      <div class="bar-l"><span><i class="d1"></i>Principal <b id="oP"></b></span><span><i class="d2"></i>Interest <b id="oI"></b></span></div>
      <div class="tot">Total payable <b id="oT"></b></div>
      <a class="btn btn-solid btn-block" id="cApply" href="#">Apply for this loan →</a>
    </div>
  </div>
</div></section>

<section class="sec sec-tint" id="voices"><div class="wrap">
  <h2 class="sec-t">What customers could say</h2>
  <p class="sec-s">Sample feedback for this demo. Not real customer reviews.</p>
  <div class="vc" id="vc">
    <?php foreach ([['“The steps were clear and I could see my EMI before applying.”','Sample customer, Chennai','🚗'],['“I uploaded my documents from my phone and tracked every status.”','Sample customer, Coimbatore','🏠'],['“Simple process for my business working-capital loan.”','Sample customer, Madurai','💼']] as $i => $v): ?>
    <figure class="vq<?= $i === 0 ? ' on' : '' ?>"><span><?= $v[2] ?></span><blockquote><?= e($v[0]) ?></blockquote><figcaption><?= e($v[1]) ?></figcaption></figure>
    <?php endforeach; ?>
    <div class="vdots"><button class="on" aria-label="1"></button><button aria-label="2"></button><button aria-label="3"></button></div>
  </div>
</div></section>

<section class="sec" id="about"><div class="wrap">
  <h2 class="sec-t">About loans</h2>
  <div class="acc">
    <details open><summary>Eligibility</summary><p>You should be an Indian resident, at least 18 years old (most loans need 21+), with a regular source of income. Each loan has its own limits on age, income and existing EMIs, and the check on this site is indicative only.</p></details>
    <details><summary>Documentation</summary><p>Identity proof, address proof and income proof are asked for every loan. Business loans add business registration and bank statements; home loans add property papers; education loans add an admission letter and fee structure.</p></details>
    <details><summary>Fees &amp; charges</summary><p>Rates, processing fee and any charges are shown in your sanction letter before you accept. Read it fully before you accept the offer.</p></details>
    <details><summary>Repayment</summary><p>Loans are repaid in monthly instalments (EMI) on a reducing balance. After disbursement you can view your EMI schedule and payment history from your dashboard.</p></details>
  </div>
</div></section>

<section class="sec sec-tint" id="faqs"><div class="wrap">
  <h2 class="sec-t">FAQs</h2>
  <input type="search" id="faqQ" class="faq-q" placeholder="🔎 Search questions">
  <div class="acc" id="faqList"><?php foreach ($faqs as $i => $f): ?><details<?= $i === 0 ? ' open' : '' ?>><summary><?= e($f[0]) ?></summary><p><?= e($f[1]) ?></p></details><?php endforeach; ?></div>
</div></section>

<section class="cta"><div class="wrap cta-in">
  <div><h2>Ready to apply?</h2><p>Create your free account and start in minutes.</p></div>
  <div><a class="btn btn-white" href="<?= e($B) ?>/register.php">Sign up free</a><a class="btn btn-outline-w" href="<?= e($B) ?>/login.php">Login</a></div>
</div></section>
</main>

<?php site_footer($P); ?>

<script>
(function(){
  var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return [].slice.call((c||document).querySelectorAll(s))};
  var BASE='<?= e($B) ?>';
  var inr=function(n){return '₹'+Math.round(n).toLocaleString('en-IN')};
  function emi(P,n,rate){var r=rate/1200,f=Math.pow(1+r,n);return r===0?P/n:P*r*f/(f-1)}
  // typed headline word
  var t=$('#typed'),w=t.dataset.words.split('|'),wi=0;
  setInterval(function(){wi=(wi+1)%w.length;t.style.opacity=0;setTimeout(function(){t.textContent=w[wi];t.style.opacity=1},250)},2600);
  // tabs
  $$('.tab').forEach(function(x){x.onclick=function(){$$('.tab').forEach(function(y){y.classList.remove('on')});$$('.panel').forEach(function(y){y.classList.remove('on')});x.classList.add('on');$('.panel[data-p="'+x.dataset.t+'"]').classList.add('on')}});
  // how it works
  var HD=JSON.parse($('#howData').textContent);
  function how(i){$$('.how-s').forEach(function(s,k){s.classList.toggle('on',k===i);s.classList.toggle('done',k<i)});$('#howD h3').textContent=(i+1)+'. '+HD[i][0];$('#howD p').textContent=HD[i][1]}
  $$('.how-s').forEach(function(s){s.onclick=function(){how(+s.dataset.i)}});how(0);
  // testimonials
  var vq=$$('.vq'),vd=$$('.vdots button'),vi=0,vt;
  function vshow(i){vi=i;vq.forEach(function(q,k){q.classList.toggle('on',k===i)});vd.forEach(function(d,k){d.classList.toggle('on',k===i)})}
  vd.forEach(function(d,k){d.onclick=function(){vshow(k);clearInterval(vt)}});vt=setInterval(function(){vshow((vi+1)%vq.length)},5000);
  // FAQ search
  $('#faqQ').oninput=function(){var q=this.value.toLowerCase();$$('#faqList details').forEach(function(d){d.style.display=d.textContent.toLowerCase().indexOf(q)>-1?'':'none'})};
  // hero quick estimate
  var chips=$$('.qo-chip'),qA=$('#qoAmt'),qT=$('#qoTen'),cur=null;
  var DATA={};<?php foreach ($P as $c => $p): ?>DATA[<?= json_encode($c) ?>]={rate:<?= (float)$p['interest_rate'] ?>,min:<?= (int)$p['min_amount'] ?>,max:<?= (int)$p['max_amount'] ?>,tmin:<?= (int)$p['min_tenure_months'] ?>,tmax:<?= (int)$p['max_tenure_months'] ?>};<?php endforeach; ?>
  function qo(reset){var d=DATA[cur];
    if(reset){qA.min=d.min;qA.max=d.max;qA.step=d.max>1000000?10000:5000;qA.value=Math.round((d.min+d.max)/4/5000)*5000;qT.min=d.tmin;qT.max=d.tmax;qT.step=1;qT.value=Math.min(d.tmax,Math.max(d.tmin,36))}
    var P=+qA.value,n=+qT.value;$('#qoA').textContent=inr(P);$('#qoT').textContent=n%12===0?(n/12)+' yr':n+' mo';
    $('#qoE').textContent=inr(emi(P,n,d.rate));$('#qoR').textContent=d.rate+'% p.a.';$('#qoGo').href=BASE+'/loan.php?type='+encodeURIComponent(cur)}
  chips.forEach(function(c){c.onclick=function(){chips.forEach(function(x){x.classList.remove('on')});c.classList.add('on');cur=c.dataset.c;qo(true)}});
  cur=chips[0].dataset.c;qo(true);qA.oninput=qT.oninput=function(){qo(false)};
  // main EMI calculator
  var T=$('#cType'),A=$('#cA'),M=$('#cT'),R=$('#cR');
  function setType(){var o=T.options[T.selectedIndex],d=o.dataset;
    A.min=d.min;A.max=d.max;A.step=d.max>1000000?10000:5000;M.min=d.tmin;M.max=d.tmax;M.step=1;R.value=d.rate;
    A.value=Math.round((+d.min+ +d.max)/4/5000)*5000;M.value=Math.min(+d.tmax,Math.max(+d.tmin,36));
    $('#cApply').href=BASE+'/loan.php?type='+encodeURIComponent(o.value);calc()}
  function calc(){var P=+A.value,n=+M.value,e=emi(P,n,+R.value),tot=e*n,i=tot-P;
    $('#vA').textContent=inr(P);$('#vT').textContent=(n%12===0?(n/12)+' yr':n+' mo');$('#vR').textContent=(+R.value).toFixed(2)+'% p.a.';
    $('#oE').textContent=inr(e);$('#oP').textContent=inr(P);$('#oI').textContent=inr(i);$('#oT').textContent=inr(tot);$('#bP').style.width=(P/tot*100)+'%'}
  T.onchange=setType;[A,M,R].forEach(function(x){x.oninput=calc});setType();
  $$('[data-calc]').forEach(function(a){a.onclick=function(){T.value=a.dataset.calc;setType()}});
})();
</script>
</body></html>
