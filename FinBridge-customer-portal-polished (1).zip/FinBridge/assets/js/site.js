(function(){
  var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return [].slice.call((c||document).querySelectorAll(s))};
  var mb=$('#megaBtn'),mg=$('#mega');
  if(mb){mb.onclick=function(e){e.stopPropagation();var o=mg.hidden;mg.hidden=!o;mb.setAttribute('aria-expanded',o)};
    document.addEventListener('click',function(e){if(!mg.contains(e.target)){mg.hidden=true;mb.setAttribute('aria-expanded',false)}})}
  var bg=$('#burger');if(bg)bg.onclick=function(){var n=$('#nav'),o=n.classList.toggle('open');this.setAttribute('aria-expanded',o)};
  var px=$('#promoX');if(px)px.onclick=function(){$('#promo').style.display='none'};
  var tt=$('#toTop');window.addEventListener('scroll',function(){if(tt)tt.classList.toggle('show',window.scrollY>600)},{passive:true});
  if(tt)tt.onclick=function(){window.scrollTo({top:0,behavior:'smooth'})};
  var hb=$('#helpBtn'),hp=$('#helpPanel');
  if(hb){hb.onclick=function(e){e.stopPropagation();var o=hp.hidden;hp.hidden=!o;hb.setAttribute('aria-expanded',o)};
    document.addEventListener('click',function(e){if(!hp.contains(e.target)&&e.target!==hb)hp.hidden=true})}
  // scroll reveal
  var rv=$$('.rv');
  if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}})},{threshold:.12});rv.forEach(function(r){io.observe(r)})}
  else rv.forEach(function(r){r.classList.add('in')});
})();
