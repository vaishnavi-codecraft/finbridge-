<?php
require __DIR__ . '/../includes/bootstrap.php';
// Same browser = same session. If a user of a different portal is signed in, sign them out so this portal's login can be used.
if (current_user() && !in_array(current_user()['role'], ['branch_officer', 'branch_manager', 'accounts_officer'], true)) { $_SESSION = []; }
if (current_user()) redirect_to_home();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $error = attempt_login($pdo, trim($_POST['identifier'] ?? ''), $_POST['password'] ?? '', 'staff');
}
auth_start('staff', 'Staff Sign In', ['Customer site', BASE_URL . '/login.php']);
?>
      <h2 class="au-title">Staff Sign In</h2>
      <p class="au-lead">For branch officers, branch managers and the accounts team.</p>
      <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="au-field">
          <label for="identifier">EMPLOYEE ID OR WORK EMAIL</label>
          <input type="text" id="identifier" name="identifier" placeholder="e.g. OFF-CHN-001" required autofocus>
        </div>
        <?php auth_password_field('password', 'PASSWORD', 'Enter your password'); ?>
        <a class="au-forgot" href="#" data-modal="forgot">Forgot password?</a>
        <button class="au-btn" type="submit">Sign In <span>→</span></button>
      </form>
      <p class="au-alt">New employee? <a href="register.php">Request access</a></p>
      <p class="au-hint">New accounts are activated after administrator approval.</p>
<?php auth_end();
