<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['branch_officer', 'branch_manager']);

$u = current_user();
$isOfficer = $u['role'] === 'branch_officer';
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

// Load the application, but only if this user is allowed to see it
$sql = "SELECT a.*, p.name AS product, p.code AS product_code, b.name AS branch,
               cu.id AS customer_user_id, cu.full_name AS customer_name, cu.email AS customer_email,
               cu.phone AS customer_phone, c.customer_code, c.employment_type, c.monthly_income
        FROM loan_applications a
        JOIN loan_products p ON p.id = a.product_id
        LEFT JOIN branches b ON b.id = a.branch_id
        JOIN customers c ON c.id = a.customer_id
        JOIN users cu ON cu.id = c.user_id
        WHERE a.id = ? AND a.status <> 'draft' AND ";
if ($isOfficer) {
    $sql .= '(a.assigned_officer_id = ? OR (a.assigned_officer_id IS NULL AND a.branch_id = ?))';
    $params = [$id, $u['id'], $u['branch_id']];
} else {
    $sql .= 'a.branch_id = ?';
    $params = [$id, $u['branch_id']];
}
$s = $pdo->prepare($sql);
$s->execute($params);
$a = $s->fetch();
if (!$a) { http_response_code(404); exit('Application not found.'); }

// ---------- Officer actions ----------
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isDecision = ($_POST['action'] ?? '') === 'decide';
    if ($isDecision === $isOfficer) { http_response_code(403); exit('Access denied.'); }   // decisions: manager only; other actions: officer only
    csrf_check();

    $act    = $_POST['action'] ?? '';
    $status = $a['status'];
    $appNo  = $a['application_no'];
    $custId = (int)$a['customer_user_id'];
    $note   = trim($_POST['note'] ?? '');
    $reason = trim($_POST['reason'] ?? '');
    $ok     = '';

    if ($act === 'start_review') {
        if ($status !== 'submitted') {
            $error = 'This application is not waiting to be started.';
        } else {
            $pdo->beginTransaction();
            change_status($pdo, $a, 'under_review', $u['id'], 'Review started');
            notify($pdo, $custId, $id, "Your application $appNo is now under review.");
            $pdo->commit();
            $ok = 'Review started.';
        }

    } elseif ($act === 'request_docs') {
        if (!in_array($status, ['submitted', 'under_review'], true)) {
            $error = 'Documents can only be requested while the application is being reviewed.';
        } elseif ($reason === '' || strlen($reason) > 250) {
            $error = 'Describe the documents required (up to 250 characters).';
        } else {
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO document_requests (application_id, requested_by, reason) VALUES (?,?,?)')
                ->execute([$id, $u['id'], $reason]);
            change_status($pdo, $a, 'documents_required', $u['id'], 'Documents requested: ' . $reason);
            notify($pdo, $custId, $id, "Additional documents are required for $appNo: $reason");
            $pdo->commit();
            $ok = 'Document request sent to the customer.';
        }

    } elseif ($act === 'resume_review') {
        // Officer confirms that no additional documents are needed and resumes the normal review.
        if ($status !== 'documents_required') {
            $error = 'This action is only available when the application is waiting for documents.';
        } elseif ($note === '' || mb_strlen($note) > 1000) {
            $error = 'Enter a reason for resuming the review (up to 1000 characters).';
        } else {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE document_requests SET status = 'fulfilled', fulfilled_at = NOW() WHERE application_id = ? AND status = 'open'")
                ->execute([$id]);
            $pdo->prepare('INSERT INTO review_notes (application_id, officer_id, note, recommendation) VALUES (?,?,?,?)')
                ->execute([$id, $u['id'], 'Document request resolved; review resumed: ' . $note, 'none']);
            change_status($pdo, $a, 'under_review', $u['id'], 'Officer resolved document request and resumed review: ' . $note);
            notify($pdo, $custId, $id, "Review of $appNo has resumed. The branch officer will continue processing your application.");
            $pdo->commit();
            $ok = 'Document request resolved. Review resumed; complete the checks and forward to the manager.';
            // Reload status for the action controls rendered below.
            $a['status'] = 'under_review';
            $status = 'under_review';
        }

    } elseif ($act === 'review_doc') {
        $docId = (int)($_POST['doc_id'] ?? 0);
        $dec = $_POST['decision'] ?? '';
        $dq = $pdo->prepare('SELECT * FROM application_documents WHERE id = ? AND application_id = ?');
        $dq->execute([$docId, $id]);
        $doc = $dq->fetch();
        if (!in_array($status, ['submitted', 'under_review', 'documents_required'], true)) {
            $error = 'Documents can only be checked while the application is being reviewed.';
        } elseif (!$doc) {
            $error = 'Document not found.';
        } elseif (!in_array($dec, ['received', 'clarification'], true)) {
            $error = 'Choose accept or ask for re-upload.';
        } elseif ($dec === 'clarification' && ($note === '' || mb_strlen($note) > 200)) {
            $error = 'Tell the customer what to fix (up to 200 characters).';
        } else {
            $pdo->prepare('UPDATE application_documents SET review_status = ?, review_note = ? WHERE id = ?')
                ->execute([$dec, $dec === 'clarification' ? $note : null, $docId]);
            if ($dec === 'clarification') notify($pdo, $custId, $id, "$appNo: please re-upload \"{$doc['doc_type']}\" - $note");
            $ok = $dec === 'received' ? 'Document accepted.' : 'Customer asked to re-upload the document.';
        }

    } elseif ($act === 'verify') {
        $method  = $_POST['method'] ?? '';
        $outcome = $_POST['outcome'] ?? '';
        $vdate   = trim($_POST['visit_date'] ?? '');
        $vd = null;
        if ($status !== 'under_review') {
            $error = 'Start the review before recording a verification.';
        } elseif (!in_array($method, ['visit', 'call', 'document_check'], true)) {
            $error = 'Choose how the verification was done.';
        } elseif (!in_array($outcome, ['satisfactory', 'concerns', 'unable'], true)) {
            $error = 'Choose the outcome.';
        } elseif ($note === '' || mb_strlen($note) > 1000) {
            $error = 'Enter your verification notes (up to 1000 characters).';
        } elseif ($method === 'visit' && (!($vd = DateTime::createFromFormat('!Y-m-d', $vdate)) || $vd->format('Y-m-d') !== $vdate || $vd > new DateTime('today'))) {
            $error = 'Enter the date of the visit (not in the future).';
        } else {
            $pdo->prepare('INSERT INTO field_verifications (application_id, officer_id, method, outcome, visit_date, address_verified, note) VALUES (?,?,?,?,?,?,?)')
                ->execute([$id, $u['id'], $method, $outcome, $method === 'visit' ? $vdate : null, empty($_POST['address_verified']) ? 0 : 1, $note]);
            $ok = 'Verification recorded.';
        }

    } elseif ($act === 'add_note') {
        if (!in_array($status, ['submitted', 'under_review', 'documents_required', 'pending_manager_decision'], true)) {
            $error = 'Notes cannot be added to this application.';
        } elseif ($note === '' || strlen($note) > 1000) {
            $error = 'Enter a note (up to 1000 characters).';
        } else {
            $pdo->prepare('INSERT INTO review_notes (application_id, officer_id, note, recommendation) VALUES (?,?,?,?)')
                ->execute([$id, $u['id'], $note, 'none']);
            $ok = 'Note saved.';
        }

    } elseif ($act === 'forward') {
        $rec = $_POST['recommendation'] ?? '';
        if ($status !== 'under_review') {
            $error = 'Only an application under review can be forwarded.';
        } elseif (($blk = forward_blockers($pdo, $a)) !== '') {
            $error = $blk;
        } elseif (!in_array($rec, ['approve', 'reject'], true)) {
            $error = 'Choose a recommendation.';
        } elseif ($note === '' || strlen($note) > 1000) {
            $error = 'Enter your review findings (up to 1000 characters).';
        } else {
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO review_notes (application_id, officer_id, note, recommendation) VALUES (?,?,?,?)')
                ->execute([$id, $u['id'], $note, $rec]);
            change_status($pdo, $a, 'pending_manager_decision', $u['id'], 'Forwarded to the branch manager for a decision');
            notify($pdo, $custId, $id, "Your application $appNo has been reviewed and forwarded for a decision.");
            $m = $pdo->prepare("SELECT id FROM users WHERE role = 'branch_manager' AND branch_id = ? AND is_active = 1");
            $m->execute([$a['branch_id']]);
            foreach ($m->fetchAll(PDO::FETCH_COLUMN) as $mid) {
                notify($pdo, (int)$mid, $id, "Application $appNo is awaiting your decision.");
            }
            $pdo->commit();
            $ok = 'Application forwarded to the branch manager.';
        }

    } elseif ($act === 'decide') {
        $decision = $_POST['decision'] ?? '';
        $amount   = (float)($_POST['approved_amount'] ?? 0);
        if ($status !== 'pending_manager_decision') {
            $error = 'This application is not waiting for a decision.';
        } elseif (!in_array($decision, ['approved', 'rejected', 'returned'], true)) {
            $error = 'Choose a decision.';
        } elseif ($reason === '' || strlen($reason) > 250) {
            $error = 'Enter the reason for your decision (up to 250 characters).';
        } elseif ($decision === 'approved' && ($amount <= 0 || $amount > (float)$a['requested_amount'])) {
            $error = 'Approved amount must be more than 0 and not above the requested amount.';
        } else {
            $to = ['approved' => 'approved', 'rejected' => 'rejected', 'returned' => 'under_review'][$decision];
            $hist = ['approved' => 'Approved by the branch manager', 'rejected' => 'Rejected by the branch manager',
                     'returned' => 'Returned for further review'][$decision];
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO approval_records (application_id, manager_id, decision, approved_amount, reason) VALUES (?,?,?,?,?)')
                ->execute([$id, $u['id'], $decision, $decision === 'approved' ? $amount : null, $reason]);
            $pdo->prepare('UPDATE loan_applications SET status = ? WHERE id = ?')->execute([$to, $id]);
            log_status($pdo, $id, $status, $to, $u['id'], $hist);

            if ($decision === 'approved') {
                $cm = "Your application $appNo has been approved for " . money($amount) . '. See your application page for details.';
            } elseif ($decision === 'rejected') {
                $cm = "Your application $appNo was not approved. See your application page for the reason.";
            } else {
                $cm = "Your application $appNo needs further review. We will update you soon.";
            }
            notify($pdo, $custId, $id, $cm);
            if ($a['assigned_officer_id']) {
                $om = $decision === 'returned'
                    ? "Manager returned $appNo for further review: $reason"
                    : "Application $appNo was " . $decision . ' by the manager.';
                notify($pdo, (int)$a['assigned_officer_id'], $id, $om);
            }
            $pdo->commit();
            $ok = 'Decision recorded: ' . $decision . '.';
        }

    } else {
        $error = 'Unknown action.';
    }

    if (!$error) {
        audit($pdo, $u['id'], 'review_' . $act, 'loan_application', $id, $appNo);
        set_flash($ok);
        header('Location: review.php?id=' . $id);
        exit;
    }
}

// ---------- Page data ----------
$details = json_decode($a['details_json'] ?? '{}', true) ?: [];
$labels = all_field_labels($a['product_code']);
$applicant = app_applicant($a);
$elig = $a['eligibility_result'] ?? null;
$vq = $pdo->prepare('SELECT v.*, u.full_name FROM field_verifications v JOIN users u ON u.id = v.officer_id WHERE v.application_id = ? ORDER BY v.id DESC');
$vq->execute([$id]); $verifications = $vq->fetchAll();
$missingDocs = !empty($a['applicant_json']) ? missing_required_documents($pdo, $a) : [];
$emi = calc_emi((float)$a['requested_amount'], (float)$a['interest_rate'], (int)$a['tenure_months']);

$d = $pdo->prepare('SELECT id, doc_key, doc_type, original_name, review_status, review_note, uploaded_at FROM application_documents WHERE application_id = ? ORDER BY id');
$d->execute([$id]); $docs = $d->fetchAll();

$rq = $pdo->prepare('SELECT reason, status, created_at FROM document_requests WHERE application_id = ? ORDER BY id DESC');
$rq->execute([$id]); $requests = $rq->fetchAll();

$rn = $pdo->prepare('SELECT n.note, n.recommendation, n.created_at, u.full_name FROM review_notes n JOIN users u ON u.id = n.officer_id WHERE n.application_id = ? ORDER BY n.id DESC');
$rn->execute([$id]); $notes = $rn->fetchAll();

$h = $pdo->prepare('SELECT h.to_status, h.note, h.created_at, u.full_name FROM application_history h JOIN users u ON u.id = h.changed_by WHERE h.application_id = ? ORDER BY h.id DESC');
$h->execute([$id]); $history = $h->fetchAll();

$ap = $pdo->prepare('SELECT d.decision, d.approved_amount, d.reason, d.decided_at, u.full_name FROM approval_records d JOIN users u ON u.id = d.manager_id WHERE d.application_id = ? ORDER BY d.id DESC');
$ap->execute([$id]); $decisions = $ap->fetchAll();
$officerRec = '';
foreach ($notes as $x) { if ($x['recommendation'] !== 'none') { $officerRec = $x['recommendation']; break; } }

$status = $a['status'];
page_header('Review ' . $a['application_no']);
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
if ($error) echo '<div class="error">' . e($error) . '</div>';
?>
<p><a href="applications.php">&larr; Back to applications</a></p>
<div class="stack">

<div class="card">
  <p>Status: <?= status_badge($status) ?> <?= $a['is_fast_track'] ? '<span class="badge badge-priority">Priority review requested</span>' : '' ?></p>
  <div class="two-col">
    <table>
      <tr><th colspan="2">Application</th></tr>
      <tr><td>Loan type</td><td><?= e($a['product']) ?></td></tr>
      <tr><td>Branch</td><td><?= e($a['branch']) ?></td></tr>
      <tr><td>Amount requested</td><td><?= money($a['requested_amount']) ?></td></tr>
      <tr><td>Tenure</td><td><?= (int)$a['tenure_months'] ?> months</td></tr>
      <tr><td>Rate / EMI (estimate)</td><td><?= e($a['interest_rate']) ?>% / <?= money($emi) ?></td></tr>
      <?php foreach ($details as $k => $v): ?>
        <tr><td><?= e($labels[$k][0] ?? $k) ?></td><td><?= e(show_value($labels, $k, $v)) ?></td></tr>
      <?php endforeach; ?>
      <?php if ($a['purpose']): ?><tr><td>Purpose</td><td><?= e($a['purpose']) ?></td></tr><?php endif; ?>
    </table>
    <table>
      <tr><th colspan="2">Customer</th></tr>
      <tr><td>Name</td><td><?= e($a['customer_name']) ?></td></tr>
      <tr><td>Customer ID</td><td><?= e($a['customer_code']) ?></td></tr>
      <tr><td>Mobile</td><td><?= e($a['customer_phone']) ?></td></tr>
      <tr><td>Email</td><td><?= e($a['customer_email']) ?></td></tr>
      <?php foreach ($applicant as $k => $v): if (in_array($k, ['permanent_same', 'full_name', 'phone', 'email'], true) || $v === '' || $v === null) continue; ?>
        <tr><td><?= e($labels[$k][0] ?? $k) ?></td><td><?= e($k === 'account_number' ? str_repeat('•', max(0, strlen((string)$v) - 4)) . substr((string)$v, -4) : show_value($labels, $k, $v)) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$applicant && $a['employment_type']): ?><tr><td>Employment</td><td><?= e($a['employment_type']) ?></td></tr><?php endif; ?>
      <?php if ($elig && isset(ELIG_LABELS[$elig])): ?><tr><td>Indicative eligibility</td><td><span class="elig-tag elig-<?= e($elig) ?>"><?= e(ELIG_LABELS[$elig]) ?></span></td></tr><?php endif; ?>
    </table>
  </div>
</div>

<div class="card">
  <h2>Documents</h2>
  <?php if ($missingDocs && $isOfficer): ?><div class="notice">Required but not uploaded: <?= e(implode(', ', $missingDocs)) ?>.</div><?php endif; ?>
  <?php if (!$docs): ?>
    <p class="muted">No documents uploaded.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <tr><th>Document</th><th>File</th><th>Check</th><th>Uploaded</th><?php if ($isOfficer): ?><th>Review</th><?php endif; ?></tr>
      <?php foreach ($docs as $x): ?>
        <tr><td><?= e($x['doc_type']) ?></td>
            <td><a href="<?= BASE_URL ?>/download_document.php?id=<?= (int)$x['id'] ?>" target="_blank" rel="noopener"><?= e($x['original_name']) ?></a></td>
            <td><?= e(DOC_STATUS_LABELS[$x['review_status']] ?? $x['review_status']) ?><?= $x['review_note'] ? '<br><span class="muted">' . e($x['review_note']) . '</span>' : '' ?></td>
            <td><?= e(date('d M Y', strtotime($x['uploaded_at']))) ?></td>
            <?php if ($isOfficer): ?><td>
              <?php if (in_array($status, ['submitted', 'under_review', 'documents_required'], true)): ?>
              <form method="post" class="docrev"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>">
                <input type="hidden" name="action" value="review_doc"><input type="hidden" name="doc_id" value="<?= (int)$x['id'] ?>">
                <input type="text" name="note" placeholder="Note (needed to ask re-upload)" maxlength="200">
                <button class="btn-sm" name="decision" value="received" type="submit">Accept</button>
                <button class="btn-sm btn-danger" name="decision" value="clarification" type="submit">Ask re-upload</button></form>
              <?php endif; ?></td><?php endif; ?></tr>
      <?php endforeach; ?>
    </table></div>
  <?php endif; ?>
  <?php if ($requests): ?>
    <h3>Document requests</h3>
    <ul class="timeline">
      <?php foreach ($requests as $x): ?>
        <li><?= e($x['reason']) ?> <span class="badge"><?= e($x['status']) ?></span>
          <span class="muted"><?= e(date('d M Y, h:i A', strtotime($x['created_at']))) ?></span></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Field verification</h2>
  <?php if (!$verifications): ?><p class="muted">No verification recorded yet.<?= $a['product_code'] === 'HOME' ? ' A home loan needs a recorded in-person visit before it can go to the manager.' : '' ?></p><?php else: ?>
  <ul class="timeline">
    <?php foreach ($verifications as $x): ?>
      <li><span class="badge"><?= e(['visit' => 'Visit', 'call' => 'Call', 'document_check' => 'Document check'][$x['method']]) ?></span>
        <span class="badge <?= $x['outcome'] === 'satisfactory' ? 'badge-approved' : ($x['outcome'] === 'concerns' ? 'badge-documents_required' : 'badge-rejected') ?>"><?= e(['satisfactory' => 'Satisfactory', 'concerns' => 'Concerns found', 'unable' => 'Unable to verify'][$x['outcome']]) ?></span>
        <?= $x['address_verified'] ? '<span class="badge badge-approved">Address verified</span>' : '' ?>
        <span class="muted"><?= e($x['full_name']) ?>, <?= e(date('d M Y, h:i A', strtotime($x['created_at']))) ?><?= $x['visit_date'] ? ', visit on ' . e(date('d M Y', strtotime($x['visit_date']))) : '' ?></span>
        <br><?= nl2br(e($x['note'])) ?></li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>
  <?php if ($isOfficer && $status === 'under_review'): ?>
  <div class="action-box" style="margin-top:12px">
    <h3>Record a verification</h3>
    <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="verify">
      <div class="form-grid">
        <div><label for="vmethod">How was it verified?</label>
          <select id="vmethod" name="method" required><option value="">Select</option><option value="visit">In-person visit</option><option value="call">Phone call</option><option value="document_check">Document check</option></select></div>
        <div><label for="voutcome">Outcome</label>
          <select id="voutcome" name="outcome" required><option value="">Select</option><option value="satisfactory">Satisfactory</option><option value="concerns">Concerns found</option><option value="unable">Unable to verify</option></select></div>
        <div id="vdateBox"><label for="visit_date">Visit date</label><input type="date" id="visit_date" name="visit_date" max="<?= date('Y-m-d') ?>"></div>
      </div>
      <label class="check"><input type="checkbox" name="address_verified" value="1"> Customer's address verified</label>
      <label for="vnote">Notes (what you saw / who you spoke to)</label>
      <textarea id="vnote" name="note" rows="3" maxlength="1000" required></textarea>
      <button type="submit">Save Verification</button></form>
    <script>(function(){var m=document.getElementById('vmethod'),b=document.getElementById('vdateBox');function t(){b.style.display=m.value==='visit'?'block':'none';}m.addEventListener('change',t);t();})();</script>
  </div>
  <?php endif; ?>
</div>

<?php if ($isOfficer): ?>
<div class="card">
  <h2>Actions</h2>

  <?php if ($status === 'submitted'): ?>
    <div class="action-box">
      <h3>Start review</h3>
      <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="start_review">
        <button type="submit">Start Review</button></form>
    </div>
  <?php endif; ?>

  <?php if (in_array($status, ['submitted', 'under_review'], true)): ?>
    <div class="action-box">
      <h3>Request documents</h3>
      <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="request_docs">
        <label for="reason">Documents needed and reason</label>
        <input type="text" id="reason" name="reason" maxlength="250" placeholder="e.g. Latest 3 months salary slips" required>
        <button type="submit">Request Documents</button></form>
    </div>
  <?php endif; ?>

  <?php if (in_array($status, ['submitted', 'under_review', 'documents_required', 'pending_manager_decision'], true)): ?>
    <div class="action-box">
      <h3>Add review note (internal)</h3>
      <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="add_note">
        <textarea name="note" rows="3" maxlength="1000" required></textarea>
        <button type="submit">Save Note</button></form>
    </div>
  <?php endif; ?>

  <?php if ($status === 'under_review'): ?>
    <div class="action-box">
      <h3>Recommend and forward to manager</h3>
      <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="forward">
        <div class="radio-row">
          <label><input type="radio" name="recommendation" value="approve" required> Recommend approval</label>
          <label><input type="radio" name="recommendation" value="reject"> Recommend rejection</label>
        </div>
        <label for="fnote">Review findings</label>
        <textarea id="fnote" name="note" rows="3" maxlength="1000" required></textarea>
        <button type="submit">Forward to Manager</button></form>
    </div>
  <?php endif; ?>

  <?php if ($status === 'documents_required'): ?>
    <div class="action-box">
      <h3>No additional documents needed?</h3>
      <p class="muted">If the request was entered by mistake or the documents are not required, resolve it here. This returns the application to review; it does not approve the loan.</p>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="id" value="<?= $id ?>">
        <input type="hidden" name="action" value="resume_review">
        <label for="resume_note">Reason for resuming review</label>
        <textarea id="resume_note" name="note" rows="2" maxlength="1000" placeholder="e.g. Document request was entered by mistake; no additional documents required." required></textarea>
        <button type="submit">Resolve Request &amp; Resume Review</button>
      </form>
    </div>
    <p class="muted">After resuming, complete the required checks and use Forward to Manager.</p>
  <?php endif; ?>
  <?php if ($status === 'pending_manager_decision'): ?><p class="muted">Forwarded. Waiting for the manager's decision.</p><?php endif; ?>
  <?php if (!in_array($status, ['submitted', 'under_review', 'documents_required', 'pending_manager_decision'], true)): ?>
    <p class="muted">No officer actions are available for this status.</p>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!$isOfficer && $status !== 'pending_manager_decision'): ?>
<div class="card" style="border-left:4px solid #5b6ee1;background:#f5f7ff">
  <h2>Next step in the loan journey</h2>
  <?php if ($status === 'documents_required'): ?>
    <p><strong>Manager decision is not available yet.</strong> The application is waiting for the customer to upload the requested documents and respond. Once submitted, the status returns to Under Review; the branch officer must re-check the documents and forward the case to you.</p>
    <p><a class="btn btn-line" href="../customer/documents.php?app=<?= (int)$id ?>">Open customer document page</a></p>
  <?php elseif ($status === 'submitted' || $status === 'under_review'): ?>
    <p>The branch officer must complete verification and use <strong>Forward to Manager</strong>. The decision controls appear here only after the status becomes <code>pending_manager_decision</code>.</p>
  <?php elseif ($status === 'approved' || $status === 'agreement_pending' || $status === 'ready_for_disbursement' || $status === 'disbursement_failed' || $status === 'active' || $status === 'closed'): ?>
    <p>This application has already passed the manager decision stage. Continue with the Accounts Officer workflow: agreement, Demo Bank disbursement, loan account and repayments.</p>
    <p><a class="btn" href="../accounts/disbursements.php">Open Accounts Disbursements</a></p>
  <?php elseif ($status === 'rejected'): ?>
    <p>This application was rejected. The accounts workflow is intentionally unavailable for rejected applications.</p>
  <?php else: ?>
    <p>Current status: <strong><?= e(STATUS_LABELS[$status] ?? $status) ?></strong>. The manager can decide only after the officer forwards the application.</p>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if (!$isOfficer && $status === 'pending_manager_decision'): ?>
<div class="card">
  <h2>Your decision</h2>
  <?php if ($officerRec): ?><p>Officer recommends: <strong><?= e($officerRec) ?></strong></p><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="id" value="<?= $id ?>">
    <input type="hidden" name="action" value="decide">
    <div class="radio-row">
      <label><input type="radio" name="decision" value="approved" required> Approve</label>
      <label><input type="radio" name="decision" value="rejected"> Reject</label>
      <label><input type="radio" name="decision" value="returned"> Return for further review</label>
    </div>
    <label for="approved_amount">Approved amount (₹) - used only when approving</label>
    <input type="number" step="any" min="0" id="approved_amount" name="approved_amount" value="<?= e($a['requested_amount']) ?>">
    <label for="dreason">Reason for decision</label>
    <input type="text" id="dreason" name="reason" maxlength="250" required>
    <button type="submit">Record Decision</button>
  </form>
</div>
<?php endif; ?>

<?php if ($decisions): ?>
<div class="card">
  <h2>Manager decisions</h2>
  <ul class="timeline">
    <?php foreach ($decisions as $x): ?>
      <li><span class="badge"><?= e($x['decision']) ?></span>
        <?= $x['approved_amount'] !== null ? ' ' . money($x['approved_amount']) : '' ?>
        <span class="muted"><?= e($x['full_name']) ?>, <?= e(date('d M Y, h:i A', strtotime($x['decided_at']))) ?></span><br><?= e($x['reason']) ?></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<div class="card">
  <h2>Review notes (internal)</h2>
  <?php if (!$notes): ?><p class="muted">No notes yet.</p><?php else: ?>
  <ul class="timeline">
    <?php foreach ($notes as $x): ?>
      <li><strong><?= e($x['full_name']) ?></strong>
        <?= $x['recommendation'] !== 'none' ? '<span class="badge">Recommends ' . e($x['recommendation']) . '</span>' : '' ?>
        <span class="muted"><?= e(date('d M Y, h:i A', strtotime($x['created_at']))) ?></span><br><?= nl2br(e($x['note'])) ?></li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>
</div>

<div class="card">
  <h2>History</h2>
  <ul class="timeline">
    <?php foreach ($history as $x): ?>
      <li><?= status_badge($x['to_status']) ?> <span class="muted"><?= e($x['full_name']) ?>, <?= e(date('d M Y, h:i A', strtotime($x['created_at']))) ?></span>
        <?= $x['note'] ? '<br>' . e($x['note']) : '' ?></li>
    <?php endforeach; ?>
  </ul>
</div>

</div>
<?php page_footer(); ?>
