<?php
// Public JSON endpoint for the loan pages: send_otp, verify_otp (demo OTP is returned on screen while TEST_MODE is on).
// Uses the same session keys as customer/apply_api.php, so a verified number carries into the application form.
require __DIR__ . '/includes/bootstrap.php';
header('Content-Type: application/json');
function out(array $d, int $code = 200): void { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['ok' => false, 'message' => 'Method not allowed.'], 405);
if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) out(['ok' => false, 'message' => 'Session expired. Please refresh the page.'], 400);
$act = $_POST['action'] ?? '';

if ($act === 'send_otp') {
    $mobile = preg_replace('/\D/', '', (string)($_POST['mobile'] ?? ''));
    if (!preg_match('/^[6-9][0-9]{9}$/', $mobile)) out(['ok' => false, 'message' => 'Enter a valid 10-digit mobile number.']);
    $last = $_SESSION['otp']['sent_at'] ?? 0;
    if (time() - $last < 30) out(['ok' => false, 'message' => 'Please wait ' . (30 - (time() - $last)) . ' seconds before requesting a new OTP.']);
    $code = (string)random_int(100000, 999999);
    $_SESSION['otp'] = ['mobile' => $mobile, 'hash' => password_hash($code, PASSWORD_DEFAULT), 'exp' => time() + 300, 'tries' => 0, 'sent_at' => time()];
    $r = ['ok' => true, 'message' => 'OTP sent to +91 ' . substr($mobile, 0, 2) . 'XXXXXX' . substr($mobile, -2) . '. Valid for 5 minutes.'];
    if (TEST_MODE) $r['demo_otp'] = $code;
    out($r);
}
if ($act === 'verify_otp') {
    $o = $_SESSION['otp'] ?? null;
    $code = preg_replace('/\D/', '', (string)($_POST['otp'] ?? ''));
    if (!$o) out(['ok' => false, 'message' => 'Request an OTP first.']);
    if (time() > $o['exp']) { unset($_SESSION['otp']); out(['ok' => false, 'message' => 'OTP expired. Request a new one.']);}
    if ($o['tries'] >= 3) { unset($_SESSION['otp']); out(['ok' => false, 'message' => 'Too many wrong attempts. Request a new OTP.']); }
    if (!password_verify($code, $o['hash'])) {
        $_SESSION['otp']['tries']++;
        out(['ok' => false, 'message' => 'Incorrect OTP. ' . (3 - $_SESSION['otp']['tries']) . ' attempt(s) left.']);
    }
    $_SESSION['otp_verified'] = ['mobile' => $o['mobile'], 'at' => time()];
    unset($_SESSION['otp']);

    // Remember the loan and the choices made on the loan page, to pre-fill the application later.
    $type = strtoupper((string)($_POST['type'] ?? ''));
    $cat = loan_catalog();
    if (isset($cat[$type])) {
        $chk = $pdo->prepare('SELECT code FROM loan_products WHERE code = ? AND is_active = 1');
        $chk->execute([$type]);
        if ($chk->fetchColumn()) {
            $fields = [];
            foreach ($cat[$type]['choices'] as $ch) {
                $v = (string)($_POST[$ch['field']] ?? '');
                if (isset($ch['opts'][$v])) $fields[$ch['field']] = $v;
            }
            $_SESSION['loan_prefill'] = ['code' => $type, 'fields' => $fields];
            $_SESSION['finbridge_selected_loan'] = $type;
        }
    }
    out(['ok' => true, 'message' => 'Mobile number verified.']);
}
out(['ok' => false, 'message' => 'Unknown action.'], 400);
