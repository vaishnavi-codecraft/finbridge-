<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$custId = customer_id_for_user($pdo, current_user()['id']);
$s = $pdo->prepare(
    'SELECT a.id, a.application_no, a.requested_amount, a.tenure_months, a.status, a.submitted_at, a.is_fast_track, a.created_at, a.current_step, p.name AS product
     FROM loan_applications a JOIN loan_products p ON p.id = a.product_id
     WHERE a.customer_id = ? ORDER BY a.id DESC'
);
$s->execute([$custId]);
$rows = $s->fetchAll();

page_header('My Applications');
if (!$rows) {
    echo '<div class="card"><p>You have not applied for a loan yet.</p><a class="btn" href="apply.php">Apply for a Loan</a></div>';
} else { ?>
<div class="table-wrap"><table>
  <tr><th>Application ID</th><th>Loan type</th><th>Amount</th><th>Tenure</th><th>Status</th><th>Submitted</th><th></th></tr>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><?= $r['status'] === 'draft' ? '<span class="muted">Draft (not submitted)</span>' : e($r['application_no']) ?><?= $r['is_fast_track'] ? ' <span class="muted">(priority)</span>' : '' ?></td>
    <td><?= e($r['product']) ?></td>
    <td><?= money($r['requested_amount']) ?></td>
    <td><?= (int)$r['tenure_months'] ?> mo</td>
    <td><?= status_badge($r['status']) ?></td>
    <td><?= e(date('d M Y', strtotime($r['submitted_at'] ?? $r['created_at']))) ?></td>
    <td><?php if ($r['status'] === 'draft'): ?><a href="application_stages.php?id=<?= (int)$r['id'] ?>">Continue</a><?php else: ?><a href="application_details.php?id=<?= (int)$r['id'] ?>">View</a><?php endif; ?></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php }
page_footer();
