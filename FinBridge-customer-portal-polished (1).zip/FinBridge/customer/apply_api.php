<?php
// JSON endpoint for the apply stepper: send_otp, verify_otp, save (creates / updates the DRAFT application).
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);
header('Content-Type: application/json');

function out(array $d, int $code = 200): void { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['ok' => false, 'message' => 'Method not allowed.'], 405);
if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) out(['ok' => false, 'message' => 'Session expired. Please refresh the page.'], 400);

$user   = current_user();
$custId = customer_id_for_user($pdo, $user['id']);
if (!$custId) out(['ok' => false, 'message' => 'Customer profile not found.'], 404);
$act = $_POST['action'] ?? '';

// ---------- OTP (demo: the code is returned on screen while TEST_MODE is on) ----------
if ($act === 'send_otp') {
    $mobile = preg_replace('/\D/', '', (string)($_POST['mobile'] ?? ''));
    if (!preg_match('/^[6-9][0-9]{9}$/', $mobile)) out(['ok' => false, 'message' => 'Enter a valid 10-digit mobile number.']);
    $last = $_SESSION['otp']['sent_at'] ?? 0;
    if (time() - $last < 30) out(['ok' => false, 'message' => 'Please wait ' . (30 - (time() - $last)) . ' seconds before requesting a new OTP.']);
    $code = (string)random_int(100000, 999999);
    $_SESSION['otp'] = ['mobile' => $mobile, 'hash' => password_hash($code, PASSWORD_DEFAULT), 'exp' => time() + 300, 'tries' => 0, 'sent_at' => time()];
    $r = ['ok' => true, 'message' => 'OTP sent to +91 ' . substr($mobile, 0, 2) . 'XXXXXX' . substr($mobile, -2) . '. Valid for 5 minutes.'];
    if (TEST_MODE) $r['demo_otp'] = $code;      // demo only: remove when TEST_MODE is false
    out($r);
}
if ($act === 'verify_otp') {
    $o = $_SESSION['otp'] ?? null;
    $code = preg_replace('/\D/', '', (string)($_POST['otp'] ?? ''));
    if (!$o) out(['ok' => false, 'message' => 'Request an OTP first.']);
    if (time() > $o['exp']) { unset($_SESSION['otp']); out(['ok' => false, 'message' => 'OTP expired. Request a new one.']); }
    if ($o['tries'] >= 3) { unset($_SESSION['otp']); out(['ok' => false, 'message' => 'Too many wrong attempts. Request a new OTP.']); }
    if (!password_verify($code, $o['hash'])) {
        $_SESSION['otp']['tries']++;
        out(['ok' => false, 'message' => 'Incorrect OTP. ' . (3 - $_SESSION['otp']['tries']) . ' attempt(s) left.']);
    }
    $_SESSION['otp_verified'] = ['mobile' => $o['mobile'], 'at' => time()];
    unset($_SESSION['otp']);
    out(['ok' => true, 'message' => 'Mobile number verified.']);
}

// ---------- Save the whole stepper as a DRAFT ----------
if ($act === 'save') {
    $ver = $_SESSION['otp_verified'] ?? null;
    if (!$ver || time() - $ver['at'] > 3600) out(['ok' => false, 'message' => 'Please verify your mobile number with OTP first.', 'goto' => 1]);

    $pr = $pdo->prepare('SELECT * FROM loan_products WHERE code = ? AND is_active = 1');
    $pr->execute([strtoupper($_POST['p'] ?? '')]);
    $product = $pr->fetch();
    if (!$product) out(['ok' => false, 'message' => 'Unknown loan type.'], 400);
    $code = $product['code'];

    $draftId = (int)($_POST['draft'] ?? 0);
    $draft = null; $existingAp = []; $existingDet = [];
    if ($draftId) {
        $s = $pdo->prepare("SELECT * FROM loan_applications WHERE id = ? AND customer_id = ? AND status = 'draft' AND product_id = ?");
        $s->execute([$draftId, $custId, $product['id']]);
        $draft = $s->fetch();
        if (!$draft) out(['ok' => false, 'message' => 'Draft not found.'], 404);
        $existingAp = app_applicant($draft); $existingDet = json_decode($draft['details_json'] ?? '{}', true) ?: [];
    }

    $errors = [];
    // PAN
    $pan = strtoupper(trim((string)($_POST['pan'] ?? '')));
    if (!preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/', $pan)) $errors[] = 'Enter a valid PAN (format ABCDE1234F).';
    elseif ($pan[3] !== 'P') $errors[] = 'Only individual PAN cards (4th letter P) are accepted for these loans.';
    $sal   = trim((string)($_POST['pan_salutation'] ?? ''));
    $fn    = trim((string)($_POST['pan_first_name'] ?? ''));
    $mn    = trim((string)($_POST['pan_middle_name'] ?? ''));
    $ln    = trim((string)($_POST['pan_last_name'] ?? ''));
    if (!in_array($sal, ['Mr', 'Mrs', 'Ms', 'Dr'], true)) $errors[] = 'Select a salutation.';
    foreach ([$fn, $mn, $ln] as $part) if ($part !== '' && !preg_match("/^[A-Za-z .'-]{1,40}$/", $part)) { $errors[] = 'Names can contain letters only.'; break; }
    if ($fn === '' || $ln === '') $errors[] = 'Enter your first and last name exactly as on your PAN card.';
    $panName = trim(preg_replace('/\s+/', ' ', "$fn $mn $ln"));

    $personal = parse_fields(personal_fields(), $_POST, $errors);
    $same = !empty($_POST['permanent_same']);
    $perm = trim((string)($_POST['permanent_address'] ?? ''));
    if (!$same && ($perm === '' || mb_strlen($perm) > 200)) $errors[] = 'Enter your permanent address.';
    $fin = parse_fields(financial_fields(($_POST['employment_type'] ?? '') === 'student'), $_POST, $errors);
    $details = parse_fields(loan_fields($code), $_POST, $errors);

    $derived = loan_derived($code);
    if ($derived) {
        $amount = (float)($details[$derived[0]] ?? 0) - (float)($details[$derived[1]] ?? 0);
        if ($amount <= 0) $errors[] = 'Down payment must be less than the price.';
    } else $amount = (float)($_POST['requested_amount'] ?? 0);
    $tenure = (int)($_POST['tenure_months'] ?? 0);
    if ($amount < (float)$product['min_amount'] || $amount > (float)$product['max_amount'])
        $errors[] = 'Loan amount must be between ' . money($product['min_amount']) . ' and ' . money($product['max_amount']) . '.';
    if ($tenure < (int)$product['min_tenure_months'] || $tenure > (int)$product['max_tenure_months'])
        $errors[] = 'Tenure must be between ' . (int)$product['min_tenure_months'] . ' and ' . (int)$product['max_tenure_months'] . ' months.';
    if (empty($_POST['consent'])) $errors[] = 'Please accept the consent to fetch and verify your details.';
    if ($errors) out(['ok' => false, 'message' => implode(' ', array_slice($errors, 0, 3)), 'errors' => $errors]);

    $ap = array_merge($existingAp, $personal, $fin, [
        'pan' => $pan, 'pan_name' => $panName, 'pan_salutation' => $sal, 'pan_first_name' => $fn, 'pan_middle_name' => $mn, 'pan_last_name' => $ln, 'verified_mobile' => $ver['mobile'], 'mobile_verified_at' => date('c'),
        'permanent_same' => $same ? 1 : 0, 'permanent_address' => $same ? '' : $perm,
    ]);
    $det = array_merge($existingDet, $details);
    $elig = compute_eligibility($product, $ap, $amount, $tenure);
    $branchId = match_branch($pdo, $personal['pincode'], $personal['district'], $personal['city'], $personal['state']);
    $dj = json_encode($det, JSON_UNESCAPED_UNICODE); $aj = json_encode($ap, JSON_UNESCAPED_UNICODE);

    if ($draft) {
        $pdo->prepare('UPDATE loan_applications SET requested_amount=?, tenure_months=?, interest_rate=?, details_json=?, applicant_json=?, branch_id=?, eligibility_result=?, current_step=GREATEST(current_step,4) WHERE id=?')
            ->execute([$amount, $tenure, $product['interest_rate'], $dj, $aj, $branchId, $elig['code'], $draft['id']]);
        $appId = (int)$draft['id'];
    } else {
        $pdo->prepare("INSERT INTO loan_applications (application_no, customer_id, product_id, branch_id, created_by, channel, requested_amount, tenure_months,
                          interest_rate, details_json, applicant_json, current_step, eligibility_result, status)
                       VALUES (?,?,?,?,?,'online',?,?,?,?,?,4,?,'draft')")
            ->execute(['DR' . bin2hex(random_bytes(6)), $custId, $product['id'], $branchId, $user['id'], $amount, $tenure, $product['interest_rate'], $dj, $aj, $elig['code']]);
        $appId = (int)$pdo->lastInsertId();
    }

    $have = $pdo->prepare('SELECT doc_key, original_name, review_status FROM application_documents WHERE application_id = ?');
    $have->execute([$appId]);
    $uploaded = [];
    foreach ($have->fetchAll() as $d) $uploaded[$d['doc_key']] = $d['original_name'];
    $docs = [];
    foreach (doc_requirements($code, $ap) as $k => [$label, $req]) $docs[] = ['key' => $k, 'label' => $label, 'required' => $req, 'file' => $uploaded[$k] ?? null];

    $emi = calc_emi($amount, (float)$product['interest_rate'], $tenure);
    out(['ok' => true, 'id' => $appId, 'docs' => $docs, 'emi' => round($emi, 2), 'amount' => $amount,
         'eligibility' => ['code' => $elig['code'], 'label' => $elig['label'], 'reasons' => $elig['reasons']]]);
}
out(['ok' => false, 'message' => 'Unknown action.'], 400);
