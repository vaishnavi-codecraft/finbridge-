<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);
$custId = customer_id_for_user($pdo, current_user()['id']);
mark_overdue_installments($pdo);
$q = $pdo->prepare("SELECT la.*, p.name AS product FROM loan_accounts la JOIN loan_products p ON p.id=la.product_id WHERE la.customer_id=? ORDER BY la.id DESC");
$q->execute([$custId]); $accounts=$q->fetchAll();
$sel=null; foreach($accounts as $a){if((int)$a['id']===(int)($_GET['id']??0))$sel=$a;} if(!$sel && $accounts)$sel=$accounts[0];
if (isset($_GET['export']) && $_GET['export']==='csv' && $sel) {
  $s=$pdo->prepare('SELECT installment_no,due_date,emi_amount,principal_part,interest_part,balance_after,status,paid_on FROM repayment_schedule WHERE loan_account_id=? ORDER BY installment_no'); $s->execute([$sel['id']]);
  header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="FinBridge-EMI-schedule.csv"');
  $out=fopen('php://output','w'); fputcsv($out,['Installment','Due date','EMI','Principal','Interest','Closing balance','Status','Paid on']); while($r=$s->fetch(PDO::FETCH_ASSOC))fputcsv($out,$r); fclose($out); exit;
}
page_header('EMI Schedule');
?>
<div class="cx-page-hero"><div><span class="cx-eyebrow">REPAYMENT PLANNER</span><h2>EMI schedule</h2><p>Review every instalment, due date, principal and interest component.</p></div><?php if($sel): ?><div class="cx-actions"><a class="cx-btn" href="?id=<?= (int)$sel['id'] ?>&amp;export=csv">Download CSV</a><button class="cx-btn cx-btn-soft" onclick="window.print()" type="button">Save as PDF</button></div><?php endif; ?></div>
<?php if(!$sel): ?><div class="cx-panel"><h3>No loan account yet</h3><p>Your repayment schedule appears after a loan is approved and disbursed.</p><a class="cx-btn" href="applications.php">Track application</a></div><?php else: ?>
<div class="cx-finance-banner"><div><span>LOAN ACCOUNT</span><h3><?= e($sel['product']) ?></h3><small><?= e($sel['account_no']) ?> · <?= e($sel['interest_rate']) ?>% p.a.</small></div><div><span>MONTHLY EMI</span><strong>₹<?= number_format((float)$sel['emi_amount'],2) ?></strong></div><div><span>OUTSTANDING</span><strong>₹<?= number_format((float)$sel['outstanding_balance'],2) ?></strong></div></div>
<div class="cx-table-card cx-schedule-card"><div class="cx-table-wrap"><table><thead><tr><th>INSTALMENT</th><th>DUE DATE</th><th>EMI AMOUNT</th><th>PRINCIPAL</th><th>INTEREST</th><th>CLOSING BALANCE</th><th>STATUS</th></tr></thead><tbody>
<?php $s=$pdo->prepare('SELECT * FROM repayment_schedule WHERE loan_account_id=? ORDER BY installment_no');$s->execute([$sel['id']]);$rows=$s->fetchAll(); foreach($rows as $r): ?><tr><td>#<?= (int)$r['installment_no'] ?></td><td><?= e(date('d M Y',strtotime($r['due_date']))) ?></td><td>₹<?= number_format((float)$r['emi_amount'],2) ?></td><td>₹<?= number_format((float)$r['principal_part'],2) ?></td><td>₹<?= number_format((float)$r['interest_part'],2) ?></td><td>₹<?= number_format((float)$r['balance_after'],2) ?></td><td><span class="cx-status <?= $r['status']==='paid'?'cx-st-good':($r['status']==='overdue'?'cx-st-bad':'cx-st-review') ?>"><?= e(ucfirst($r['status'])) ?></span><?php if($r['paid_on']): ?><small class="cx-paid-date">Paid <?= e(date('d M Y',strtotime($r['paid_on']))) ?></small><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php if(!$rows): ?><div class="cx-empty">No instalments have been generated for this account yet.</div><?php endif; ?></div><p class="cx-disclaimer">PDF tip: select “Save as PDF” in your browser's print dialog. Taxes or fees are shown only when recorded by your loan product/account.</p><?php endif; ?>
<?php page_footer(); ?>
