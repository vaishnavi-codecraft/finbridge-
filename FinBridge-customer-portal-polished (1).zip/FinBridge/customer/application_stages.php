<?php
// HDFC-style stage checklist for one draft application: shows what is done and what is next.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$user   = current_user();
$custId = customer_id_for_user($pdo, $user['id']);
$id     = (int)($_GET['id'] ?? 0);

$s = $pdo->prepare('SELECT a.*, p.name AS product, p.code AS product_code FROM loan_applications a
                    JOIN loan_products p ON p.id = a.product_id WHERE a.id = ? AND a.customer_id = ?');
$s->execute([$id, $custId]);
$app = $s->fetch();
if (!$app) { http_response_code(404); exit('Application not found.'); }
if ($app['status'] !== 'draft') { header('Location: application_details.php?id=' . $id); exit; }

$progress = (int)$app['current_step'];            // 4 after Quick Apply is saved; complete.php steps 1-4 raise it
$elig     = $app['eligibility_result'] ?? '';
$eligText = ['may_meet' => 'May meet initial criteria', 'more_info' => 'More information required', 'not_met' => 'Does not meet the current demo criteria'];
$missing  = missing_required_documents($pdo, $app);
$det = json_decode($app['details_json'] ?? '{}', true) ?: [];
$detailsDone = true;
foreach (loan_detail_fields($app['product_code']) as $f) { if (empty($f[4]) && trim((string)($det[$f[0]] ?? '')) === '') { $detailsDone = false; break; } }
$dc = $pdo->prepare('SELECT COUNT(*) FROM application_documents WHERE application_id = ?'); $dc->execute([$id]);
$docsDone = !$missing && (int)$dc->fetchColumn() > 0;

// Stage state: done / prog / todo
$stages = [
  ['Personal and Employment Details', 'Tell us a bit about your PAN, address and employment details.', 'apply.php?draft=' . $id, true],
  ['Receive In-Principle Loan Approval', $elig ? 'Indicative result: ' . ($eligText[$elig] ?? $elig) . ' (not a final approval).' : 'See your indicative eligibility and EMI.', 'complete.php?id=' . $id . '&step=0', $elig !== ''],
  ['Add ' . strtolower($app['product']) . ' details', 'Share the details of your chosen loan so we can match the right branch.', 'complete.php?id=' . $id . '&step=3', $detailsDone],
  ['Complete your KYC and upload documents', 'Upload your identity, address and income documents from home.', 'complete.php?id=' . $id . '&step=4', $docsDone],
  ['Complete your application for disbursement', 'Review everything, accept the declaration and submit.', 'complete.php?id=' . $id . '&step=5', false],
];
// A stage is in progress when it is the first one not done
$firstOpen = null;
foreach ($stages as $i => $st) { if (!$st[3]) { $firstOpen = $i; break; } }
$pct = round(100 * count(array_filter($stages, fn($x) => $x[3])) / count($stages));

page_header('Your application', false);
?>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/apply-wizard.css">
<div class="st">
  <div class="st-hero">
    <h1><?= e($app['product']) ?> application</h1>
    <p><?= money($app['requested_amount']) ?> &middot; <?= (int)$app['tenure_months'] ?> months &middot; <?= $pct ?>% complete</p>
  </div>
  <div class="st-list">
    <?php foreach ($stages as $i => [$title, $desc, $href, $done]):
        $cls = $done ? 'done' : ($i === $firstOpen ? 'prog' : 'todo');
        $tag = $done ? 'Completed' : ($i === $firstOpen ? 'In Progress' : 'Not Started'); ?>
      <a class="st-item <?= $cls ?>" href="<?= e($href) ?>">
        <span class="st-no"><?= $done ? '&#10003;' : $i + 1 ?></span>
        <span class="st-body"><h3><?= e($title) ?></h3><p><?= e($desc) ?></p><span class="st-tag"><?= $tag ?></span></span>
      </a>
    <?php endforeach; ?>
  </div>
  <div class="st-cta"><a href="<?= e($stages[$firstOpen ?? 4][2]) ?>"><?= ($firstOpen ?? 0) > 0 ? 'Continue application' : 'Start application' ?></a></div>
</div>
<?php page_footer(); ?>
