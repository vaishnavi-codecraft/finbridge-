<?php
// Complete your application (part 2): eligibility result, personal, financial, loan details,
// documents, review and final submit. The application stays a DRAFT until the final submit.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$user   = current_user();
$custId = customer_id_for_user($pdo, $user['id']);
$id     = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$s = $pdo->prepare('SELECT a.*, p.name AS product, p.code AS product_code FROM loan_applications a
                    JOIN loan_products p ON p.id = a.product_id WHERE a.id = ? AND a.customer_id = ?');
$s->execute([$id, $custId]);
$app = $s->fetch();
if (!$app) { http_response_code(404); exit('Application not found.'); }
if ($app['status'] !== 'draft') { header('Location: application_details.php?id=' . $id); exit; }

$code = $app['product_code'];
$pr = $pdo->prepare('SELECT * FROM loan_products WHERE id = ?');
$pr->execute([$app['product_id']]);
$product = $pr->fetch();

$cu = $pdo->prepare('SELECT u.full_name, u.email, u.phone, c.customer_code FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id = ?');
$cu->execute([$custId]);
$acct = $cu->fetch();

$ap  = app_applicant($app);
$det = json_decode($app['details_json'] ?? '{}', true) ?: [];
$progress = (int)$app['current_step'];
$step = (int)($_GET['step'] ?? $_POST['step'] ?? 0);
$step = max(0, min(5, $step, $progress + 1));          // cannot jump ahead of what is completed
$errors = [];
$old = [];

function recompute(PDO $pdo, array $product, array $ap, array $app): string {
    $r = compute_eligibility($product, $ap, (float)$app['requested_amount'], (int)$app['tenure_months']);
    return $r['code'];
}
function bump(PDO $pdo, int $id, int $progress, int $n): void {
    $pdo->prepare('UPDATE loan_applications SET current_step = ? WHERE id = ?')->execute([max($progress, $n), $id]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['action'] ?? 'save';
    $old = $_POST;

    if ($act === 'discard') {
        $f = $pdo->prepare('SELECT file_path FROM application_documents WHERE application_id = ?');
        $f->execute([$id]);
        $pdo->beginTransaction();
        $pdo->prepare('DELETE FROM application_documents WHERE application_id = ?')->execute([$id]);
        $pdo->prepare("DELETE FROM loan_applications WHERE id = ? AND status = 'draft'")->execute([$id]);
        $pdo->commit();
        foreach ($f->fetchAll(PDO::FETCH_COLUMN) as $fp) { @unlink(doc_file_path($fp)); }
        set_flash('Draft discarded.');
        header('Location: dashboard.php'); exit;
    }

    if ($act === 'change_branch') {
        $bid = (int)($_POST['branch_id'] ?? 0);
        $ok = $pdo->prepare('SELECT 1 FROM branches WHERE id = ? AND is_active = 1');
        $ok->execute([$bid]);
        if ($ok->fetchColumn() && $progress >= 4) {
            $pdo->prepare('UPDATE loan_applications SET branch_id = ? WHERE id = ?')->execute([$bid, $id]);
            set_flash('Branch updated.');
        }
        header('Location: complete.php?id=' . $id . '&step=5'); exit;
    }

    if ($act === 'submit') {
        $step = 5;
        $miss = missing_required_documents($pdo, $app);
        $bOk = $app['branch_id'] ? $pdo->prepare('SELECT 1 FROM branches WHERE id = ? AND is_active = 1') : null;
        if ($bOk) $bOk->execute([$app['branch_id']]);
        if ($progress < 4) $errors[] = 'Please complete all the earlier steps first.';
        if ($miss) $errors[] = 'Please upload the required documents: ' . implode(', ', $miss) . '.';
        if (empty($_POST['decl_accurate'])) $errors[] = 'Please confirm that the information is accurate.';
        if (empty($_POST['decl_privacy'])) $errors[] = 'Please accept the declaration and privacy terms.';
        if (!$errors) {
            $branchId = ($bOk && $bOk->fetchColumn()) ? (int)$app['branch_id']
                      : match_branch($pdo, $ap['pincode'] ?? '', $ap['district'] ?? '', $ap['city'] ?? '', $ap['state'] ?? '');
            if (!$branchId) $errors[] = 'No branch is available right now. Please try again later.';
        }
        if (!$errors) {
            $fast    = empty($_POST['fast_track']) ? 0 : 1;
            $officer = pick_officer($pdo, $branchId);
            $appNo   = sprintf('FB%s-%05d', date('Y'), $id);
            $pdo->beginTransaction();
            $u = $pdo->prepare("UPDATE loan_applications SET status = 'submitted', application_no = ?, branch_id = ?, assigned_officer_id = ?, is_fast_track = ?,
                                  submitted_at = NOW(), declared_at = NOW(), current_step = 5, eligibility_result = ? WHERE id = ? AND status = 'draft'");
            $u->execute([$appNo, $branchId, $officer, $fast, recompute($pdo, $product, $ap, $app), $id]);
            if ($u->rowCount() !== 1) { $pdo->rollBack(); header('Location: application_details.php?id=' . $id); exit; }
            $pdo->prepare('UPDATE customers SET dob = ?, address = ?, employment_type = ?, monthly_income = ?, home_branch_id = ? WHERE id = ?')
                ->execute([$ap['dob'] ?? null, mb_substr(trim(($ap['address'] ?? '') . ', ' . ($ap['city'] ?? '') . ' ' . ($ap['pincode'] ?? '')), 0, 255),
                           $ap['employment_type'] ?? null, $ap['monthly_income'] ?? null, $branchId, $custId]);
            log_status($pdo, $id, 'draft', 'submitted', $user['id'], $fast ? 'Application submitted (fast-track review requested)' : 'Application submitted');
            notify($pdo, $user['id'], $id, "Your application $appNo has been submitted and is awaiting review.");
            if ($officer) notify($pdo, $officer, $id, "New application $appNo assigned to you.");
            $pdo->commit();
            audit($pdo, $user['id'], 'application_submitted', 'loan_application', $id, $appNo);
            header('Location: application_details.php?id=' . $id . '&new=1'); exit;
        }
    } elseif ($step === 1) {
        $new = parse_fields(personal_fields(), $_POST, $errors);
        $same = !empty($_POST['permanent_same']);
        $perm = trim($_POST['permanent_address'] ?? '');
        if (!$same && ($perm === '' || mb_strlen($perm) > 200)) $errors[] = 'Enter your permanent address (up to 200 characters).';
        if (!$errors) {
            $oldPin = $ap['pincode'] ?? ''; $oldDist = $ap['district'] ?? '';
            $pan = strtoupper(trim($_POST['pan_number'] ?? ''));
            $salutation = trim($_POST['salutation'] ?? '');
            $panFirst = trim($_POST['pan_first_name'] ?? '');
            $panMiddle = trim($_POST['pan_middle_name'] ?? '');
            $panLast = trim($_POST['pan_last_name'] ?? '');
            if (!preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/', $pan)) $errors[] = 'Enter a valid PAN format (for demo, use fictional details only).';
            if (!in_array($salutation, ['Mr.','Ms.','Mrs.','Dr.'], true)) $errors[] = 'Select a salutation.';
            if ($panFirst === '' || $panLast === '') $errors[] = 'Enter the first and last name as per PAN.';
            if (empty($_POST['pan_consent'])) $errors[] = 'Please confirm the PAN verification consent.';
            if ($errors) { /* Keep the form open and show validation feedback. */ }
            else {
            $ap = array_merge($ap, $new, [
                'salutation' => $salutation, 'pan_number' => $pan,
                'pan_first_name' => $panFirst, 'pan_middle_name' => $panMiddle,
                'pan_last_name' => $panLast, 'pan_consent' => 1,
                'permanent_same' => $same ? 1 : 0, 'permanent_address' => $same ? '' : $perm
            ]);
            // Match the branch automatically; only re-match when there is none yet or the location changed
            $branchId = $app['branch_id'] ? (int)$app['branch_id'] : null;
            if (!$branchId || $oldPin !== $new['pincode'] || strcasecmp($oldDist, $new['district']) !== 0) {
                $branchId = match_branch($pdo, $new['pincode'], $new['district'], $new['city'], $new['state']);
            }
            $pdo->prepare('UPDATE loan_applications SET applicant_json = ?, branch_id = ?, eligibility_result = ? WHERE id = ?')
                ->execute([json_encode($ap, JSON_UNESCAPED_UNICODE), $branchId, recompute($pdo, $product, $ap, $app), $id]);
            bump($pdo, $id, $progress, 1);
            header('Location: complete.php?id=' . $id . '&step=2'); exit;
            }
        }
    } elseif ($step === 2) {
        $new = parse_fields(financial_fields(($_POST['employment_type'] ?? '') === 'student'), $_POST, $errors);
        if (!$errors) {
            $ap = array_merge($ap, $new);
            $pdo->prepare('UPDATE loan_applications SET applicant_json = ?, eligibility_result = ? WHERE id = ?')
                ->execute([json_encode($ap, JSON_UNESCAPED_UNICODE), recompute($pdo, $product, $ap, $app), $id]);
            bump($pdo, $id, $progress, 2);
            header('Location: complete.php?id=' . $id . '&step=3'); exit;
        }
    } elseif ($step === 3) {
        $new = parse_fields(loan_detail_fields($code), $_POST, $errors);
        if (!$errors) {
            $det = array_merge($det, $new);
            $pdo->prepare('UPDATE loan_applications SET details_json = ? WHERE id = ?')->execute([json_encode($det, JSON_UNESCAPED_UNICODE), $id]);
            bump($pdo, $id, $progress, 3);
            header('Location: complete.php?id=' . $id . '&step=4'); exit;
        }
    } elseif ($step === 4) {
        $miss = missing_required_documents($pdo, $app);
        if ($miss) $errors[] = 'Please upload the required documents: ' . implode(', ', $miss) . '.';
        else { bump($pdo, $id, $progress, 4); header('Location: complete.php?id=' . $id . '&step=5'); exit; }
    }
}

// ---------- page data ----------
$emi = calc_emi((float)$app['requested_amount'], (float)$app['interest_rate'], (int)$app['tenure_months']);
$elig = compute_eligibility($product, $ap, (float)$app['requested_amount'], (int)$app['tenure_months']);
$val = fn(string $k, $default = '') => $old[$k] ?? ($ap[$k] ?? ($det[$k] ?? $default));

page_header('Complete your application', false);
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
?>
<div class="wiz-head">
  <h1 class="cx-title" style="margin-bottom:4px"><?= e($app['product']) ?> application</h1>
  <p class="muted">Draft - not submitted yet. Requested <?= money($app['requested_amount']) ?> for <?= (int)$app['tenure_months'] ?> months.</p>
</div>
<ol class="wiz-steps">
  <?php foreach (WIZARD_STEPS as $n => $label):
      $cls = $n === $step ? 'current' : ($n <= $progress ? 'done' : ''); ?>
    <li class="<?= $cls ?>"><?php if ($n <= $progress + 1): ?><a href="complete.php?id=<?= $id ?>&amp;step=<?= $n ?>"><b><?= $n <= $progress && $n !== $step ? '✓' : $n ?></b><?= e($label) ?></a>
      <?php else: ?><span><b><?= $n ?></b><?= e($label) ?></span><?php endif; ?></li>
  <?php endforeach; ?>
</ol>

<div class="card">
<?php foreach ($errors as $er): ?><div class="error"><?= e($er) ?></div><?php endforeach; ?>

<?php if ($step === 0): ?>
  <h2>Your indicative eligibility</h2>
  <?php render_eligibility($elig['code'], $elig['reasons']); ?>
  <table style="margin-top:10px">
    <tr><th>Loan</th><td><?= e($app['product']) ?></td></tr>
    <tr><th>Amount / tenure</th><td><?= money($app['requested_amount']) ?> for <?= (int)$app['tenure_months'] ?> months</td></tr>
    <tr><th>Indicative EMI</th><td><?= money($emi) ?> / month at <?= e($app['interest_rate']) ?>% p.a.</td></tr>
  </table>
  <p>Next you will add your personal and financial details, loan details and documents. The branch that will handle your
    application is found automatically from your PIN code.</p>
  <div class="wiz-nav">
    <a class="btn btn-line" href="apply.php?draft=<?= $id ?>">Edit quick details</a>
    <a class="btn" href="complete.php?id=<?= $id ?>&amp;step=1">Continue</a>
  </div>

<?php elseif ($step === 1): ?>
  <h2>Personal information</h2>
  <p class="muted">Name, mobile and email come from your account: <?= e($acct['full_name']) ?> | <?= e($acct['phone']) ?> | <?= e($acct['email']) ?></p>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="1">
    <section class="fb-identity-panel">
      <div class="fb-panel-heading"><span class="fb-step-icon">01</span><div><h3>Personal and PAN details</h3><p>Enter details exactly as they appear on your PAN card.</p></div></div>
      <div class="form-grid">
        <div><label for="salutation">Salutation <span class="fb-required">*</span></label><select id="salutation" name="salutation" required><option value="">Select</option><?php foreach (['Mr.','Ms.','Mrs.','Dr.'] as $sal): ?><option value="<?= e($sal) ?>" <?= $val('salutation') === $sal ? 'selected' : '' ?>><?= e($sal) ?></option><?php endforeach; ?></select></div>
        <div><label for="pan_number">PAN number <span class="fb-required">*</span></label><input id="pan_number" name="pan_number" type="text" maxlength="10" minlength="10" pattern="[A-Za-z]{5}[0-9]{4}[A-Za-z]" value="<?= e($val('pan_number')) ?>" placeholder="ABCDE1234F" style="text-transform:uppercase" required></div>
        <div><label for="pan_first_name">First name as per PAN <span class="fb-required">*</span></label><input id="pan_first_name" name="pan_first_name" value="<?= e($val('pan_first_name', $acct['full_name'])) ?>" maxlength="80" required></div>
        <div><label for="pan_middle_name">Middle name</label><input id="pan_middle_name" name="pan_middle_name" value="<?= e($val('pan_middle_name')) ?>" maxlength="80"></div>
        <div><label for="pan_last_name">Last name as per PAN <span class="fb-required">*</span></label><input id="pan_last_name" name="pan_last_name" value="<?= e($val('pan_last_name')) ?>" maxlength="80" required></div>
      </div>
      <div class="fb-hint"><strong>Important:</strong> Make sure your name matches your PAN records. If your PAN uses initials, enter the expanded full name to avoid mismatches.</div>
      <label class="check fb-consent"><input type="checkbox" name="pan_consent" value="1" <?= !empty($old['pan_consent']) ? 'checked' : '' ?> required> I consent to PAN verification through an authorised agency for processing this application. <span class="fb-demo-label">Demo consent only</span></label>
    </section>
    <section class="fb-identity-panel">
      <div class="fb-panel-heading"><span class="fb-step-icon">02</span><div><h3>Address and contact details</h3><p>We use these details to identify your servicing branch.</p></div></div>
      <div class="form-grid">
        <?php foreach (personal_fields() as $f) render_field($f, $val($f[0])); ?>
      </div>
      <label class="check"><input type="checkbox" name="permanent_same" value="1" id="permSame" <?= ($old ? !empty($old['permanent_same']) : (($ap['permanent_same'] ?? 1) == 1)) ? 'checked' : '' ?>> Permanent address is the same as current address</label>
    </section>
    <section class="fb-identity-panel fb-verify-panel">
      <div class="fb-panel-heading"><span class="fb-step-icon">03</span><div><h3>Aadhaar verification</h3><p>Illustrative verification step for the prototype.</p></div></div>
      <div class="fb-security-note"><span>🔒</span><div><strong>Demo mode — do not enter real Aadhaar details or OTPs.</strong><p>This prototype is not connected to UIDAI or an OTP provider. Use fictional test data only. Real verification requires an authorised integration and appropriate consent.</p></div></div>
      <div class="form-grid">
        <div><label for="aadhaar_demo">Aadhaar number (demo placeholder)</label><input id="aadhaar_demo" name="aadhaar_demo" type="text" inputmode="numeric" maxlength="12" placeholder="Use fictional test digits only" autocomplete="off"><small class="fb-field-help">Not saved or sent to a server.</small></div>
        <div><label for="demo_otp">Demo OTP</label><div class="fb-otp-row"><input id="demo_otp" type="text" inputmode="numeric" maxlength="6" placeholder="6-digit demo code" autocomplete="off"><button class="aw-btn fb-otp-button" type="button" id="demoOtpBtn">Verify demo OTP</button></div><small id="demoOtpMsg" class="fb-field-help" aria-live="polite">No real OTP will be sent.</small></div>
      </div>
    </section>
    <div id="permBox" style="display:none"><label for="permanent_address">Permanent address</label>
      <input type="text" id="permanent_address" name="permanent_address" maxlength="200" value="<?= e($val('permanent_address')) ?>"></div>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=0">&larr; Back</a><button type="submit">Save &amp; continue</button></div>
  </form>
  <script>
    (function(){var c=document.getElementById('permSame'),b=document.getElementById('permBox');function t(){b.style.display=c.checked?'none':'block';}c.addEventListener('change',t);t();})();
    (function(){var btn=document.getElementById('demoOtpBtn'),otp=document.getElementById('demo_otp'),msg=document.getElementById('demoOtpMsg');if(!btn)return;btn.addEventListener('click',function(){if(!otp.value.trim()){msg.textContent='Enter a fictional 6-digit demo code to preview this interaction.';msg.className='fb-field-help fb-error';return;}if(!/^\\d{6}$/.test(otp.value.trim())){msg.textContent='Use exactly 6 digits for the demo code.';msg.className='fb-field-help fb-error';return;}msg.textContent='Demo interaction complete — no real Aadhaar verification occurred.';msg.className='fb-field-help fb-success';});})();
  </script>

<?php elseif ($step === 2): ?>
  <h2>Financial information</h2>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="2">
    <div class="form-grid">
      <?php foreach (financial_fields(($val('employment_type')) === 'student') as $f) render_field($f, $val($f[0])); ?>
    </div>
    <p class="muted">Demo prototype: use fictional details only.</p>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=1">&larr; Back</a><button type="submit">Save &amp; continue</button></div>
  </form>

<?php elseif ($step === 3): ?>
  <h2>Loan details</h2>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="3">
    <div class="form-grid">
      <?php foreach (loan_detail_fields($code) as $f) render_field($f, $val($f[0])); ?>
    </div>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=2">&larr; Back</a><button type="submit">Save &amp; continue</button></div>
  </form>

<?php elseif ($step === 4):
    $reqs = doc_requirements($code, $ap);
    $dq = $pdo->prepare('SELECT * FROM application_documents WHERE application_id = ?'); $dq->execute([$id]);
    $docs = []; foreach ($dq->fetchAll() as $d) $docs[$d['doc_key']] = $d; ?>
  <h2>Upload documents</h2>
  <p class="muted">PDF, JPG or PNG, up to 5 MB each. Use fictional documents only (demo prototype). Files are stored privately and only the branch handling your application can open them.</p>
  <?php foreach ($reqs as $k => [$label, $req]) render_doc_slot($app, $k, $label, $req, $docs[$k] ?? null, 'wizard', true); ?>
  <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="4">
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=3">&larr; Back</a><button type="submit">Continue to review</button></div>
  </form>

<?php else:
    $labels = all_field_labels($code);
    $dq = $pdo->prepare('SELECT doc_type, original_name FROM application_documents WHERE application_id = ? ORDER BY id'); $dq->execute([$id]); $docList = $dq->fetchAll();
    $bq = $pdo->prepare('SELECT name, city FROM branches WHERE id = ?'); $bq->execute([$app['branch_id']]); $branch = $bq->fetch();
    $skipAp = ['permanent_same', 'full_name', 'phone', 'email']; ?>
  <h2>Review &amp; submit</h2>
  <?php render_eligibility($elig['code'], $elig['reasons']); ?>

  <h3 class="step-h">Loan <a class="muted" href="apply.php?draft=<?= $id ?>">Edit</a></h3>
  <table>
    <tr><th>Loan type</th><td><?= e($app['product']) ?></td></tr>
    <tr><th>Amount / tenure</th><td><?= money($app['requested_amount']) ?> / <?= (int)$app['tenure_months'] ?> months (EMI about <?= money($emi) ?>)</td></tr>
    <?php foreach ($det as $k => $v): ?><tr><th><?= e($labels[$k][0] ?? $k) ?></th><td><?= e(show_value($labels, $k, $v)) ?></td></tr><?php endforeach; ?>
  </table>
  <h3 class="step-h">Personal &amp; financial <a class="muted" href="complete.php?id=<?= $id ?>&amp;step=1">Edit personal</a> | <a class="muted" href="complete.php?id=<?= $id ?>&amp;step=2">Edit financial</a></h3>
  <table>
    <tr><th>Name</th><td><?= e($acct['full_name']) ?></td></tr>
    <?php foreach ($ap as $k => $v): if (in_array($k, $skipAp, true) || $v === '' || $v === null) continue; ?>
      <tr><th><?= e($labels[$k][0] ?? $k) ?></th><td><?= e($k === 'account_number' ? str_repeat('•', max(0, strlen((string)$v) - 4)) . substr((string)$v, -4) : show_value($labels, $k, $v)) ?></td></tr>
    <?php endforeach; ?>
  </table>
  <h3 class="step-h">Documents <a class="muted" href="complete.php?id=<?= $id ?>&amp;step=4">Edit</a></h3>
  <ul><?php foreach ($docList as $d): ?><li><?= e($d['doc_type']) ?> - <span class="muted"><?= e($d['original_name']) ?></span></li><?php endforeach; ?></ul>

  <h3 class="step-h">Processing branch</h3>
  <p>Matched from your PIN code <strong><?= e($ap['pincode'] ?? '') ?></strong>: <strong><?= e($branch['name'] ?? 'To be assigned') ?></strong></p>
  <p class="muted">Your application is routed automatically to the appropriate branch using your PIN code. You do not need to choose or visit an office to submit this application.</p>

  <form method="post" style="margin-top:14px"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="5"><input type="hidden" name="action" value="submit">
    <label class="check"><input type="checkbox" name="decl_accurate" value="1"> I confirm that the information and documents I provided are accurate. (Demo prototype: fictional data only.)</label>
    <label class="check"><input type="checkbox" name="decl_privacy" value="1"> I accept the declaration and privacy terms and agree that the branch may contact me and verify my details.</label>
    <label class="check"><input type="checkbox" name="fast_track" value="1"> Request fast-track (priority) review. This does not guarantee approval.</label>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=4">&larr; Back</a><button type="submit">Submit application</button></div>
  </form>
<?php endif; ?>

  <form method="post" style="margin-top:18px" onsubmit="return confirm('Discard this draft and its uploaded files?')">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="discard">
    <button class="btn-sm btn-danger" type="submit">Discard draft</button>
  </form>
</div>
<script src="<?= BASE_URL ?>/assets/js/upload.js"></script>
<?php page_footer(); ?>
