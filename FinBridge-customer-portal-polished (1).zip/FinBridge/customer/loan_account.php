<?php
// Customer view of their loan account(s): balance, EMI schedule, payment history.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);
$custId = customer_id_for_user($pdo, current_user()['id']);

mark_overdue_installments($pdo);
$q = $pdo->prepare('SELECT la.*, p.name AS product FROM loan_accounts la JOIN loan_products p ON p.id = la.product_id
                    WHERE la.customer_id = ? ORDER BY la.id DESC');
$q->execute([$custId]);
$accounts = $q->fetchAll();

$sel = null;
foreach ($accounts as $a) { if ((int)$a['id'] === (int)($_GET['id'] ?? 0)) $sel = $a; }
if (!$sel && $accounts) $sel = $accounts[0];

page_header('Loan Account');
echo '<div class="cx-account-intro"><span class="cx-account-eyebrow">YOUR FINANCIAL OVERVIEW</span><h2>EMI &amp; repayment centre</h2><p>Review your loan balance, installment schedule and recorded payments in one place.</p></div>';
if (!$sel) {
    echo '<div class="card"><p class="muted">You do not have a loan account yet. It is created once your approved loan is disbursed.</p>'
       . '<p><a class="btn" href="applications.php">View my applications</a></p></div>';
} else {
    if (count($accounts) > 1) {
        echo '<p>';
        foreach ($accounts as $a) echo '<a class="btn-sm' . ($a['id'] == $sel['id'] ? '' : ' btn-line') . '" style="margin-right:6px" href="loan_account.php?id=' . (int)$a['id'] . '">' . e($a['product']) . ' - ' . e($a['account_no']) . '</a>';
        echo '</p>';
    }
    echo '<h3>' . e($sel['product']) . '</h3>';
    render_loan_account($pdo, $sel);
}
page_footer();
