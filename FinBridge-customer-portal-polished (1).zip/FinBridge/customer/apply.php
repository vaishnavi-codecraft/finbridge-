<?php
// Quick Apply (part 1): a few loan-specific questions, live EMI, indicative eligibility.
// The application is saved as a DRAFT; the rest is collected in complete.php.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$user   = current_user();
$custId = customer_id_for_user($pdo, $user['id']);
if (!$custId) exit('Customer profile not found.');

$products = $pdo->query('SELECT * FROM loan_products WHERE is_active = 1 ORDER BY id')->fetchAll();

// Editing an existing draft?
$draft = null;
$draftId = (int)($_GET['draft'] ?? $_POST['draft'] ?? 0);
if ($draftId) {
    $s = $pdo->prepare("SELECT a.*, p.code AS product_code FROM loan_applications a JOIN loan_products p ON p.id = a.product_id
                        WHERE a.id = ? AND a.customer_id = ? AND a.status = 'draft'");
    $s->execute([$draftId, $custId]);
    $draft = $s->fetch();
    if (!$draft) { http_response_code(404); exit('Draft not found.'); }
}

$code = $draft ? $draft['product_code'] : strtoupper($_GET['p'] ?? $_POST['p'] ?? '');
$product = null;
foreach ($products as $p) { if ($p['code'] === $code) $product = $p; }

// Step 0: choose a loan type
if (!$product) {
    page_header('Choose a Loan');
    echo '<div class="apply-intro"><span class="apply-eyebrow">CHOOSE WHAT FITS YOUR PLAN</span><h1 class="cx-title">Explore your loan options</h1><p class="muted">Select a product to begin. Amounts, rates and tenure are taken from your active FinBridge configuration.</p></div>';
    echo '<div class="cx-apply-product-grid">';
    $applyIcons = ['PERSONAL'=>'✦','BUSINESS'=>'▣','VEHICLE'=>'↗','HOME'=>'⌂','EDUCATION'=>'▤','DURABLE'=>'◇','MEDICAL'=>'＋'];
    foreach ($products as $p) {
        $pc = strtoupper($p['code']); $pi = $applyIcons[$pc] ?? '✦';
        echo '<article class="cx-apply-product cx-product-' . e(strtolower($pc)) . '"><div class="cx-apply-product-top"><span class="cx-apply-product-icon">' . e($pi) . '</span><span class="cx-apply-arrow">↗</span></div>'
           . '<h3>' . e($p['name']) . '</h3><p class="cx-apply-product-desc">' . e(match($pc) { 'PERSONAL'=>'For personal expenses and life events.', 'BUSINESS'=>'Support working capital and business growth.', 'VEHICLE'=>'Explore financing for eligible vehicles.', 'HOME'=>'For eligible housing needs.', 'EDUCATION'=>'Support eligible study expenses.', 'DURABLE'=>'Finance eligible appliances and goods.', 'MEDICAL'=>'For eligible healthcare expenses.', default=>'Explore this available financing option.' }) . '</p>'
           . '<small>Configured amount range</small><strong class="cx-apply-amount">' . money($p['min_amount']) . ' – ' . money($p['max_amount']) . '</strong>'
           . '<div class="cx-apply-meta"><span>Interest rate</span><b>' . e($p['interest_rate']) . '% p.a.</b></div><div class="cx-apply-meta"><span>Maximum tenure</span><b>' . (int)$p['max_tenure_months'] . ' months</b></div>'
           . '<a class="cx-btn cx-apply-cta" href="../loan.php?type=' . e($p['code']) . '">Apply now <span>→</span></a></article>';
    }
    echo '</div><p class="muted" style="margin-top:16px">Rates are indicative. An application is not an approval or a guarantee of disbursement.</p>';
    page_footer();
    exit;
}

// ================= HDFC-style stepper for one loan =================
$draftAp  = $draft ? app_applicant($draft) : [];
$draftDet = $draft ? (json_decode($draft['details_json'] ?? '{}', true) ?: []) : [];
$prof = $pdo->prepare('SELECT u.full_name, u.phone, c.dob, c.employment_type, c.monthly_income FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id = ?');
$prof->execute([$custId]);
$prof = $prof->fetch() ?: [];
$val = array_merge(array_filter($prof, fn($v) => $v !== null), $draftAp, $draftDet);
$pf = $_SESSION['loan_prefill'] ?? null;   // choices made on the public loan page (e.g. new / used)
if (!$draft && $pf && ($pf['code'] ?? '') === $code) $val = array_merge($val, $pf['fields'] ?? []);
if (!$draft && !empty($_GET['pf']) && is_array($_GET['pf'])) {   // choices made on loan.php (e.g. new / used)
    foreach ((loan_catalog()[$code]['choices'] ?? []) as $ch) { $v = (string)($_GET['pf'][$ch['field']] ?? ''); if (isset($ch['opts'][$v])) $val[$ch['field']] = $v; }
}
if ($draft) { $val['requested_amount'] = $draft['requested_amount']; $val['tenure_months'] = $draft['tenure_months']; }
$derived = loan_derived($code);
$mobile  = $draftAp['verified_mobile'] ?? ($prof['phone'] ?? '');
$sv = $_SESSION['otp_verified'] ?? null;
$alreadyVerified = $sv && time() - $sv['at'] < 3600;
$steps = ['PAN Details', 'Address Details', 'Employment Details', 'Loan Details', 'Documents'];
$nm = preg_split('/\s+/', trim($prof['full_name'] ?? ''));
$dFirst = $val['pan_first_name'] ?? ($nm[0] ?? ''); $dLast = $val['pan_last_name'] ?? (count($nm) > 1 ? end($nm) : '');
$dMid = $val['pan_middle_name'] ?? (count($nm) > 2 ? implode(' ', array_slice($nm, 1, -1)) : '');
$loanFields = loan_fields($code);

page_header('Apply - ' . $product['name'], false);
?>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/apply-wizard.css">
<div class="aw">
  <div class="aw-top">
    <a class="aw-back" href="apply.php">&larr; All loans</a>
    <h1><?= e($product['name']) ?></h1>
    <p><?= e($product['interest_rate']) ?>% p.a. &middot; <?= money($product['min_amount']) ?> to <?= money($product['max_amount']) ?> &middot; up to <?= (int)$product['max_tenure_months'] ?> months</p>
  </div>

  <ol class="aw-steps" id="awSteps">
    <?php foreach ($steps as $i => $s): ?><li data-s="<?= $i + 1 ?>"><b><?= $i + 1 ?></b><span><?= e($s) ?></span></li><?php endforeach; ?>
  </ol>

  <form id="awForm" class="aw-card" autocomplete="off" novalidate>
    <input type="hidden" id="csrf" value="<?= e(csrf_token()) ?>">
    <div id="awMsg" class="aw-msg" role="alert"></div>

    <!-- STEP 1: mobile OTP + PAN details (HDFC style) -->
    <section class="aw-step" data-s="1">
      <h2>Give us your PAN details to get started!</h2>
      <label>Mobile number</label>
      <div class="aw-row">
        <span class="aw-prefix">+91</span>
        <input type="tel" id="mobile" inputmode="numeric" maxlength="10" value="<?= e($mobile) ?>" placeholder="10-digit mobile">
        <button type="button" class="aw-btn aw-line" id="btnSend">Send OTP</button>
      </div>
      <div id="otpBox" style="display:none">
        <label>Enter the 6-digit OTP</label>
        <div class="aw-row"><input type="text" id="otp" inputmode="numeric" maxlength="6" placeholder="------"><button type="button" class="aw-btn" id="btnVerify">Verify</button></div>
        <div id="demoOtp" class="aw-demo"></div>
      </div>
      <div id="verifiedTag" class="aw-ok" style="display:none">&#10003; Mobile number verified</div>

      <label for="pan">PAN Number *</label>
      <input type="text" id="pan" name="pan_display" maxlength="10" placeholder="PAN Number" style="text-transform:uppercase" value="<?= e($val['pan'] ?? '') ?>">
      <div class="aw-grid">
        <div><label for="dob">Date of birth as per PAN Card *</label><input type="date" id="dob" name="dob" max="<?= date('Y-m-d') ?>" value="<?= e($val['dob'] ?? '') ?>"></div>
        <div><label for="pan_salutation">Salutation *</label>
          <select id="pan_salutation" name="pan_salutation"><option value="">Salutation *</option>
            <?php foreach (['Mr', 'Mrs', 'Ms', 'Dr'] as $sl): ?><option value="<?= $sl ?>" <?= ($val['pan_salutation'] ?? '') === $sl ? 'selected' : '' ?>><?= $sl ?></option><?php endforeach; ?></select></div>
        <div><label for="pan_first_name">First Name as per PAN Card *</label><input type="text" id="pan_first_name" name="pan_first_name" maxlength="40" placeholder="First Name" value="<?= e($dFirst) ?>"></div>
        <div><label for="pan_middle_name">Middle Name as per PAN Card</label><input type="text" id="pan_middle_name" name="pan_middle_name" maxlength="40" placeholder="Middle Name" value="<?= e($dMid) ?>"></div>
        <div><label for="pan_last_name">Last Name as per PAN Card *</label><input type="text" id="pan_last_name" name="pan_last_name" maxlength="40" placeholder="Last Name" value="<?= e($dLast) ?>"></div>
      </div>
      <div class="aw-note"><strong>Note:</strong>
        <ol><li>Ensure name entered matches PAN records.</li>
        <li>If PAN shows initials, enter full name. e.g. If name on PAN Card is 'D K Bansal' it should be mentioned as 'Deepak Kumar Bansal'. Any mismatch may result in application rejection.</li></ol></div>
      <label class="aw-check"><input type="checkbox" id="consent" name="consent" value="1"> I specifically consent for you to get my PAN verified from NSDL / any other agency and receive my personal details to process the same in accordance with the consent already provided by me. (Demo: use fictional details.)</label>
    </section>

    <!-- STEP 2: personal -->
    <section class="aw-step" data-s="2" hidden>
      <h2>Address Details</h2>
      <div class="aw-grid"><?php foreach (personal_fields() as $f) { if ($f[0] === 'dob' || str_starts_with($f[0], 'co_applicant_')) continue; render_field($f, $val[$f[0]] ?? ''); } ?></div>
      <div class="aw-coapp-card">
        <div class="aw-coapp-head"><span class="aw-coapp-icon">♧</span><div><h3>Co-applicant details</h3><p>Optional for most loans. Add a co-applicant only if relevant to your application.</p></div></div>
        <label class="aw-check"><input type="checkbox" id="hasCoApplicant" <?= !empty($val['co_applicant_name']) ? 'checked' : '' ?>> I want to add a co-applicant</label>
        <div id="coApplicantFields" class="aw-grid" <?= empty($val['co_applicant_name']) ? 'hidden' : '' ?>><?php foreach (personal_fields() as $f) { if (!str_starts_with($f[0], 'co_applicant_')) continue; render_field($f, $val[$f[0]] ?? ''); } ?></div>
      </div>
      <label class="aw-check"><input type="checkbox" name="permanent_same" id="permSame" value="1" <?= (($val['permanent_same'] ?? 1) == 1) ? 'checked' : '' ?>> Permanent address is same as current address</label>
      <div id="permBox" style="display:none"><label for="permanent_address">Permanent address</label><input type="text" id="permanent_address" name="permanent_address" maxlength="200" value="<?= e($val['permanent_address'] ?? '') ?>"></div>
    </section>

    <!-- STEP 3: employment -->
    <section class="aw-step" data-s="3" hidden>
      <h2>Employment Details</h2>
      <div class="aw-grid"><?php foreach (financial_fields(($val['employment_type'] ?? '') === 'student') as $f) render_field($f, $val[$f[0]] ?? ''); ?></div>
      <p class="aw-sub">Bank details are used only for the simulated disbursement.</p>
    </section>

    <!-- STEP 4: loan details -->
    <section class="aw-step" data-s="4" hidden>
      <h2><?= e($product['name']) ?> details</h2>
      <div class="aw-grid">
        <?php foreach ($loanFields as $f) render_field($f, $val[$f[0]] ?? ''); ?>
        <div><label for="requested_amount">Loan amount needed (₹)</label>
          <?php if ($derived): ?><input type="text" id="requested_amount" readonly placeholder="Price minus down payment">
          <?php else: ?><input type="number" step="any" min="0" id="requested_amount" name="requested_amount" value="<?= e($val['requested_amount'] ?? '') ?>"><?php endif; ?></div>
        <div><label for="tenure_months">Tenure (months)</label>
          <input type="number" id="tenure_months" name="tenure_months" min="<?= (int)$product['min_tenure_months'] ?>" max="<?= (int)$product['max_tenure_months'] ?>" value="<?= e($val['tenure_months'] ?? '') ?>"></div>
      </div>
      <div class="aw-offer"><div><small>Indicative EMI</small><strong id="emiOut">-</strong></div><div><small>Rate</small><strong><?= e($product['interest_rate']) ?>% p.a.</strong></div><div><small>Total interest (approx.)</small><strong id="intOut">-</strong></div></div>
    </section>

    <!-- STEP 5: documents -->
    <section class="aw-step" data-s="5" hidden>
      <div id="eligBox"></div>
      <h2>Upload documents</h2>
      <p class="aw-sub">PDF, JPG or PNG, up to 5 MB each. Use fictional documents only (demo).</p>
      <div id="docList"></div>
    </section>

    <div class="aw-nav">
      <button type="button" class="aw-btn aw-line" id="btnBack" style="visibility:hidden">Back</button>
      <button type="button" class="aw-btn" id="btnNext">Continue</button>
    </div>
  </form>
</div>

<script>
(function () {
  var CODE = <?= json_encode($code) ?>, RATE = <?= json_encode((float)$product['interest_rate']) ?>, DERIVED = <?= json_encode($derived) ?>;
  var DRAFT = <?= (int)($draft['id'] ?? 0) ?>, verified = <?= $alreadyVerified ? 'true' : 'false' ?>, step = <?= $alreadyVerified ? 2 : 1 ?>, appId = DRAFT;
  var $ = function (id) { return document.getElementById(id); };
  var form = $('awForm'), msg = $('awMsg'), csrf = $('csrf').value, API = 'apply_api.php';

  function show(n) {
    step = n;
    document.querySelectorAll('.aw-step').forEach(function (s) { s.hidden = +s.dataset.s !== n; });
    document.querySelectorAll('#awSteps li').forEach(function (li) {
      var k = +li.dataset.s; li.className = k === n ? 'cur' : (k < n ? 'done' : '');
      li.querySelector('b').textContent = k < n ? '\u2713' : k;
    });
    $('btnBack').style.visibility = n === 1 ? 'hidden' : 'visible';
    $('btnNext').textContent = n === 4 ? 'Check eligibility & continue' : (n === 5 ? 'Review & submit' : 'Continue');
    msg.style.display = 'none'; window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function say(t, ok) { msg.textContent = t; msg.className = 'aw-msg ' + (ok ? 'ok' : 'err'); msg.style.display = 'block'; }
  function post(data) {
    var fd = new FormData(); fd.append('csrf', csrf);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(API, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
  }
  function setVerified() { verified = true; $('verifiedTag').style.display = 'block'; $('otpBox').style.display = 'none'; $('btnSend').style.display = 'none'; $('mobile').readOnly = true; }

  // ---- OTP ----
  $('btnSend').onclick = function () {
    var b = this; b.disabled = true;
    post({ action: 'send_otp', mobile: $('mobile').value }).then(function (j) {
      b.disabled = false; say(j.message, j.ok);
      if (j.ok) { $('otpBox').style.display = 'block'; $('otp').focus(); $('demoOtp').textContent = j.demo_otp ? 'Demo mode - your OTP is ' + j.demo_otp : ''; b.textContent = 'Resend OTP'; }
    }).catch(function () { b.disabled = false; say('Could not send OTP. Try again.'); });
  };
  $('btnVerify').onclick = function () {
    post({ action: 'verify_otp', otp: $('otp').value }).then(function (j) { say(j.message, j.ok); if (j.ok) setVerified(); });
  };
  if (verified) setVerified();

  // ---- permanent address toggle ----
  var ps = $('permSame'); function pt() { $('permBox').style.display = ps.checked ? 'none' : 'block'; } ps.onchange = pt; pt();
  var coToggle = $('hasCoApplicant'), coFields = $('coApplicantFields'); if (coToggle && coFields) { function syncCo() { coFields.hidden = !coToggle.checked; coFields.querySelectorAll('input,select').forEach(function (el) { if (!coToggle.checked) el.value = ''; }); } coToggle.addEventListener('change', syncCo); syncCo(); }

  // ---- live EMI ----
  function amount() {
    if (DERIVED) { var p = parseFloat(($(DERIVED[0]) || {}).value) || 0, d = parseFloat(($(DERIVED[1]) || {}).value) || 0, a = Math.max(p - d, 0); $('requested_amount').value = a > 0 ? a : ''; return a; }
    return parseFloat($('requested_amount').value) || 0;
  }
  function emi() {
    var P = amount(), n = parseInt($('tenure_months').value, 10) || 0, r = RATE / 1200;
    if (P <= 0 || n <= 0) { $('emiOut').textContent = '-'; $('intOut').textContent = '-'; return; }
    var f = Math.pow(1 + r, n), e = r === 0 ? P / n : P * r * f / (f - 1);
    $('emiOut').textContent = '\u20B9' + e.toLocaleString('en-IN', { maximumFractionDigits: 0 });
    $('intOut').textContent = '\u20B9' + Math.max(e * n - P, 0).toLocaleString('en-IN', { maximumFractionDigits: 0 });
  }
  form.addEventListener('input', emi); emi();

  // ---- validation of the visible step ----
  function validStep(n) {
    if (n === 1) {
      if (!verified) { say('Please verify your mobile number with OTP.'); return false; }
      var pan = $('pan').value.trim().toUpperCase();
      if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan)) { say('Enter a valid PAN, e.g. ABCDE1234F.'); return false; }
      if (pan[3] !== 'P') { say('Only individual PAN cards (4th letter P) are accepted.'); return false; }
      if (!$('dob').value) { say('Enter your date of birth as per PAN card.'); return false; }
      if (!$('pan_salutation').value) { say('Select a salutation.'); return false; }
      if (!$('pan_first_name').value.trim() || !$('pan_last_name').value.trim()) { say('Enter your first and last name as per PAN card.'); return false; }
      if (!$('consent').checked) { say('Please accept the consent to continue.'); return false; }
      return true;
    }
    var sec = document.querySelector('.aw-step[data-s="' + n + '"]'), els = sec.querySelectorAll('input,select');
    for (var i = 0; i < els.length; i++) {
      var el = els[i]; if (el.offsetParent === null || el.readOnly) continue;
      if (!el.checkValidity()) { el.reportValidity(); return false; }
    }
    return true;
  }

  // ---- docs ----
  function renderDocs(docs) {
    var box = $('docList'); box.innerHTML = '';
    docs.forEach(function (d) {
      var row = document.createElement('div'); row.className = 'aw-doc';
      row.innerHTML = '<div><strong></strong> <em class="' + (d.required ? 'req' : '') + '">' + (d.required ? 'Required' : 'Optional') + '</em><div class="aw-file"></div></div>' +
        '<div class="aw-up"><input type="file" accept=".pdf,.jpg,.jpeg,.png"><button type="button" class="aw-btn aw-sm">Upload</button></div>';
      row.querySelector('strong').textContent = d.label;
      var fileEl = row.querySelector('.aw-file'); fileEl.textContent = d.file ? '\u2713 ' + d.file : 'Not uploaded yet';
      row.querySelector('button').onclick = function () {
        var inp = row.querySelector('input'), f = inp.files[0], b = this;
        if (!f) { fileEl.textContent = 'Choose a file first.'; return; }
        if (f.size > 5242880) { fileEl.textContent = 'File is larger than 5 MB.'; return; }
        var fd = new FormData(); fd.append('csrf', csrf); fd.append('app', appId); fd.append('doc_key', d.key); fd.append('back', 'wizard'); fd.append('file', f);
        b.disabled = true; fileEl.textContent = 'Uploading...';
        fetch('upload_document.php', { method: 'POST', body: fd, headers: { 'X-Requested-With': 'XMLHttpRequest' }, credentials: 'same-origin' })
          .then(function (r) { return r.json(); }).then(function (j) { b.disabled = false; fileEl.textContent = j.ok ? '\u2713 ' + f.name : j.message; if (j.ok) d.file = f.name; });
      };
      box.appendChild(row);
    });
  }

  // ---- navigation ----
  $('btnBack').onclick = function () { if (step > 1) show(step - 1); };
  $('btnNext').onclick = function () {
    if (!validStep(step)) return;
    if (step < 4) { show(step + 1); return; }
    if (step === 4) {
      var data = { action: 'save', p: CODE, draft: appId || '' };
      new FormData(form).forEach(function (v, k) { data[k] = v; });
      delete data.pan_display; data.pan = $('pan').value.trim().toUpperCase(); data.consent = $('consent').checked ? 1 : '';
      if (!$('permSame').checked) delete data.permanent_same;
      this.disabled = true; var b = this;
      post(data).then(function (j) {
        b.disabled = false;
        if (!j.ok) { say(j.message); if (j.goto) show(j.goto); return; }
        appId = j.id; renderDocs(j.docs);
        var cls = j.eligibility.code, h = '<div class="elig elig-' + cls + '"><strong></strong><div class="aw-sub"></div></div>';
        $('eligBox').innerHTML = h;
        $('eligBox').querySelector('strong').textContent = j.eligibility.label + ' \u2022 EMI about \u20B9' + Number(j.emi).toLocaleString('en-IN', { maximumFractionDigits: 0 }) + '/month';
        $('eligBox').querySelector('.aw-sub').textContent = j.eligibility.reasons.length ? j.eligibility.reasons.join(' ') : 'Indicative only - not an approval.';
        show(5);
      }).catch(function () { b.disabled = false; say('Could not save. Check your connection and try again.'); });
      return;
    }
    window.location = 'complete.php?id=' + appId + '&step=5';
  };
  show(step);
})();
</script>
<?php page_footer(); ?>
