<?php
// FinBridge loan page: one page per loan type. Mobile number + OTP first, then the application steps page.
require __DIR__ . '/includes/bootstrap.php';
$u = current_user();

$rows = $pdo->query("SELECT code, name, min_amount, max_amount, interest_rate, min_tenure_months, max_tenure_months FROM loan_products WHERE is_active = 1 ORDER BY id")->fetchAll();
$P = []; foreach ($rows as $r) $P[$r['code']] = $r;
$type = strtoupper(trim((string)($_GET['type'] ?? '')));
if (!$u || $u['role'] !== 'customer') {   // sign in / sign up first, then come back to this loan
    header('Location: ' . BASE_URL . '/login.php?loan=' . rawurlencode($type)); exit;
}
if (!isset($P[$type])) { header('Location: ' . BASE_URL . '/index.php#types'); exit; }
$p = $P[$type]; $cat = loan_catalog(); $c = $cat[$type] ?? null;
if (!$c) { header('Location: ' . BASE_URL . '/index.php#types'); exit; }
$ic = site_icons(); $B = BASE_URL;
$isCust = $u && $u['role'] === 'customer';
$phone = '';
if ($isCust) { $s = $pdo->prepare('SELECT phone FROM users WHERE id = ?'); $s->execute([$u['id']]); $phone = (string)$s->fetchColumn(); }
$startUrl = $B . '/customer/apply.php?p=' . rawurlencode($type);
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0b1f5c">
<title><?= e($p['name']) ?> | FinBridge</title>
<link rel="stylesheet" href="<?= e($B) ?>/assets/css/home.css">
<link rel="stylesheet" href="<?= e($B) ?>/assets/css/loan.css">
</head>
<body>
<?php site_header($P); ?>

<div class="crumb wrap"><a href="<?= e($B) ?>/customer/dashboard.php">Dashboard</a> <span>/</span> <a href="<?= e($B) ?>/customer/apply.php">Apply for a loan</a> <span>/</span> <b><?= e($p['name']) ?></b></div>

<!-- STAGE 2: appears after the OTP is verified -->
<section class="st2" id="stage2">
  <div class="wrap">
    <div class="st2-head">
      <span class="ok-badge">Welcome, <?= e(explode(' ', $u['name'])[0]) ?></span>
      <h1><?= $c['emoji'] ?> Your <?= e($p['name']) ?> application</h1>
      <p>Complete these 5 simple steps. You can save a draft and come back any time.</p>
    </div>
    <?php if ($c['choices']): ?>
    <div class="pickcard">
      <h3>Tell us what you need</h3>
      <?php foreach ($c['choices'] as $ch): ?>
      <div class="grp" data-field="<?= e($ch['field']) ?>"><label><?= e($ch['label']) ?></label>
        <div class="pills"><?php $first = true; foreach ($ch['opts'] as $val => $o): ?><button type="button" class="pill<?= $first ? ' on' : '' ?>" data-v="<?= e($val) ?>"><span><?= $o[1] ?></span><?= e($o[0]) ?></button><?php $first = false; endforeach; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="stepsbar" aria-hidden="true"><i class="on"></i><i></i><i></i><i></i><i></i></div>
    <div class="slist">
      <?php $em = ['🧑‍💼', '📝', '🎯', '📤', '🚀']; foreach ($c['steps'] as $i => $s): ?>
      <article class="srow rv">
        <div class="s-ic"><span><?= $em[$i] ?></span><b><?= $i + 1 ?></b></div>
        <div class="s-tx"><h3><?= e($s[0]) ?></h3><p><?= e($s[1]) ?></p><span class="nst">Not started</span></div>
      </article>
      <?php endforeach; ?>
    </div>
    <div class="st2-cta">
      <button type="button" class="btn btn-solid btn-lg" id="btnStart">START APPLICATION →</button>
      <a class="btn btn-ghost" href="<?= e($B) ?>/index.php#types">← Choose a different loan</a>
    </div>
    <div class="st2-need">
      <h3>📋 Keep these handy</h3>
      <ul><?php foreach ($c['docs'] as $d): ?><li><?= e($d) ?></li><?php endforeach; ?></ul>
      <p class="mut">This is an indicative check. Approval depends on document verification and manager review.</p>
    </div>
  </div>
</section>

<main>
<section class="sec" id="lp-why"><div class="wrap">
  <h2 class="sec-t">Why choose our <?= e($p['name']) ?>?</h2>
  <p class="sec-s">Everything you need to know before you apply.</p>
  <div class="why">
    <?php foreach ($c['perks'] as $k): ?><div class="rv"><span><?= $k[0] ?></span><h3><?= e($k[1]) ?></h3><p><?= e($k[2]) ?>.</p></div><?php endforeach; ?>
  </div>
</div></section>

<section class="sec sec-tint"><div class="wrap">
  <h2 class="sec-t">Documents you may need</h2>
  <div class="docgrid">
    <?php foreach ($c['docs'] as $d): ?><div class="rv"><span>📄</span><?= e($d) ?></div><?php endforeach; ?>
  </div>
</div></section>

<section class="sec"><div class="wrap">
  <h2 class="sec-t">Explore other loans</h2>
  <div class="mini">
    <?php foreach ($P as $oc => $op): if ($oc === $type) continue; ?>
    <a class="mini-c rv" href="<?= e(loan_url($oc)) ?>"><span class="tile-ic"><?= svgi($ic, $oc, 24) ?></span><b><?= e($op['name']) ?></b><small>From <?= e($op['interest_rate']) ?>% p.a.</small><i>→</i></a>
    <?php endforeach; ?>
  </div>
</div></section>
</main>

<?php site_footer($P); ?>
<script>
(function(){
  var $$=function(s){return [].slice.call(document.querySelectorAll(s))};
  var START=<?= json_encode($startUrl) ?>;
  $$('.grp').forEach(function(g){g.addEventListener('click',function(e){var b=e.target.closest('.pill');if(!b)return;
    g.querySelectorAll('.pill').forEach(function(x){x.classList.remove('on')});b.classList.add('on')})});
  document.getElementById('btnStart').onclick=function(){
    var q='';$$('.grp').forEach(function(g){var on=g.querySelector('.pill.on');if(on)q+='&pf['+encodeURIComponent(g.dataset.field)+']='+encodeURIComponent(on.dataset.v)});
    location.href=START+q};
  $$('.rv').forEach(function(r,i){setTimeout(function(){r.classList.add('in')},120*i)});
})();
</script>
</body></html>
