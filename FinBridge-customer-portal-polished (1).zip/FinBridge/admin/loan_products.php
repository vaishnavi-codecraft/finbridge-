<?php
// Admin: edit loan product rates, amounts and tenures. (Existing applications keep the rate they were created with.)
require __DIR__ . '/../includes/bootstrap.php';
require_role(['admin']);
$me = current_user();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $name = trim((string)($_POST['name'] ?? ''));
    $minA = round((float)($_POST['min_amount'] ?? 0), 2);  $maxA = round((float)($_POST['max_amount'] ?? 0), 2);
    $rate = round((float)($_POST['interest_rate'] ?? -1), 2);
    $minT = (int)($_POST['min_tenure_months'] ?? 0);        $maxT = (int)($_POST['max_tenure_months'] ?? 0);
    $active = empty($_POST['is_active']) ? 0 : 1;

    $ex = $pdo->prepare('SELECT * FROM loan_products WHERE id = ?'); $ex->execute([$id]); $old = $ex->fetch();
    if (!$old) $errors[] = 'Loan product not found.';
    if (mb_strlen($name) < 3 || mb_strlen($name) > 80) $errors[] = 'Name must be 3 to 80 characters.';
    if ($minA <= 0 || $maxA < $minA) $errors[] = 'Amounts: minimum must be above 0 and the maximum at least the minimum.';
    if ($maxA > 99999999) $errors[] = 'Maximum amount is too large.';
    if ($rate < 0 || $rate > 60) $errors[] = 'Interest rate must be between 0 and 60 percent a year.';
    if ($minT < 1 || $maxT < $minT || $maxT > 480) $errors[] = 'Tenure: minimum at least 1 month, maximum at least the minimum and at most 480 months.';
    if (!$errors) {
        $pdo->prepare('UPDATE loan_products SET name=?, min_amount=?, max_amount=?, interest_rate=?, min_tenure_months=?, max_tenure_months=?, is_active=? WHERE id=?')
            ->execute([$name, $minA, $maxA, $rate, $minT, $maxT, $active, $id]);
        audit($pdo, (int)$me['id'], 'product_updated', 'loan_product', $id,
              $old['code'] . ': rate ' . $old['interest_rate'] . '->' . $rate . ', amt ' . $minA . '-' . $maxA . ', tenure ' . $minT . '-' . $maxT . ', active ' . $active);
        set_flash($old['code'] . ' updated.');
        header('Location: loan_products.php'); exit;
    }
}

$products = $pdo->query('SELECT * FROM loan_products ORDER BY id')->fetchAll();
page_header('Loan Products');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
foreach ($errors as $er) echo '<div class="error">' . e($er) . '</div>';
?>
<p class="muted">Changes apply to new applications only. Applications and loans already created keep their own rate, amount and tenure. An inactive product no longer appears when customers apply.</p>
<?php foreach ($products as $p): ?>
<form id="pf<?= (int)$p['id'] ?>" method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"></form>
<?php endforeach; ?>
<div class="table-wrap"><table>
  <tr><th>Code</th><th>Name</th><th>Min amount</th><th>Max amount</th><th>Rate % p.a.</th><th>Min months</th><th>Max months</th><th>Active</th><th></th></tr>
  <?php foreach ($products as $p): $f = 'pf' . (int)$p['id']; ?>
  <tr>
    <td><?= e($p['code']) ?></td>
    <td><input form="<?= $f ?>" type="text" name="name" value="<?= e($p['name']) ?>" maxlength="80" required></td>
    <td><input form="<?= $f ?>" type="number" step="0.01" min="1" name="min_amount" value="<?= e($p['min_amount']) ?>" required style="width:110px"></td>
    <td><input form="<?= $f ?>" type="number" step="0.01" min="1" name="max_amount" value="<?= e($p['max_amount']) ?>" required style="width:120px"></td>
    <td><input form="<?= $f ?>" type="number" step="0.01" min="0" max="60" name="interest_rate" value="<?= e($p['interest_rate']) ?>" required style="width:80px"></td>
    <td><input form="<?= $f ?>" type="number" min="1" max="480" name="min_tenure_months" value="<?= (int)$p['min_tenure_months'] ?>" required style="width:70px"></td>
    <td><input form="<?= $f ?>" type="number" min="1" max="480" name="max_tenure_months" value="<?= (int)$p['max_tenure_months'] ?>" required style="width:70px"></td>
    <td><input form="<?= $f ?>" type="checkbox" name="is_active" value="1" <?= $p['is_active'] ? 'checked' : '' ?>></td>
    <td><button form="<?= $f ?>" class="btn-sm" type="submit">Save</button></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php page_footer();
