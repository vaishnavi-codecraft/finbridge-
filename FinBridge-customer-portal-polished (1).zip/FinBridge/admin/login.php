<?php
require __DIR__ . '/../includes/bootstrap.php';
// Same browser = same session. If a user of a different portal is signed in, sign them out so this portal's login can be used.
if (current_user() && !in_array(current_user()['role'], ['admin'], true)) { $_SESSION = []; }
if (current_user()) redirect_to_home();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $error = attempt_login($pdo, trim($_POST['identifier'] ?? ''), $_POST['password'] ?? '', 'admin');
}
auth_start('admin', 'Administrator Sign In', ['Staff sign in', BASE_URL . '/staff/login.php']);
?>
      <h2 class="au-title">Admin Sign In</h2>
      <p class="au-lead">Head office administration for FinBridge.</p>
      <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="au-field">
          <label for="identifier">ADMIN ID OR EMAIL</label>
          <input type="text" id="identifier" name="identifier" placeholder="e.g. ADM-001" required autofocus>
        </div>
        <?php auth_password_field('password', 'PASSWORD', 'Enter your password'); ?>
        <a class="au-forgot" href="#" data-modal="forgot">Forgot password?</a>
        <button class="au-btn" type="submit">Sign In <span>→</span></button>
      </form>
      <p class="au-hint">Authorised administrators only.</p>
<?php auth_end();
