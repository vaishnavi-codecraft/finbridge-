<?php
// Admin overview: reports across branches and an audit log viewer.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['admin']);
mark_overdue_installments($pdo);

$one = fn(string $sql) => $pdo->query($sql)->fetchColumn();
$totalApps   = (int)$one("SELECT COUNT(*) FROM loan_applications WHERE status <> 'draft'");
$disbursed   = (float)$one("SELECT COALESCE(SUM(amount),0) FROM disbursement_transactions WHERE status = 'success'");
$outstanding = (float)$one("SELECT COALESCE(SUM(outstanding_balance),0) FROM loan_accounts WHERE status = 'active'");
$collected   = (float)$one("SELECT COALESCE(SUM(amount),0) FROM payments");
$overdueCnt  = (int)$one("SELECT COUNT(*) FROM repayment_schedule WHERE status = 'overdue'");
$overdueAmt  = (float)$one("SELECT COALESCE(SUM(emi_amount),0) FROM repayment_schedule WHERE status = 'overdue'");

$byStatus = $pdo->query("SELECT status, COUNT(*) n FROM loan_applications WHERE status <> 'draft' GROUP BY status ORDER BY n DESC")->fetchAll();
$byProduct = $pdo->query("SELECT p.name, COUNT(a.id) n, COALESCE(SUM(a.requested_amount),0) amt
                          FROM loan_products p LEFT JOIN loan_applications a ON a.product_id = p.id AND a.status <> 'draft' GROUP BY p.id ORDER BY p.id")->fetchAll();
$byBranch = $pdo->query("SELECT b.name, COUNT(a.id) n,
                                SUM(a.status IN ('approved','agreement_pending','ready_for_disbursement','disbursement_failed','active','closed')) approved,
                                SUM(a.status = 'rejected') rejected
                         FROM branches b LEFT JOIN loan_applications a ON a.branch_id = b.id AND a.status <> 'draft' GROUP BY b.id ORDER BY b.name")->fetchAll();
$maxStatus = max(1, ...array_map(fn($r) => (int)$r['n'], $byStatus ?: [['n' => 1]]));

// ---- audit log viewer ----
$action = trim((string)($_GET['action'] ?? ''));
$q      = trim((string)($_GET['q'] ?? ''));
$page   = max(1, (int)($_GET['p'] ?? 1));
$per    = 50;
$where = []; $args = [];
if ($action !== '') { $where[] = 'l.action = ?'; $args[] = $action; }
if ($q !== '')      { $where[] = '(l.details LIKE ? OR u.full_name LIKE ? OR u.employee_code LIKE ? OR l.entity LIKE ?)'; array_push($args, "%$q%", "%$q%", "%$q%", "%$q%"); }
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$cnt = $pdo->prepare("SELECT COUNT(*) FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id $w"); $cnt->execute($args);
$total = (int)$cnt->fetchColumn(); $pages = max(1, (int)ceil($total / $per)); $page = min($page, $pages);
$ls = $pdo->prepare("SELECT l.*, u.full_name, u.employee_code FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id $w ORDER BY l.id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
$ls->execute($args); $logs = $ls->fetchAll();
$actions = $pdo->query('SELECT DISTINCT action FROM audit_logs ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);
$qs = fn(int $p) => '?' . http_build_query(['action' => $action, 'q' => $q, 'p' => $p]) . '#audit';

page_header('Administrator Overview');
?>
<div class="stats">
  <div class="stat"><b><?= $totalApps ?></b>Applications submitted</div>
  <div class="stat"><b><?= money($disbursed) ?></b>Simulated disbursed</div>
  <div class="stat"><b><?= money($outstanding) ?></b>Outstanding balance</div>
  <div class="stat"><b><?= money($collected) ?></b>Repayments collected</div>
  <div class="stat"><b><?= $overdueCnt ?></b>Overdue EMIs (<?= money($overdueAmt) ?>)</div>
</div>

<h3 style="margin-top:22px">Applications by status</h3>
<?php if (!$byStatus): ?><p class="muted">No applications yet.</p><?php else: ?>
<div class="table-wrap"><table>
  <?php foreach ($byStatus as $r): ?>
  <tr><td style="width:220px"><?= status_badge($r['status']) ?></td><td style="width:70px"><?= (int)$r['n'] ?></td>
      <td><div style="background:#2a5bd7;height:12px;border-radius:6px;width:<?= max(2, round($r['n'] / $maxStatus * 100)) ?>%"></div></td></tr>
  <?php endforeach; ?>
</table></div>
<?php endif; ?>

<h3 style="margin-top:22px">By loan type</h3>
<div class="table-wrap"><table>
  <tr><th>Loan type</th><th>Applications</th><th>Total requested</th></tr>
  <?php foreach ($byProduct as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= (int)$r['n'] ?></td><td><?= money($r['amt']) ?></td></tr><?php endforeach; ?>
</table></div>

<h3 style="margin-top:22px">By branch</h3>
<div class="table-wrap"><table>
  <tr><th>Branch</th><th>Applications</th><th>Approved (incl. later stages)</th><th>Rejected</th></tr>
  <?php foreach ($byBranch as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= (int)$r['n'] ?></td><td><?= (int)$r['approved'] ?></td><td><?= (int)$r['rejected'] ?></td></tr><?php endforeach; ?>
</table></div>

<h3 id="audit" style="margin-top:28px">Audit log</h3>
<form method="get" style="margin-bottom:12px">
  <select name="action"><option value="">All actions</option>
    <?php foreach ($actions as $a): ?><option value="<?= e($a) ?>" <?= $a === $action ? 'selected' : '' ?>><?= e($a) ?></option><?php endforeach; ?>
  </select>
  <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search user, employee ID or details">
  <button class="btn-sm" type="submit">Filter</button>
</form>
<?php if (!$logs): ?><p class="muted">No log entries match.</p><?php else: ?>
<div class="table-wrap"><table>
  <tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr>
  <?php foreach ($logs as $l): ?>
  <tr><td><?= e($l['created_at']) ?></td>
      <td><?= $l['full_name'] ? e($l['full_name']) . ($l['employee_code'] ? ' <span class="muted">(' . e($l['employee_code']) . ')</span>' : '') : '<span class="muted">-</span>' ?></td>
      <td><?= e($l['action']) ?></td><td><?= e($l['entity'] ? $l['entity'] . ' #' . $l['entity_id'] : '-') ?></td><td><?= e($l['details'] ?? '') ?></td><td><?= e($l['ip_address'] ?? '') ?></td></tr>
  <?php endforeach; ?>
</table></div>
<p>
  <?php if ($page > 1): ?><a class="btn-sm btn-line" href="<?= e($qs($page - 1)) ?>">&larr; Newer</a><?php endif; ?>
  <span class="muted">Page <?= $page ?> of <?= $pages ?> (<?= $total ?> entries)</span>
  <?php if ($page < $pages): ?><a class="btn-sm btn-line" href="<?= e($qs($page + 1)) ?>">Older &rarr;</a><?php endif; ?>
</p>
<?php endif;
page_footer();
