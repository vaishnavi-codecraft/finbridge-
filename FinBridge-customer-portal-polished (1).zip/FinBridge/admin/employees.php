<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['admin']);
ensure_employee_code_unique($pdo);

$me = current_user();
$roles = ['branch_officer' => 'Branch Officer', 'branch_manager' => 'Branch Manager', 'accounts_officer' => 'Accounts Officer'];
$branches = $pdo->query('SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name')->fetchAll();
$roleList = "'branch_officer','branch_manager','accounts_officer'";

$error = '';
$old = ['name' => '', 'email' => '', 'phone' => '', 'role' => '', 'branch_id' => 0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $uid = (int)($_POST['id'] ?? 0);

    if ($act === 'approve') {
        $s = $pdo->prepare("SELECT id, role, branch_id FROM users WHERE id = ? AND is_active = 0 AND employee_code IS NULL AND role IN ($roleList)");
        $s->execute([$uid]);
        if ($r = $s->fetch()) {
            $code = with_unique_employee_code($pdo, $r['role'], $r['branch_id'] ? (int)$r['branch_id'] : null, function ($c) use ($pdo, $uid) {
                $pdo->prepare('UPDATE users SET employee_code = ?, is_active = 1 WHERE id = ?')->execute([$c, $uid]);
            });
            audit($pdo, $me['id'], 'staff_approved', 'user', $uid, $code);
            set_flash("Approved. Employee ID: $code. Share it with the employee so they can sign in.");
            header('Location: employees.php'); exit;
        }
        $error = 'That request is no longer pending.';

    } elseif ($act === 'reject') {
        $pdo->prepare("DELETE FROM users WHERE id = ? AND is_active = 0 AND employee_code IS NULL AND role IN ($roleList)")->execute([$uid]);
        audit($pdo, $me['id'], 'staff_rejected', 'user', $uid);
        set_flash('Request rejected and removed.');
        header('Location: employees.php'); exit;

    } elseif ($act === 'toggle') {
        $pdo->prepare("UPDATE users SET is_active = 1 - is_active WHERE id = ? AND employee_code IS NOT NULL AND role IN ($roleList) AND id <> ?")->execute([$uid, $me['id']]);
        audit($pdo, $me['id'], 'staff_toggled', 'user', $uid);
        set_flash('Account status updated.');
        header('Location: employees.php'); exit;

    } elseif ($act === 'create') {
        $old = [
            'name' => trim($_POST['name'] ?? ''), 'email' => trim($_POST['email'] ?? ''), 'phone' => trim($_POST['phone'] ?? ''),
            'role' => $_POST['role'] ?? '', 'branch_id' => (int)($_POST['branch_id'] ?? 0),
        ];
        $pass = $_POST['password'] ?? '';
        $validBranch = in_array($old['branch_id'], array_map('intval', array_column($branches, 'id')), true);
        if ($old['name'] === '' || strlen($old['name']) > 100) $error = 'Enter the employee name.';
        elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $error = 'Enter a valid email address.';
        elseif (!preg_match('/^[0-9]{10}$/', $old['phone'])) $error = 'Enter a 10-digit mobile number.';
        elseif (!isset($roles[$old['role']])) $error = 'Select a role.';
        elseif (!$validBranch) $error = 'Select a branch.';
        elseif (strlen($pass) < 8) $error = 'Temporary password must be at least 8 characters.';
        else {
            $chk = $pdo->prepare('SELECT 1 FROM users WHERE email = ? OR phone = ?');
            $chk->execute([$old['email'], $old['phone']]);
            if ($chk->fetchColumn()) {
                $error = 'This email or mobile number is already registered.';
            } else {
                $newId = 0;
                $code = with_unique_employee_code($pdo, $old['role'], $old['branch_id'], function ($c) use ($pdo, $old, $pass, &$newId) {
                    $pdo->prepare('INSERT INTO users (branch_id, full_name, email, phone, employee_code, password_hash, role) VALUES (?,?,?,?,?,?,?)')
                        ->execute([$old['branch_id'], $old['name'], $old['email'], $old['phone'], $c, password_hash($pass, PASSWORD_DEFAULT), $old['role']]);
                    $newId = (int)$pdo->lastInsertId();
                });
                audit($pdo, $me['id'], 'staff_created', 'user', $newId, $code);
                set_flash("Employee created. Employee ID: $code. Share the ID and the temporary password with them.");
                header('Location: employees.php'); exit;
            }
        }
    }
}

$pending = $pdo->query(
    "SELECT u.id, u.full_name, u.email, u.phone, u.role, u.created_at, b.name AS branch
     FROM users u LEFT JOIN branches b ON b.id = u.branch_id
     WHERE u.is_active = 0 AND u.employee_code IS NULL AND u.role IN ($roleList) ORDER BY u.id"
)->fetchAll();

$staff = $pdo->query(
    "SELECT u.id, u.employee_code, u.full_name, u.email, u.role, u.is_active, b.name AS branch
     FROM users u LEFT JOIN branches b ON b.id = u.branch_id
     WHERE u.employee_code IS NOT NULL AND u.role <> 'customer' ORDER BY u.role, u.employee_code"
)->fetchAll();

page_header('Employees');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
if ($error) echo '<div class="error">' . e($error) . '</div>';
$csrf = e(csrf_token());
?>
<div class="stack">

<div class="card">
  <h2>Pending access requests (<?= count($pending) ?>)</h2>
  <?php if (!$pending): ?><p class="muted">No pending requests. New requests from the staff sign-up page appear here.</p><?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>Name</th><th>Role</th><th>Branch</th><th>Email</th><th>Mobile</th><th>Requested</th><th></th></tr>
    <?php foreach ($pending as $p): ?>
      <tr>
        <td><?= e($p['full_name']) ?></td><td><?= e($roles[$p['role']] ?? $p['role']) ?></td><td><?= e($p['branch'] ?? '-') ?></td>
        <td><?= e($p['email']) ?></td><td><?= e($p['phone']) ?></td><td><?= e(date('d M Y', strtotime($p['created_at']))) ?></td>
        <td>
          <form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <input type="hidden" name="action" value="approve"><button class="btn-sm" type="submit">Approve</button></form>
          <form method="post" style="display:inline" onsubmit="return confirm('Reject and remove this request?')"><input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <input type="hidden" name="action" value="reject"><button class="btn-sm btn-danger" type="submit">Reject</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Create employee</h2>
  <p class="muted">The Employee ID is generated automatically. Share it, with the temporary password, with the employee.</p>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="action" value="create">
    <div class="form-grid">
      <div><label for="name">Full name</label><input type="text" id="name" name="name" value="<?= e($old['name']) ?>" required></div>
      <div><label for="email">Work email</label><input type="email" id="email" name="email" value="<?= e($old['email']) ?>" required></div>
      <div><label for="phone">Mobile number</label><input type="tel" id="phone" name="phone" maxlength="10" value="<?= e($old['phone']) ?>" required></div>
      <div><label for="role">Role</label><select id="role" name="role" required><option value="">Select role</option>
        <?php foreach ($roles as $k => $l): ?><option value="<?= e($k) ?>" <?= $old['role'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
      <div><label for="branch_id">Branch</label><select id="branch_id" name="branch_id" required><option value="">Select branch</option>
        <?php foreach ($branches as $b): ?><option value="<?= (int)$b['id'] ?>" <?= (int)$old['branch_id'] === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?></select></div>
      <div><label for="password">Temporary password</label><input type="text" id="password" name="password" minlength="8" required></div>
    </div>
    <button type="submit" style="width:auto;padding:10px 20px">Create Employee</button>
  </form>
</div>

<div class="card">
  <h2>All staff</h2>
  <div class="table-wrap"><table>
    <tr><th>Employee ID</th><th>Name</th><th>Role</th><th>Branch</th><th>Email</th><th>Status</th><th></th></tr>
    <?php foreach ($staff as $s): ?>
      <tr>
        <td><?= e($s['employee_code']) ?></td><td><?= e($s['full_name']) ?></td><td><?= e($roles[$s['role']] ?? $s['role']) ?></td>
        <td><?= e($s['branch'] ?? 'Head office') ?></td><td><?= e($s['email']) ?></td>
        <td><?= $s['is_active'] ? '<span class="badge badge-approved">Active</span>' : '<span class="badge badge-rejected">Disabled</span>' ?></td>
        <td>
          <form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
            <input type="hidden" name="action" value="toggle"><button class="btn-sm btn-line" type="submit"><?= $s['is_active'] ? 'Disable' : 'Enable' ?></button></form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

</div>
<?php page_footer(); ?>
