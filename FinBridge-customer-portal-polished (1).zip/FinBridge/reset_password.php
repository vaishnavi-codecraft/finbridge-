<?php
// Sets a new password from a reset link (single use, expires after 30 minutes).
require __DIR__ . '/includes/bootstrap.php';
$kind = in_array($_GET['portal'] ?? $_POST['portal'] ?? '', ['customer', 'staff', 'admin'], true) ? ($_GET['portal'] ?? $_POST['portal']) : 'customer';
$loginUrl = BASE_URL . ['customer' => '/login.php', 'staff' => '/staff/login.php', 'admin' => '/admin/login.php'][$kind];
ensure_password_resets_table($pdo);

$token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$row = null;
if (preg_match('/^[a-f0-9]{48}$/', $token)) {
    $s = $pdo->prepare('SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW()');
    $s->execute([hash('sha256', $token)]);
    $row = $s->fetch();
}

$error = ''; $done = false;
if ($row && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $p1 = $_POST['password'] ?? ''; $p2 = $_POST['password2'] ?? '';
    if (strlen($p1) < 8) $error = 'Password must be at least 8 characters.';
    elseif ($p1 !== $p2) $error = 'Password and confirmation do not match.';
    else {
        $pdo->beginTransaction();
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($p1, PASSWORD_DEFAULT), $row['user_id']]);
        $pdo->prepare('UPDATE password_resets SET used_at = NOW() WHERE id = ?')->execute([$row['id']]);
        audit($pdo, (int)$row['user_id'], 'password_reset', 'user', (int)$row['user_id']);
        $pdo->commit();
        $done = true;
    }
}
auth_start($kind, 'Set new password', ['Back to sign in', $loginUrl]);
?>
      <h2 class="au-title">Set a new password</h2>
      <?php if ($done): ?>
        <p class="au-lead">Your password has been changed.</p>
        <a class="au-btn" style="display:block;text-align:center;text-decoration:none" href="<?= e($loginUrl) ?>">Sign in</a>
      <?php elseif (!$row): ?>
        <div class="au-error">This reset link is invalid or has expired.</div>
        <p class="au-alt"><a href="forgot_password.php?portal=<?= e($kind) ?>">Request a new link</a></p>
      <?php else: ?>
        <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
        <form method="post">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="portal" value="<?= e($kind) ?>"><input type="hidden" name="token" value="<?= e($token) ?>">
          <?php auth_password_field('password', 'NEW PASSWORD', 'At least 8 characters'); ?>
          <?php auth_password_field('password2', 'CONFIRM PASSWORD', 'Repeat the password'); ?>
          <button class="au-btn" type="submit">Change password <span>→</span></button>
        </form>
      <?php endif; ?>
<?php auth_end();
