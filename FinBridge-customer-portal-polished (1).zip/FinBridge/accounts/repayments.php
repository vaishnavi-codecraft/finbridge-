<?php
// record EMI payments (accounts officer). Pays the earliest unpaid instalment, reduces the balance,
// closes the loan when the last EMI is paid. Overdue instalments are flagged automatically.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = (string)($_POST['action'] ?? '');
    $accId = (int)($_POST['account'] ?? 0);
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare('SELECT la.*, c.user_id AS customer_user_id FROM loan_accounts la JOIN customers c ON c.id = la.customer_id WHERE la.id = ? FOR UPDATE');
        $s->execute([$accId]);
        $acct = $s->fetch();
        if (!$acct) throw new RuntimeException('Loan account not found.');
        if ($acct['status'] !== 'active') throw new RuntimeException('This loan account is already closed.');

        $n = $pdo->prepare("SELECT * FROM repayment_schedule WHERE loan_account_id = ? AND status <> 'paid' ORDER BY installment_no LIMIT 1 FOR UPDATE");
        $n->execute([$accId]);
        $inst = $n->fetch();
        if (!$inst) throw new RuntimeException('No unpaid instalment left on this account.');

        if ($act === 'pay') {
            $mode = (string)($_POST['mode'] ?? '');
            if (!in_array($mode, ['cash', 'upi', 'bank_transfer', 'demo'], true)) throw new RuntimeException('Choose a payment mode.');
            $amount = round((float)($_POST['amount'] ?? 0), 2);
            if (abs($amount - (float)$inst['emi_amount']) > 0.009) throw new RuntimeException('The amount must be exactly the EMI due: ' . money($inst['emi_amount']) . '.');
            $ref = mb_substr(trim((string)($_POST['reference'] ?? '')), 0, 40);

            $pdo->prepare('INSERT INTO payments (loan_account_id, schedule_id, amount, mode, reference, recorded_by) VALUES (?,?,?,?,?,?)')
                ->execute([$accId, $inst['id'], $amount, $mode, $ref !== '' ? $ref : null, $user['id']]);
            $pdo->prepare("UPDATE repayment_schedule SET status = 'paid', paid_on = CURDATE() WHERE id = ?")->execute([$inst['id']]);

            $left = $pdo->prepare("SELECT COUNT(*) FROM repayment_schedule WHERE loan_account_id = ? AND status <> 'paid'");
            $left->execute([$accId]);
            $remaining = (int)$left->fetchColumn();
            $newBal = $remaining === 0 ? 0.0 : (float)$inst['balance_after'];
            $pdo->prepare('UPDATE loan_accounts SET outstanding_balance = ?, status = ? WHERE id = ?')
                ->execute([$newBal, $remaining === 0 ? 'closed' : 'active', $accId]);

            $uid = (int)$acct['customer_user_id']; $appId = (int)$acct['application_id'];
            notify($pdo, $uid, $appId, 'Payment of ' . money($amount) . ' received for EMI #' . $inst['installment_no'] . ' on ' . $acct['account_no'] . '. Outstanding: ' . money($newBal) . '.');
            audit($pdo, (int)$user['id'], 'payment_recorded', 'loan_account', $accId, 'EMI #' . $inst['installment_no'] . ' ' . $amount);
            if ($remaining === 0) {
                $a = $pdo->prepare('SELECT * FROM loan_applications WHERE id = ?'); $a->execute([$appId]);
                if ($app = $a->fetch()) change_status($pdo, $app, 'closed', (int)$user['id'], 'Loan fully repaid');
                notify($pdo, $uid, $appId, 'Congratulations! Your loan ' . $acct['account_no'] . ' is fully repaid and closed.');
                audit($pdo, (int)$user['id'], 'loan_closed', 'loan_account', $accId, $acct['account_no']);
                set_flash('EMI #' . $inst['installment_no'] . ' recorded. Loan ' . $acct['account_no'] . ' is now closed.');
            } else {
                set_flash('EMI #' . $inst['installment_no'] . ' recorded. Outstanding: ' . money($newBal) . '.');
            }
        } elseif ($act === 'make_overdue' && TEST_MODE) {
            // test helper: pretend the next EMI was due yesterday
            $pdo->prepare('UPDATE repayment_schedule SET due_date = DATE_SUB(CURDATE(), INTERVAL 1 DAY) WHERE id = ?')->execute([$inst['id']]);
            audit($pdo, (int)$user['id'], 'test_make_overdue', 'loan_account', $accId, 'EMI #' . $inst['installment_no']);
            set_flash('Test: EMI #' . $inst['installment_no'] . ' due date moved to yesterday.');
        } else {
            throw new RuntimeException('Unknown action.');
        }
        $pdo->commit();
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        set_flash('Could not complete that step: ' . $ex->getMessage());
    }
    header('Location: repayments.php?id=' . $accId); exit;
}

mark_overdue_installments($pdo);

$id = (int)($_GET['id'] ?? 0);
page_header('Repayments');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';

$acct = null;
if ($id) {
    $s = $pdo->prepare('SELECT la.*, p.name AS product, cu.full_name AS customer FROM loan_accounts la JOIN loan_products p ON p.id = la.product_id
                        JOIN customers c ON c.id = la.customer_id JOIN users cu ON cu.id = c.user_id WHERE la.id = ?');
    $s->execute([$id]); $acct = $s->fetch();
}

if ($acct) {
    $n = $pdo->prepare("SELECT * FROM repayment_schedule WHERE loan_account_id = ? AND status <> 'paid' ORDER BY installment_no LIMIT 1");
    $n->execute([$id]); $inst = $n->fetch();
    echo '<p><a href="repayments.php">&larr; All accounts</a> &middot; <a href="loan_accounts.php?id=' . (int)$id . '">Full schedule</a></p>';
    echo '<h3>' . e($acct['customer']) . ' - ' . e($acct['product']) . ' (' . e($acct['account_no']) . ')</h3>';
    if ($acct['status'] === 'closed' || !$inst) {
        echo '<div class="success">This loan is fully repaid and closed.</div>';
    } else { ?>
<div class="card">
  <p>Next instalment: <strong>#<?= (int)$inst['installment_no'] ?></strong> of <?= money($inst['emi_amount']) ?>, due <?= e(date('d M Y', strtotime($inst['due_date']))) ?>
     <?= $inst['status'] === 'overdue' ? '<span class="badge badge-rejected">Overdue</span>' : '' ?></p>
  <p class="muted">Outstanding balance: <?= money($acct['outstanding_balance']) ?></p>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="account" value="<?= (int)$id ?>"><input type="hidden" name="action" value="pay">
    <label>Amount (₹)</label><input type="number" step="0.01" name="amount" value="<?= e($inst['emi_amount']) ?>" required>
    <label>Mode</label>
    <select name="mode"><option value="cash">Cash</option><option value="upi">UPI</option><option value="bank_transfer">Bank transfer</option><option value="demo" selected>Demo</option></select>
    <label>Reference (optional)</label><input type="text" name="reference" maxlength="40">
    <p><button class="btn" type="submit">Record payment</button></p>
  </form>
  <?php if (TEST_MODE): ?>
  <form method="post" style="margin-top:8px"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="account" value="<?= (int)$id ?>"><input type="hidden" name="action" value="make_overdue">
    <button class="btn-sm btn-line" type="submit">Test: make this EMI overdue</button></form>
  <?php endif; ?>
</div>
<?php }
    render_loan_account($pdo, $acct);
} else {
    $term = trim((string)($_GET['q'] ?? ''));
    $sql = "SELECT la.id, la.account_no, la.emi_amount, la.outstanding_balance, cu.full_name AS customer,
                   (SELECT MIN(due_date) FROM repayment_schedule r WHERE r.loan_account_id = la.id AND r.status <> 'paid') AS next_due,
                   (SELECT COUNT(*) FROM repayment_schedule r WHERE r.loan_account_id = la.id AND r.status = 'overdue') AS overdue_cnt
            FROM loan_accounts la JOIN customers c ON c.id = la.customer_id JOIN users cu ON cu.id = c.user_id WHERE la.status = 'active'";
    $args = [];
    if ($term !== '') { $sql .= ' AND (la.account_no LIKE ? OR cu.full_name LIKE ?)'; $args = ["%$term%", "%$term%"]; }
    $sql .= ' ORDER BY overdue_cnt DESC, next_due ASC LIMIT 200';
    $st = $pdo->prepare($sql); $st->execute($args); $rows = $st->fetchAll();
    ?>
<form method="get" style="margin-bottom:12px"><input type="text" name="q" value="<?= e($term) ?>" placeholder="Search account no. or customer"> <button class="btn-sm" type="submit">Search</button></form>
<?php if (!$rows): ?><div class="card"><p class="muted">No active loan accounts.</p></div><?php else: ?>
<div class="table-wrap"><table>
  <tr><th>Account</th><th>Customer</th><th>EMI</th><th>Outstanding</th><th>Next due</th><th></th></tr>
  <?php foreach ($rows as $r): ?>
  <tr><td><?= e($r['account_no']) ?></td><td><?= e($r['customer']) ?></td><td><?= money($r['emi_amount']) ?></td><td><?= money($r['outstanding_balance']) ?></td>
      <td><?= $r['next_due'] ? e(date('d M Y', strtotime($r['next_due']))) : '-' ?> <?= $r['overdue_cnt'] ? '<span class="badge badge-rejected">' . (int)$r['overdue_cnt'] . ' overdue</span>' : '' ?></td>
      <td><a href="repayments.php?id=<?= (int)$r['id'] ?>">Record payment</a></td></tr>
  <?php endforeach; ?>
</table></div>
<?php endif; }
page_footer();
