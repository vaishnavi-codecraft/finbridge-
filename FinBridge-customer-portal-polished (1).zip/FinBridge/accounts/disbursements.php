<?php
// simulated disbursement (accounts officer).
// approved -> agreement_pending -> ready_for_disbursement -> (success => active | failed => disbursement_failed -> retry)
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);
$user = current_user();

// action => [required current status, new status, customer message]
const DISB_FLOW = [
    'prepare_agreement' => ['approved',               'agreement_pending',      'Your loan agreement is being prepared. We will let you know when it is ready.'],
    'agreement_signed'  => ['agreement_pending',      'ready_for_disbursement', 'Your loan agreement is complete. Your loan is ready for disbursement.'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act   = (string)($_POST['action'] ?? '');
    $appId = (int)($_POST['app'] ?? 0);

    $pdo->beginTransaction();
    try {
        // lock the row so a double click cannot run the same step twice
        $s = $pdo->prepare('SELECT a.*, c.user_id AS customer_user_id FROM loan_applications a
                            JOIN customers c ON c.id = a.customer_id WHERE a.id = ? FOR UPDATE');
        $s->execute([$appId]);
        $app = $s->fetch();
        if (!$app) throw new RuntimeException('Application not found.');

        if (isset(DISB_FLOW[$act])) {
            [$from, $to, $msg] = DISB_FLOW[$act];
            if ($app['status'] !== $from) throw new RuntimeException('This step is not available for the current status (' . (STATUS_LABELS[$app['status']] ?? $app['status']) . ').');
            change_status($pdo, $app, $to, (int)$user['id'], 'Accounts: ' . $act);
            notify($pdo, (int)$app['customer_user_id'], $appId, $msg);
            audit($pdo, (int)$user['id'], $act, 'loan_application', $appId, $app['application_no']);
            set_flash($app['application_no'] . ': ' . (STATUS_LABELS[$to] ?? $to) . '.');

        } elseif ($act === 'disburse_success' || $act === 'disburse_fail') {
            if (!in_array($app['status'], ['ready_for_disbursement', 'disbursement_failed'], true))
                throw new RuntimeException('This application is not ready for disbursement.');
            $retry = $app['status'] === 'disbursement_failed';
            $ok    = $act === 'disburse_success';
            $amt   = sanctioned_amount($pdo, $app);

            // 1. processing record
            $pdo->prepare("INSERT INTO disbursement_transactions (application_id, amount, reference, status, message, initiated_by)
                           VALUES (?,?,?,?,?,?)")
                ->execute([$appId, $amt, 'TMP' . bin2hex(random_bytes(8)), 'processing',
                           $retry ? 'Retry started' : 'Disbursement started', $user['id']]);
            $tid = (int)$pdo->lastInsertId();
            $ref = 'SIM-DISB-' . (10000 + $tid);
            $pdo->prepare('UPDATE disbursement_transactions SET reference = ? WHERE id = ?')->execute([$ref, $tid]);
            notify($pdo, (int)$app['customer_user_id'], $appId, 'Disbursement of ' . money($amt) . ' is being processed (' . $ref . ').');

            // 2. simulated bank result
            if ($ok) {
                $pdo->prepare("UPDATE disbursement_transactions SET status = 'success', message = ? WHERE id = ?")
                    ->execute(['Simulated transfer successful', $tid]);
                change_status($pdo, $app, 'active', (int)$user['id'], 'Disbursed ' . $ref);
                $accId = create_loan_account($pdo, $app);
                notify($pdo, (int)$app['customer_user_id'], $appId, money($amt) . ' has been disbursed to your account (' . $ref . '). Your loan account is now active - view your EMI schedule under Loan Account.');
                audit($pdo, (int)$user['id'], 'disbursement_success', 'loan_application', $appId, $ref);
                set_flash($app['application_no'] . ': disbursed (' . $ref . ').');
            } else {
                $pdo->prepare("UPDATE disbursement_transactions SET status = 'failed', message = ? WHERE id = ?")
                    ->execute(['Simulated bank failure', $tid]);
                if ($app['status'] !== 'disbursement_failed') change_status($pdo, $app, 'disbursement_failed', (int)$user['id'], 'Failed ' . $ref);
                notify($pdo, (int)$app['customer_user_id'], $appId, 'Disbursement could not be completed (' . $ref . '). We will retry shortly.');
                audit($pdo, (int)$user['id'], 'disbursement_failed', 'loan_application', $appId, $ref);
                set_flash($app['application_no'] . ': disbursement failed (' . $ref . '). You can retry.');
            }
        } else {
            throw new RuntimeException('Unknown action.');
        }
        $pdo->commit();
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        set_flash('Could not complete that step: ' . $ex->getMessage());
    }
    header('Location: disbursements.php'); exit;
}

$rows = $pdo->query(
    "SELECT a.id, a.application_no, a.requested_amount, a.customer_id, a.product_id, a.tenure_months, a.status, p.name AS product, cu.full_name AS customer, b.name AS branch
     FROM loan_applications a
     JOIN loan_products p ON p.id = a.product_id
     JOIN customers c ON c.id = a.customer_id
     JOIN users cu ON cu.id = c.user_id
     LEFT JOIN branches b ON b.id = a.branch_id
     WHERE a.status IN ('approved','agreement_pending','ready_for_disbursement','disbursement_failed')
     ORDER BY a.id ASC LIMIT 200"
)->fetchAll();

$tx = $pdo->query(
    "SELECT t.*, a.application_no FROM disbursement_transactions t
     JOIN loan_applications a ON a.id = t.application_id ORDER BY t.id DESC LIMIT 20"
)->fetchAll();

function disb_btn(int $id, string $action, string $label, string $cls = 'btn-sm'): void {
    echo '<form method="post" style="display:inline-block;margin:2px">'
       . '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '"><input type="hidden" name="app" value="' . $id . '">'
       . '<input type="hidden" name="action" value="' . e($action) . '"><button class="' . $cls . '" type="submit">' . e($label) . '</button></form>';
}

page_header('Disbursements');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
?>
<p class="muted">Simulated demo only - no real money moves.</p>
<?php if (!$rows): ?>
  <div class="card"><p class="muted">No approved applications are waiting.</p></div>
<?php else: ?>
<div class="table-wrap"><table>
  <tr><th>Application</th><th>Customer</th><th>Loan type</th><th>Amount</th><th>Branch</th><th>Status</th><th>Next step</th></tr>
  <?php foreach ($rows as $r): $id = (int)$r['id']; ?>
  <tr>
    <td><?= e($r['application_no']) ?></td>
    <td><?= e($r['customer']) ?></td>
    <td><?= e($r['product']) ?></td>
    <td><?= money(sanctioned_amount($pdo, $r)) ?></td>
    <td><?= e($r['branch'] ?? '-') ?></td>
    <td><?= status_badge($r['status']) ?></td>
    <td>
      <?php
      if ($r['status'] === 'approved')                    disb_btn($id, 'prepare_agreement', 'Prepare agreement');
      elseif ($r['status'] === 'agreement_pending')       disb_btn($id, 'agreement_signed', 'Mark agreement complete');
      else {
          $retry = $r['status'] === 'disbursement_failed';
          disb_btn($id, 'disburse_success', $retry ? 'Retry (success)' : 'Disburse (success)');
          disb_btn($id, 'disburse_fail', $retry ? 'Retry (simulate failure)' : 'Simulate failure', 'btn-sm btn-line');
      } ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php endif; ?>

<h3 style="margin-top:24px">Recent transactions</h3>
<?php if (!$tx): ?><p class="muted">None yet.</p><?php else: ?>
<div class="table-wrap"><table>
  <tr><th>Reference</th><th>Application</th><th>Amount</th><th>Result</th><th>Message</th><th>Time</th></tr>
  <?php foreach ($tx as $t): ?>
  <tr><td><?= e($t['reference']) ?></td><td><?= e($t['application_no']) ?></td><td><?= money($t['amount']) ?></td>
      <td><?= e(ucfirst($t['status'])) ?></td><td><?= e($t['message']) ?></td><td><?= e($t['created_at']) ?></td></tr>
  <?php endforeach; ?>
</table></div>
<?php endif;
page_footer();
