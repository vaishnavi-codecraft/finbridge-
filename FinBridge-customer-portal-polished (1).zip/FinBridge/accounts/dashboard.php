<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);

mark_overdue_installments($pdo);
$ready = (int)$pdo->query("SELECT COUNT(*) FROM loan_applications WHERE status IN ('approved','agreement_pending','ready_for_disbursement')")->fetchColumn();
$failed = (int)$pdo->query("SELECT COUNT(*) FROM loan_applications WHERE status = 'disbursement_failed'")->fetchColumn();
$active = (int)$pdo->query("SELECT COUNT(*) FROM loan_accounts WHERE status = 'active'")->fetchColumn();
$disbursed = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM disbursement_transactions WHERE status = 'success'")->fetchColumn();
$overdue = (int)$pdo->query("SELECT COUNT(*) FROM repayment_schedule WHERE status = 'overdue'")->fetchColumn();

page_header('Accounts Dashboard');
?>
<div class="stats">
  <div class="stat"><b><?= $ready ?></b>Approved, awaiting disbursement</div>
  <div class="stat"><b><?= $failed ?></b>Disbursement failed</div>
  <div class="stat"><b><?= $active ?></b>Active loan accounts</div>
  <div class="stat"><b><?= money($disbursed) ?></b>Simulated disbursed</div>
  <div class="stat"><b><?= $overdue ?></b>Overdue instalments</div>
</div>
<p>
  <a class="btn" href="disbursements.php">Disbursements</a>
  <a class="btn btn-line" href="loan_accounts.php">Loan accounts</a>
  <a class="btn btn-line" href="repayments.php">Repayments</a>
</p>
<div class="card" style="margin-top:16px">
  <h2>Accounts workflow</h2>
  <p>Only manager-approved applications enter this queue. Complete the steps in order:</p>
  <ol>
    <li><strong>Approved</strong> → Prepare agreement.</li>
    <li><strong>Agreement pending</strong> → Customer accepts the agreement; then mark it complete.</li>
    <li><strong>Ready for disbursement</strong> → Send funds using the simulated Demo Bank transfer.</li>
    <li><strong>Transfer failed</strong> → Review the failure and retry after correcting it.</li>
    <li><strong>Active loan</strong> → Check the loan account and record repayments.</li>
  </ol>
  <p class="muted"><strong>Demo Bank</strong> is the fictional funding institution in this prototype. Transfers are simulated; no real bank account or money is accessed. Applications in Documents Required or Under Review will not appear here until the manager approves them.</p>
</div>
<?php page_footer(); ?>
