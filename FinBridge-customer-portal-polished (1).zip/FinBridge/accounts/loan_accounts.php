<?php
// Accounts officer: all loan accounts, with the schedule and payments of one account.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);

mark_overdue_installments($pdo);
$id = (int)($_GET['id'] ?? 0);
if ($id) {
    $s = $pdo->prepare('SELECT la.*, p.name AS product, cu.full_name AS customer FROM loan_accounts la
                        JOIN loan_products p ON p.id = la.product_id JOIN customers c ON c.id = la.customer_id
                        JOIN users cu ON cu.id = c.user_id WHERE la.id = ?');
    $s->execute([$id]);
    if ($acct = $s->fetch()) {
        page_header('Loan Account ' . $acct['account_no']);
        echo '<p><a href="loan_accounts.php">&larr; All loan accounts</a> &middot; <a href="repayments.php?id=' . (int)$acct['id'] . '">Record payment</a></p>';
        echo '<h3>' . e($acct['customer']) . ' - ' . e($acct['product']) . '</h3>';
        render_loan_account($pdo, $acct);
        page_footer(); exit;
    }
}

$term = trim((string)($_GET['q'] ?? ''));
$sql = "SELECT la.id, la.account_no, la.principal, la.emi_amount, la.outstanding_balance, la.status, p.name AS product, cu.full_name AS customer,
               (SELECT COUNT(*) FROM repayment_schedule r WHERE r.loan_account_id = la.id AND r.status = 'paid') AS paid_cnt,
               (SELECT COUNT(*) FROM repayment_schedule r WHERE r.loan_account_id = la.id AND r.status = 'overdue') AS overdue_cnt,
               la.tenure_months
        FROM loan_accounts la JOIN loan_products p ON p.id = la.product_id JOIN customers c ON c.id = la.customer_id JOIN users cu ON cu.id = c.user_id";
$args = [];
if ($term !== '') { $sql .= ' WHERE la.account_no LIKE ? OR cu.full_name LIKE ?'; $args = ["%$term%", "%$term%"]; }
$sql .= ' ORDER BY la.id DESC LIMIT 200';
$st = $pdo->prepare($sql); $st->execute($args); $rows = $st->fetchAll();

page_header('Loan Accounts');
?>
<form method="get" style="margin-bottom:12px"><input type="text" name="q" value="<?= e($term) ?>" placeholder="Search account no. or customer"> <button class="btn-sm" type="submit">Search</button></form>
<?php if (!$rows): ?>
  <div class="card"><p class="muted">No loan accounts yet. They are created when a disbursement succeeds.</p></div>
<?php else: ?>
<div class="table-wrap"><table>
  <tr><th>Account</th><th>Customer</th><th>Loan type</th><th>Principal</th><th>EMI</th><th>Outstanding</th><th>Paid</th><th>Status</th><th></th></tr>
  <?php foreach ($rows as $r): ?>
  <tr><td><?= e($r['account_no']) ?></td><td><?= e($r['customer']) ?></td><td><?= e($r['product']) ?></td><td><?= money($r['principal']) ?></td>
      <td><?= money($r['emi_amount']) ?></td><td><?= money($r['outstanding_balance']) ?></td>
      <td><?= (int)$r['paid_cnt'] ?>/<?= (int)$r['tenure_months'] ?><?= $r['overdue_cnt'] ? ' <span class="badge badge-rejected">' . (int)$r['overdue_cnt'] . ' overdue</span>' : '' ?></td>
      <td><?= e(ucfirst($r['status'])) ?></td><td><a href="loan_accounts.php?id=<?= (int)$r['id'] ?>">Open</a></td></tr>
  <?php endforeach; ?>
</table></div>
<?php endif;
page_footer();
