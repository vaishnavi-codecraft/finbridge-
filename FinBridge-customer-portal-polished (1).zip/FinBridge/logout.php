<?php
require __DIR__ . '/includes/bootstrap.php';
$role = current_user()['role'] ?? '';
if (current_user()) audit($pdo, current_user()['id'], 'logout');
$_SESSION = [];
session_destroy();
$to = '/index.php';   // customers land on the public home page after logout
if ($role === 'admin') $to = '/admin/login.php';
elseif (in_array($role, ['branch_officer', 'branch_manager', 'accounts_officer'], true)) $to = '/staff/login.php';
header('Location: ' . BASE_URL . $to);
