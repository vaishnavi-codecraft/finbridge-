<?php
require __DIR__ . '/includes/bootstrap.php';
current_user() ? redirect_to_home() : header('Location: ' . BASE_URL . '/login.php');
