<?php
// Complete your application (part 2): eligibility result, personal, financial, loan details,
// documents, review and final submit. The application stays a DRAFT until the final submit.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$user   = current_user();
$custId = customer_id_for_user($pdo, $user['id']);
$id     = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$s = $pdo->prepare('SELECT a.*, p.name AS product, p.code AS product_code FROM loan_applications a
                    JOIN loan_products p ON p.id = a.product_id WHERE a.id = ? AND a.customer_id = ?');
$s->execute([$id, $custId]);
$app = $s->fetch();
if (!$app) { http_response_code(404); exit('Application not found.'); }
if ($app['status'] !== 'draft') { header('Location: application_details.php?id=' . $id); exit; }

$code = $app['product_code'];
$pr = $pdo->prepare('SELECT * FROM loan_products WHERE id = ?');
$pr->execute([$app['product_id']]);
$product = $pr->fetch();

$cu = $pdo->prepare('SELECT u.full_name, u.email, u.phone, c.customer_code FROM customers c JOIN users u ON u.id = c.user_id WHERE c.id = ?');
$cu->execute([$custId]);
$acct = $cu->fetch();

$ap  = app_applicant($app);
$det = json_decode($app['details_json'] ?? '{}', true) ?: [];
$progress = (int)$app['current_step'];
$step = (int)($_GET['step'] ?? $_POST['step'] ?? 0);
$step = max(0, min(5, $step, $progress + 1));          // cannot jump ahead of what is completed
$errors = [];
$old = [];

function recompute(PDO $pdo, array $product, array $ap, array $app): string {
    $r = compute_eligibility($product, $ap, (float)$app['requested_amount'], (int)$app['tenure_months']);
    return $r['code'];
}
function bump(PDO $pdo, int $id, int $progress, int $n): void {
    $pdo->prepare('UPDATE loan_applications SET current_step = ? WHERE id = ?')->execute([max($progress, $n), $id]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['action'] ?? 'save';
    $old = $_POST;

    if ($act === 'discard') {
        $f = $pdo->prepare('SELECT file_path FROM application_documents WHERE application_id = ?');
        $f->execute([$id]);
        $pdo->beginTransaction();
        $pdo->prepare('DELETE FROM application_documents WHERE application_id = ?')->execute([$id]);
        $pdo->prepare("DELETE FROM loan_applications WHERE id = ? AND status = 'draft'")->execute([$id]);
        $pdo->commit();
        foreach ($f->fetchAll(PDO::FETCH_COLUMN) as $fp) { @unlink(doc_file_path($fp)); }
        set_flash('Draft discarded.');
        header('Location: dashboard.php'); exit;
    }

    if ($act === 'change_branch') {
        $bid = (int)($_POST['branch_id'] ?? 0);
        $ok = $pdo->prepare('SELECT 1 FROM branches WHERE id = ? AND is_active = 1');
        $ok->execute([$bid]);
        if ($ok->fetchColumn() && $progress >= 4) {
            $pdo->prepare('UPDATE loan_applications SET branch_id = ? WHERE id = ?')->execute([$bid, $id]);
            set_flash('Branch updated.');
        }
        header('Location: complete.php?id=' . $id . '&step=5'); exit;
    }

    if ($act === 'submit') {
        $step = 5;
        $miss = missing_required_documents($pdo, $app);
        $bOk = $app['branch_id'] ? $pdo->prepare('SELECT 1 FROM branches WHERE id = ? AND is_active = 1') : null;
        if ($bOk) $bOk->execute([$app['branch_id']]);
        if ($progress < 4) $errors[] = 'Please complete all the earlier steps first.';
        if ($miss) $errors[] = 'Please upload the required documents: ' . implode(', ', $miss) . '.';
        if (empty($_POST['decl_accurate'])) $errors[] = 'Please confirm that the information is accurate.';
        if (empty($_POST['decl_privacy'])) $errors[] = 'Please accept the declaration and privacy terms.';
        if (!$errors) {
            $branchId = ($bOk && $bOk->fetchColumn()) ? (int)$app['branch_id']
                      : match_branch($pdo, $ap['pincode'] ?? '', $ap['district'] ?? '', $ap['city'] ?? '', $ap['state'] ?? '');
            if (!$branchId) $errors[] = 'No branch is available right now. Please try again later.';
        }
        if (!$errors) {
            $fast    = empty($_POST['fast_track']) ? 0 : 1;
            $officer = pick_officer($pdo, $branchId);
            $appNo   = sprintf('FB%s-%05d', date('Y'), $id);
            $pdo->beginTransaction();
            $u = $pdo->prepare("UPDATE loan_applications SET status = 'submitted', application_no = ?, branch_id = ?, assigned_officer_id = ?, is_fast_track = ?,
                                  submitted_at = NOW(), declared_at = NOW(), current_step = 5, eligibility_result = ? WHERE id = ? AND status = 'draft'");
            $u->execute([$appNo, $branchId, $officer, $fast, recompute($pdo, $product, $ap, $app), $id]);
            if ($u->rowCount() !== 1) { $pdo->rollBack(); header('Location: application_details.php?id=' . $id); exit; }
            $pdo->prepare('UPDATE customers SET dob = ?, address = ?, employment_type = ?, monthly_income = ?, home_branch_id = ? WHERE id = ?')
                ->execute([$ap['dob'] ?? null, mb_substr(trim(($ap['address'] ?? '') . ', ' . ($ap['city'] ?? '') . ' ' . ($ap['pincode'] ?? '')), 0, 255),
                           $ap['employment_type'] ?? null, $ap['monthly_income'] ?? null, $branchId, $custId]);
            log_status($pdo, $id, 'draft', 'submitted', $user['id'], $fast ? 'Application submitted (fast-track review requested)' : 'Application submitted');
            notify($pdo, $user['id'], $id, "Your application $appNo has been submitted and is awaiting review.");
            if ($officer) notify($pdo, $officer, $id, "New application $appNo assigned to you.");
            $pdo->commit();
            audit($pdo, $user['id'], 'application_submitted', 'loan_application', $id, $appNo);
            header('Location: application_details.php?id=' . $id . '&new=1'); exit;
        }
    } elseif ($step === 1) {
        $new = parse_fields(personal_fields(), $_POST, $errors);
        $same = !empty($_POST['permanent_same']);
        $perm = trim($_POST['permanent_address'] ?? '');
        if (!$same && ($perm === '' || mb_strlen($perm) > 200)) $errors[] = 'Enter your permanent address (up to 200 characters).';
        if (!$errors) {
            $oldPin = $ap['pincode'] ?? ''; $oldDist = $ap['district'] ?? '';
            $ap = array_merge($ap, $new, ['permanent_same' => $same ? 1 : 0, 'permanent_address' => $same ? '' : $perm]);
            // Match the branch automatically; only re-match when there is none yet or the location changed
            $branchId = $app['branch_id'] ? (int)$app['branch_id'] : null;
            if (!$branchId || $oldPin !== $new['pincode'] || strcasecmp($oldDist, $new['district']) !== 0) {
                $branchId = match_branch($pdo, $new['pincode'], $new['district'], $new['city'], $new['state']);
            }
            $pdo->prepare('UPDATE loan_applications SET applicant_json = ?, branch_id = ?, eligibility_result = ? WHERE id = ?')
                ->execute([json_encode($ap, JSON_UNESCAPED_UNICODE), $branchId, recompute($pdo, $product, $ap, $app), $id]);
            bump($pdo, $id, $progress, 1);
            header('Location: complete.php?id=' . $id . '&step=2'); exit;
        }
    } elseif ($step === 2) {
        $new = parse_fields(financial_fields(($_POST['employment_type'] ?? '') === 'student'), $_POST, $errors);
        if (!$errors) {
            $ap = array_merge($ap, $new);
            $pdo->prepare('UPDATE loan_applications SET applicant_json = ?, eligibility_result = ? WHERE id = ?')
                ->execute([json_encode($ap, JSON_UNESCAPED_UNICODE), recompute($pdo, $product, $ap, $app), $id]);
            bump($pdo, $id, $progress, 2);
            header('Location: complete.php?id=' . $id . '&step=3'); exit;
        }
    } elseif ($step === 3) {
        $new = parse_fields(loan_detail_fields($code), $_POST, $errors);
        if (!$errors) {
            $det = array_merge($det, $new);
            $pdo->prepare('UPDATE loan_applications SET details_json = ? WHERE id = ?')->execute([json_encode($det, JSON_UNESCAPED_UNICODE), $id]);
            bump($pdo, $id, $progress, 3);
            header('Location: complete.php?id=' . $id . '&step=4'); exit;
        }
    } elseif ($step === 4) {
        $miss = missing_required_documents($pdo, $app);
        if ($miss) $errors[] = 'Please upload the required documents: ' . implode(', ', $miss) . '.';
        else { bump($pdo, $id, $progress, 4); header('Location: complete.php?id=' . $id . '&step=5'); exit; }
    }
}

// ---------- page data ----------
$emi = calc_emi((float)$app['requested_amount'], (float)$app['interest_rate'], (int)$app['tenure_months']);
$elig = compute_eligibility($product, $ap, (float)$app['requested_amount'], (int)$app['tenure_months']);
$val = fn(string $k, $default = '') => $old[$k] ?? ($ap[$k] ?? ($det[$k] ?? $default));

page_header('Complete your application', false);
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
?>
<div class="wiz-head">
  <h1 class="cx-title" style="margin-bottom:4px"><?= e($app['product']) ?> application</h1>
  <p class="muted">Draft - not submitted yet. Requested <?= money($app['requested_amount']) ?> for <?= (int)$app['tenure_months'] ?> months.</p>
</div>
<ol class="wiz-steps">
  <?php foreach (WIZARD_STEPS as $n => $label):
      $cls = $n === $step ? 'current' : ($n <= $progress ? 'done' : ''); ?>
    <li class="<?= $cls ?>"><?php if ($n <= $progress + 1): ?><a href="complete.php?id=<?= $id ?>&amp;step=<?= $n ?>"><b><?= $n <= $progress && $n !== $step ? '✓' : $n ?></b><?= e($label) ?></a>
      <?php else: ?><span><b><?= $n ?></b><?= e($label) ?></span><?php endif; ?></li>
  <?php endforeach; ?>
</ol>

<div class="card">
<?php foreach ($errors as $er): ?><div class="error"><?= e($er) ?></div><?php endforeach; ?>

<?php if ($step === 0): ?>
  <h2>Your indicative eligibility</h2>
  <?php render_eligibility($elig['code'], $elig['reasons']); ?>
  <table style="margin-top:10px">
    <tr><th>Loan</th><td><?= e($app['product']) ?></td></tr>
    <tr><th>Amount / tenure</th><td><?= money($app['requested_amount']) ?> for <?= (int)$app['tenure_months'] ?> months</td></tr>
    <tr><th>Indicative EMI</th><td><?= money($emi) ?> / month at <?= e($app['interest_rate']) ?>% p.a.</td></tr>
  </table>
  <p>Next you will add your personal and financial details, loan details and documents. The branch that will handle your
    application is found automatically from your PIN code.</p>
  <div class="wiz-nav">
    <a class="btn btn-line" href="apply.php?draft=<?= $id ?>">Edit quick details</a>
    <a class="btn" href="complete.php?id=<?= $id ?>&amp;step=1">Continue</a>
  </div>

<?php elseif ($step === 1): ?>
  <h2>Personal information</h2>
  <p class="muted">Name, mobile and email come from your account: <?= e($acct['full_name']) ?> | <?= e($acct['phone']) ?> | <?= e($acct['email']) ?></p>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="1">
    <div class="form-grid">
      <?php foreach (personal_fields() as $f) render_field($f, $val($f[0])); ?>
    </div>
    <label class="check"><input type="checkbox" name="permanent_same" value="1" id="permSame" <?= ($old ? !empty($old['permanent_same']) : (($ap['permanent_same'] ?? 1) == 1)) ? 'checked' : '' ?>> Permanent address is the same as current address</label>
    <div id="permBox" style="display:none"><label for="permanent_address">Permanent address</label>
      <input type="text" id="permanent_address" name="permanent_address" maxlength="200" value="<?= e($val('permanent_address')) ?>"></div>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=0">&larr; Back</a><button type="submit">Save &amp; continue</button></div>
  </form>
  <script>
    (function(){var c=document.getElementById('permSame'),b=document.getElementById('permBox');function t(){b.style.display=c.checked?'none':'block';}c.addEventListener('change',t);t();})();
  </script>

<?php elseif ($step === 2): ?>
  <h2>Financial information</h2>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="2">
    <div class="form-grid">
      <?php foreach (financial_fields(($val('employment_type')) === 'student') as $f) render_field($f, $val($f[0])); ?>
    </div>
    <p class="muted">Demo prototype: use fictional details only.</p>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=1">&larr; Back</a><button type="submit">Save &amp; continue</button></div>
  </form>

<?php elseif ($step === 3): ?>
  <h2>Loan details</h2>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="3">
    <div class="form-grid">
      <?php foreach (loan_detail_fields($code) as $f) render_field($f, $val($f[0])); ?>
    </div>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=2">&larr; Back</a><button type="submit">Save &amp; continue</button></div>
  </form>

<?php elseif ($step === 4):
    $reqs = doc_requirements($code, $ap);
    $dq = $pdo->prepare('SELECT * FROM application_documents WHERE application_id = ?'); $dq->execute([$id]);
    $docs = []; foreach ($dq->fetchAll() as $d) $docs[$d['doc_key']] = $d; ?>
  <h2>Upload documents</h2>
  <p class="muted">PDF, JPG or PNG, up to 5 MB each. Use fictional documents only (demo prototype). Files are stored privately and only the branch handling your application can open them.</p>
  <?php foreach ($reqs as $k => [$label, $req]) render_doc_slot($app, $k, $label, $req, $docs[$k] ?? null, 'wizard', true); ?>
  <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="4">
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=3">&larr; Back</a><button type="submit">Continue to review</button></div>
  </form>

<?php else:
    $labels = all_field_labels($code);
    $dq = $pdo->prepare('SELECT doc_type, original_name FROM application_documents WHERE application_id = ? ORDER BY id'); $dq->execute([$id]); $docList = $dq->fetchAll();
    $bq = $pdo->prepare('SELECT name, city FROM branches WHERE id = ?'); $bq->execute([$app['branch_id']]); $branch = $bq->fetch();
    $allBranches = $pdo->query('SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name')->fetchAll();
    $skipAp = ['permanent_same', 'full_name', 'phone', 'email']; ?>
  <h2>Review &amp; submit</h2>
  <?php render_eligibility($elig['code'], $elig['reasons']); ?>

  <h3 class="step-h">Loan <a class="muted" href="apply.php?draft=<?= $id ?>">Edit</a></h3>
  <table>
    <tr><th>Loan type</th><td><?= e($app['product']) ?></td></tr>
    <tr><th>Amount / tenure</th><td><?= money($app['requested_amount']) ?> / <?= (int)$app['tenure_months'] ?> months (EMI about <?= money($emi) ?>)</td></tr>
    <?php foreach ($det as $k => $v): ?><tr><th><?= e($labels[$k][0] ?? $k) ?></th><td><?= e(show_value($labels, $k, $v)) ?></td></tr><?php endforeach; ?>
  </table>
  <h3 class="step-h">Personal &amp; financial <a class="muted" href="complete.php?id=<?= $id ?>&amp;step=1">Edit personal</a> | <a class="muted" href="complete.php?id=<?= $id ?>&amp;step=2">Edit financial</a></h3>
  <table>
    <tr><th>Name</th><td><?= e($acct['full_name']) ?></td></tr>
    <?php foreach ($ap as $k => $v): if (in_array($k, $skipAp, true) || $v === '' || $v === null) continue; ?>
      <tr><th><?= e($labels[$k][0] ?? $k) ?></th><td><?= e($k === 'account_number' ? str_repeat('•', max(0, strlen((string)$v) - 4)) . substr((string)$v, -4) : show_value($labels, $k, $v)) ?></td></tr>
    <?php endforeach; ?>
  </table>
  <h3 class="step-h">Documents <a class="muted" href="complete.php?id=<?= $id ?>&amp;step=4">Edit</a></h3>
  <ul><?php foreach ($docList as $d): ?><li><?= e($d['doc_type']) ?> - <span class="muted"><?= e($d['original_name']) ?></span></li><?php endforeach; ?></ul>

  <h3 class="step-h">Processing branch</h3>
  <p>Matched from your PIN code <strong><?= e($ap['pincode'] ?? '') ?></strong>: <strong><?= e($branch['name'] ?? 'To be assigned') ?></strong></p>
  <details><summary>Use a different branch</summary>
    <form method="post" style="margin-top:8px"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="change_branch">
      <select name="branch_id"><?php foreach ($allBranches as $b): ?><option value="<?= (int)$b['id'] ?>" <?= (int)$b['id'] === (int)$app['branch_id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?></select>
      <button class="btn-sm" type="submit">Change branch</button></form>
  </details>

  <form method="post" style="margin-top:14px"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="step" value="5"><input type="hidden" name="action" value="submit">
    <label class="check"><input type="checkbox" name="decl_accurate" value="1"> I confirm that the information and documents I provided are accurate. (Demo prototype: fictional data only.)</label>
    <label class="check"><input type="checkbox" name="decl_privacy" value="1"> I accept the declaration and privacy terms and agree that the branch may contact me and verify my details.</label>
    <label class="check"><input type="checkbox" name="fast_track" value="1"> Request fast-track (priority) review. This does not guarantee approval.</label>
    <div class="wiz-nav"><a href="complete.php?id=<?= $id ?>&amp;step=4">&larr; Back</a><button type="submit">Submit application</button></div>
  </form>
<?php endif; ?>

  <form method="post" style="margin-top:18px" onsubmit="return confirm('Discard this draft and its uploaded files?')">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="action" value="discard">
    <button class="btn-sm btn-danger" type="submit">Discard draft</button>
  </form>
</div>
<script src="<?= BASE_URL ?>/assets/js/upload.js"></script>
<?php page_footer(); ?>
