<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$u = current_user();
$custId = customer_id_for_user($pdo, $u['id']);
$m0 = fn($v) => '₹' . number_format((float)$v, 0);

// Application counts
$c = $pdo->prepare("SELECT status, COUNT(*) FROM loan_applications WHERE customer_id = ? AND status <> 'draft' GROUP BY status");
$c->execute([$custId]);
$counts = $c->fetchAll(PDO::FETCH_KEY_PAIR);
$n = fn($k) => (int)($counts[$k] ?? 0);
$total    = array_sum($counts);
$inReview = $n('submitted') + $n('under_review') + $n('documents_required') + $n('pending_manager_decision');
$docsNeeded = $n('documents_required');

// Loan accounts
$la = $pdo->prepare("SELECT COUNT(*) AS cnt, COALESCE(SUM(outstanding_balance), 0) AS bal FROM loan_accounts WHERE customer_id = ? AND status = 'active'");
$la->execute([$custId]);
$loanStat = $la->fetch();

$products = $pdo->query('SELECT * FROM loan_products WHERE is_active = 1 ORDER BY id')->fetchAll();
$info = [
    'PERSONAL'  => ['↗', 'For your personal financial needs'],
    'DURABLE'   => ['⌂', 'Finance eligible home appliances and furniture'],
    'BUSINESS'  => ['▣', 'Support your business goals'],
    'EDUCATION' => ['▤', 'Invest in your education'],
    'HOME'      => ['⌂', 'Plan your home purchase or construction'],
    'VEHICLE'   => ['➜', 'Finance your next car or two-wheeler'],
];

$r = $pdo->prepare(
    "SELECT a.id, a.application_no, a.requested_amount, a.status, a.submitted_at, p.name AS product
     FROM loan_applications a JOIN loan_products p ON p.id = a.product_id
     WHERE a.customer_id = ? AND a.status <> 'draft' ORDER BY a.id DESC LIMIT 5"
);
$r->execute([$custId]);
$recent = $r->fetchAll();
$latest = $recent[0] ?? null;

// Unfinished (draft) applications
$dr = $pdo->prepare("SELECT a.id, a.current_step, p.name AS product FROM loan_applications a JOIN loan_products p ON p.id = a.product_id
                     WHERE a.customer_id = ? AND a.status = 'draft' ORDER BY a.id DESC LIMIT 3");
$dr->execute([$custId]);
$drafts = $dr->fetchAll();

// Progress of the latest application
$steps = ['Submitted', 'Review', 'Decision', 'Disbursement'];
$state = array_fill(0, 4, '');
if ($latest) {
    $curMap = ['submitted' => 1, 'under_review' => 1, 'documents_required' => 1, 'pending_manager_decision' => 2,
               'approved' => 3, 'agreement_pending' => 3, 'ready_for_disbursement' => 3, 'disbursement_failed' => 3,
               'rejected' => 3, 'withdrawn' => 1, 'active' => 4, 'closed' => 4];
    $cur = $curMap[$latest['status']] ?? 1;
    for ($i = 0; $i < 4; $i++) {
        if ($i < $cur) $state[$i] = 'done';
        elseif ($i === $cur && $latest['status'] !== 'rejected') $state[$i] = 'current';
    }
}

// Active loan summary
$acct = $pdo->prepare("SELECT * FROM loan_accounts WHERE customer_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
$acct->execute([$custId]);
$account = $acct->fetch();
$nextEmi = null;
if ($account) {
    $ne = $pdo->prepare("SELECT due_date, emi_amount FROM repayment_schedule WHERE loan_account_id = ? AND status IN ('due','overdue') ORDER BY installment_no LIMIT 1");
    $ne->execute([$account['id']]);
    $nextEmi = $ne->fetch();
}

page_header('Dashboard', false);
?>
<section class="cx-welcome">
  <div>
    <h1>Welcome back, <?= e($u['name']) ?>!</h1>
    <p>Here is an overview of your applications and finances.</p>
  </div>
  <a class="cx-btn" href="apply.php">＋ &nbsp; Apply for a Loan</a>
</section>

<?php if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>'; ?>
<?php foreach ($drafts as $d): ?>
  <div class="notice">Continue your <strong><?= e($d['product']) ?></strong> application - it has not been submitted yet.
    <a href="complete.php?id=<?= (int)$d['id'] ?>&amp;step=<?= min(5, (int)$d['current_step'] + 1) ?>">Continue →</a></div>
<?php endforeach; ?>

<section class="cx-summary-grid">
  <article class="cx-summary-card">
    <div class="cx-s-top"><span class="cx-s-label">Total Applications</span><span class="cx-s-icon">▤</span></div>
    <div class="cx-s-number"><?= $total ?></div>
    <div class="cx-s-note">Applications submitted</div>
  </article>
  <article class="cx-summary-card">
    <div class="cx-s-top"><span class="cx-s-label">Under Review</span><span class="cx-s-icon">◷</span></div>
    <div class="cx-s-number"><?= $inReview ?></div>
    <div class="cx-s-note"><?= $docsNeeded ? $docsNeeded . ' need documents' : 'Awaiting review' ?></div>
  </article>
  <article class="cx-summary-card">
    <div class="cx-s-top"><span class="cx-s-label">Active Loans</span><span class="cx-s-icon">▣</span></div>
    <div class="cx-s-number"><?= (int)$loanStat['cnt'] ?></div>
    <div class="cx-s-note"><?= $loanStat['cnt'] ? 'Disbursed loans' : 'No active loans yet' ?></div>
  </article>
  <article class="cx-summary-card">
    <div class="cx-s-top"><span class="cx-s-label">Outstanding Balance</span><span class="cx-s-icon">₹</span></div>
    <div class="cx-s-number"><?= $m0($loanStat['bal']) ?></div>
    <div class="cx-s-note"><?= $loanStat['cnt'] ? 'Across active loans' : 'No disbursed loans' ?></div>
  </article>
</section>

<section class="cx-section">
  <div class="cx-section-head">
    <div><h2>Explore Loan Products</h2><p>Choose a financing option that fits your needs.</p></div>
    <a href="apply.php" class="cx-link">View all →</a>
  </div>
  <div class="cx-loan-grid">
    <?php foreach ($products as $p): [$ic, $desc] = $info[$p['code']] ?? ['₹', '']; ?>
      <article class="cx-loan-card">
        <div class="cx-loan-icon"><?= $ic ?></div>
        <h3><?= e($p['name']) ?></h3>
        <p><?= e($desc) ?><br>From <?= e($p['interest_rate']) ?>% p.a. (indicative)</p>
        <a href="apply.php?p=<?= e($p['code']) ?>">Apply now →</a>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="cx-section">
  <div class="cx-section-head">
    <div><h2>Recent Applications</h2><p>Track the latest updates on your applications.</p></div>
    <a href="applications.php" class="cx-link">View all →</a>
  </div>
  <div class="cx-table-card">
    <?php if (!$recent): ?>
      <div class="cx-empty">You have not applied for a loan yet. <a class="cx-link" href="apply.php">Apply now →</a></div>
    <?php else: ?>
    <div class="cx-table-wrap"><table>
      <thead><tr><th>APPLICATION ID</th><th>LOAN TYPE</th><th>REQUESTED AMOUNT</th><th>SUBMITTED ON</th><th>STATUS</th><th>ACTION</th></tr></thead>
      <tbody>
      <?php foreach ($recent as $x): ?>
        <tr>
          <td class="cx-appid"><?= e($x['application_no']) ?></td>
          <td><?= e($x['product']) ?></td>
          <td class="cx-amount"><?= $m0($x['requested_amount']) ?></td>
          <td><?= e(date('d M Y', strtotime($x['submitted_at'] ?? 'now'))) ?></td>
          <td><?= cx_pill($x['status']) ?></td>
          <td><a class="cx-view-btn" href="application_details.php?id=<?= (int)$x['id'] ?>">View Details</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>
</section>

<section class="cx-bottom-grid">
  <article class="cx-panel">
    <h2>Application Progress</h2>
    <p class="cx-panel-sub"><?= $latest ? e($latest['application_no']) . ' - ' . e($latest['product']) : 'A guide to the loan application journey.' ?></p>
    <div class="cx-steps">
      <?php foreach ($steps as $i => $label): ?>
        <div class="cx-step <?= $state[$i] ?>">
          <div class="cx-step-circle"><?= $state[$i] === 'done' ? '✓' : $i + 1 ?></div>
          <div class="cx-step-label"><?= e($label) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="cx-notice">
      <span class="cx-notice-icon">ⓘ</span>
      <div>
        <?php if ($latest && $latest['status'] === 'documents_required'): ?>
          <strong>Additional documents are required</strong>
          <p>The review team has asked for more information. <a href="application_details.php?id=<?= (int)$latest['id'] ?>">Respond now →</a></p>
        <?php elseif ($latest && $latest['status'] === 'rejected'): ?>
          <strong>Application not approved</strong>
          <p><a href="application_details.php?id=<?= (int)$latest['id'] ?>">View the decision →</a></p>
        <?php elseif ($latest): ?>
          <strong>Status: <?= e(STATUS_LABELS[$latest['status']] ?? $latest['status']) ?></strong>
          <p>Approval and disbursement are separate steps. We will notify you at each stage.</p>
        <?php else: ?>
          <strong>No applications yet</strong>
          <p>Start an application to follow its progress here.</p>
        <?php endif; ?>
      </div>
    </div>
  </article>

  <article class="cx-panel">
    <h2>My Loan Summary</h2>
    <p class="cx-panel-sub">Your active loan and upcoming EMI information.</p>
    <?php if (!$account): ?>
      <div class="cx-emi-empty">
        <strong>No active loan account yet</strong>
        <p style="margin:7px 0 0">Once an approved loan is successfully disbursed, your loan balance and repayment schedule will appear here.</p>
      </div>
    <?php endif; ?>
    <div class="cx-emi-details">
      <div class="cx-emi-row"><span>Next EMI date</span><strong><?= $nextEmi ? e(date('d M Y', strtotime($nextEmi['due_date']))) : '—' ?></strong></div>
      <div class="cx-emi-row"><span>Monthly EMI</span><strong><?= $account ? $m0($account['emi_amount']) : '—' ?></strong></div>
      <div class="cx-emi-row"><span>Outstanding balance</span><strong><?= $m0($loanStat['bal']) ?></strong></div>
    </div>
  </article>
</section>
<?php page_footer(); ?>
