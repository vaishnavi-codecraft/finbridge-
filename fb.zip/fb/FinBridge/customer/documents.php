<?php
// My Documents: upload / replace files for an application and answer document requests from the branch.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$user   = current_user();
$custId = customer_id_for_user($pdo, $user['id']);
$appId  = (int)($_GET['app'] ?? $_POST['app'] ?? 0);

// ---- list of applications ----
if (!$appId) {
    $s = $pdo->prepare('SELECT a.id, a.application_no, a.status, p.name AS product,
                               (SELECT COUNT(*) FROM application_documents d WHERE d.application_id = a.id) AS docs
                        FROM loan_applications a JOIN loan_products p ON p.id = a.product_id
                        WHERE a.customer_id = ? ORDER BY a.id DESC');
    $s->execute([$custId]);
    $rows = $s->fetchAll();
    page_header('My Documents');
    if (!$rows) {
        echo '<div class="card"><p>You have no applications yet. Documents are uploaded as part of your application.</p><a class="btn" href="apply.php">Apply for a Loan</a></div>';
    } else { ?>
<div class="table-wrap"><table>
  <tr><th>Application</th><th>Loan type</th><th>Status</th><th>Files</th><th></th></tr>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><?= $r['status'] === 'draft' ? '<span class="muted">Draft</span>' : e($r['application_no']) ?></td>
    <td><?= e($r['product']) ?></td><td><?= status_badge($r['status']) ?></td><td><?= (int)$r['docs'] ?></td>
    <td><a href="<?= $r['status'] === 'draft' ? 'complete.php?id=' . (int)$r['id'] . '&amp;step=4' : 'documents.php?app=' . (int)$r['id'] ?>"><?= $r['status'] === 'draft' ? 'Continue' : (can_upload_docs($r) ? 'Manage documents' : 'View') ?></a></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php }
    page_footer();
    exit;
}

// ---- one application ----
$s = $pdo->prepare('SELECT a.*, p.name AS product, p.code AS product_code FROM loan_applications a
                    JOIN loan_products p ON p.id = a.product_id WHERE a.id = ? AND a.customer_id = ?');
$s->execute([$appId, $custId]);
$app = $s->fetch();
if (!$app) { http_response_code(404); exit('Application not found.'); }
if ($app['status'] === 'draft') { header('Location: complete.php?id=' . $appId . '&step=4'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'respond_docs') {
    csrf_check();
    $msg = trim($_POST['message'] ?? '');
    $rq = $pdo->prepare("SELECT MAX(created_at) FROM document_requests WHERE application_id = ? AND status = 'open'");
    $rq->execute([$appId]);
    $since = $rq->fetchColumn();
    $n = 0;
    if ($since) {
        $c = $pdo->prepare('SELECT COUNT(*) FROM application_documents WHERE application_id = ? AND uploaded_at >= ?');
        $c->execute([$appId, $since]);
        $n = (int)$c->fetchColumn();
    }
    if ($app['status'] !== 'documents_required') $error = 'There is no open document request.';
    elseif (mb_strlen($msg) > 200) $error = 'Your message is too long (up to 200 characters).';
    elseif ($n === 0) $error = 'Upload at least one document before sending your response.';
    else {
        $pdo->beginTransaction();
        $pdo->prepare("UPDATE document_requests SET status = 'fulfilled', fulfilled_at = NOW() WHERE application_id = ? AND status = 'open'")->execute([$appId]);
        $pdo->prepare("UPDATE loan_applications SET status = 'under_review' WHERE id = ?")->execute([$appId]);
        log_status($pdo, $appId, 'documents_required', 'under_review', $user['id'], 'Customer responded' . ($msg !== '' ? ': ' . mb_substr($msg, 0, 200) : ' with documents'));
        if ($app['assigned_officer_id']) notify($pdo, (int)$app['assigned_officer_id'], $appId, 'Customer responded to the document request on ' . $app['application_no'] . '.');
        $pdo->commit();
        audit($pdo, $user['id'], 'documents_response', 'loan_application', $appId);
        set_flash('Your response has been sent to the branch officer.');
        header('Location: documents.php?app=' . $appId); exit;
    }
}

$reqs = doc_requirements($app['product_code'], app_applicant($app));
$dq = $pdo->prepare('SELECT * FROM application_documents WHERE application_id = ? ORDER BY id'); $dq->execute([$appId]);
$docs = []; foreach ($dq->fetchAll() as $d) $docs[(string)$d['doc_key']] = $d;
$legacy = array_filter($docs, fn($d, $k) => $k === '' || (!isset($reqs[$k]) && strpos($k, 'extra_') !== 0), ARRAY_FILTER_USE_BOTH);
$open = $pdo->prepare("SELECT reason, created_at FROM document_requests WHERE application_id = ? AND status = 'open' ORDER BY id");
$open->execute([$appId]); $open = $open->fetchAll();
$can = can_upload_docs($app);
$needRe = array_filter($docs, fn($d) => $d['review_status'] === 'clarification');

page_header('Documents - ' . $app['application_no']);
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
if ($error) echo '<div class="error">' . e($error) . '</div>';
?>
<p><a href="application_details.php?id=<?= $appId ?>">&larr; Back to application</a> <?= status_badge($app['status']) ?></p>

<?php if ($app['status'] === 'documents_required' && $open): ?>
<div class="card" style="margin-bottom:16px">
  <div class="notice"><strong>The branch needs more from you:</strong></div>
  <ul><?php foreach ($open as $r): ?><li><?= e($r['reason']) ?> <span class="muted">(<?= e(date('d M Y', strtotime($r['created_at']))) ?>)</span></li><?php endforeach; ?></ul>
  <p class="muted">Upload the files below (use the "Additional document" slots, or re-upload a document), then send your response.</p>
</div>
<?php elseif ($needRe && $can): ?>
<div class="notice">Some documents need to be uploaded again. See the branch notes below.</div>
<?php endif; ?>

<div class="card">
  <h2>Required &amp; optional documents</h2>
  <?php foreach ($reqs as $k => [$label, $req]) render_doc_slot($app, $k, $label, $req, $docs[$k] ?? null, 'documents', $can); ?>
</div>

<?php
$extraKeys = [];
for ($i = 1; $i <= EXTRA_DOC_SLOTS; $i++) { $k = 'extra_' . $i; if (isset($docs[$k]) || $app['status'] === 'documents_required') $extraKeys[] = $k; }
if ($extraKeys): ?>
<div class="card" style="margin-top:16px">
  <h2>Additional documents</h2>
  <?php foreach ($extraKeys as $k) render_doc_slot($app, $k, doc_label($k, $reqs), false, $docs[$k] ?? null, 'documents', $can); ?>
</div>
<?php endif; ?>

<?php if ($legacy): ?>
<div class="card" style="margin-top:16px"><h2>Other files on this application</h2>
  <?php foreach ($legacy as $d): ?><p><a href="<?= BASE_URL ?>/download_document.php?id=<?= (int)$d['id'] ?>" target="_blank" rel="noopener"><?= e($d['doc_type']) ?> - <?= e($d['original_name']) ?></a></p><?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($app['status'] === 'documents_required'): ?>
<div class="card" style="margin-top:16px">
  <h2>Send your response</h2>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="app" value="<?= $appId ?>"><input type="hidden" name="action" value="respond_docs">
    <label for="message">Message to the branch officer (optional)</label>
    <input type="text" id="message" name="message" maxlength="200" placeholder="e.g. Uploaded the latest salary slips">
    <button type="submit">Send response</button>
  </form>
</div>
<?php endif; ?>
<script src="<?= BASE_URL ?>/assets/js/upload.js"></script>
<?php page_footer(); ?>
