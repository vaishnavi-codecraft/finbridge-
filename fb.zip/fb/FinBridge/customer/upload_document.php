<?php
// Receives ONE document for a checklist slot. Files are stored privately in /storage (web access denied)
// under a random name; they are only ever served by download_document.php after a permission check.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$isAjax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
$user = current_user();

function finish(bool $ok, string $msg, string $back, bool $isAjax): void {
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => $ok, 'message' => $msg]);
    } else {
        set_flash($msg);
        header('Location: ' . $back);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method not allowed.'); }

// A file bigger than PHP's post_max_size arrives as an empty request
if (empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    finish(false, 'That file is too large (maximum 5 MB).', 'documents.php', $isAjax);
}
if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
    http_response_code(400);
    finish(false, 'Your session expired. Please refresh the page.', 'documents.php', $isAjax);
}

$custId = customer_id_for_user($pdo, $user['id']);
$appId  = (int)($_POST['app'] ?? 0);
$s = $pdo->prepare('SELECT a.*, p.code AS product_code FROM loan_applications a JOIN loan_products p ON p.id = a.product_id
                    WHERE a.id = ? AND a.customer_id = ?');
$s->execute([$appId, $custId]);
$app = $s->fetch();
if (!$app) { http_response_code(404); finish(false, 'Application not found.', 'documents.php', $isAjax); }

$back = ($_POST['back'] ?? '') === 'wizard' && $app['status'] === 'draft'
    ? 'complete.php?id=' . $appId . '&step=4' : 'documents.php?app=' . $appId;

if (!can_upload_docs($app)) finish(false, 'Documents can no longer be changed for this application.', $back, $isAjax);

// Which slot?
$key  = (string)($_POST['doc_key'] ?? '');
$reqs = doc_requirements($app['product_code'], app_applicant($app));
$isExtra = preg_match('/^extra_([1-9])$/', $key, $m) && (int)$m[1] <= EXTRA_DOC_SLOTS && $app['status'] !== 'draft';
if (!isset($reqs[$key]) && !$isExtra) finish(false, 'Unknown document type.', $back, $isAjax);
$label = $isExtra ? doc_label($key, $reqs) : $reqs[$key][0];

// The file
$f = $_FILES['file'] ?? null;
if (!$f || !is_array($f) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    $err = $f['error'] ?? UPLOAD_ERR_NO_FILE;
    finish(false, in_array($err, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true) ? 'That file is too large (maximum 5 MB).' : 'Choose a file to upload.', $back, $isAjax);
}
if ($f['size'] > UPLOAD_MAX_BYTES) finish(false, 'That file is too large (maximum 5 MB).', $back, $isAjax);
if ($f['size'] < 10) finish(false, 'That file looks empty.', $back, $isAjax);
if (!is_uploaded_file($f['tmp_name'])) finish(false, 'Upload failed. Please try again.', $back, $isAjax);

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
if (!in_array($ext, UPLOAD_EXTENSIONS, true)) finish(false, 'Only PDF, JPG or PNG files are accepted.', $back, $isAjax);

// Check the real content (first bytes), not just the name
$head = (string)file_get_contents($f['tmp_name'], false, null, 0, 8);
if (strncmp($head, '%PDF', 4) === 0) { $kind = 'pdf'; $mime = 'application/pdf'; }
elseif (strncmp($head, "\xFF\xD8\xFF", 3) === 0) { $kind = 'jpg'; $mime = 'image/jpeg'; }
elseif (strncmp($head, "\x89PNG\r\n\x1A\n", 8) === 0) { $kind = 'png'; $mime = 'image/png'; }
else $kind = '';
if ($kind === '' || ($kind === 'jpg' ? !in_array($ext, ['jpg', 'jpeg'], true) : $ext !== $kind)) {
    finish(false, 'The file content does not match its type. Upload a real PDF, JPG or PNG.', $back, $isAjax);
}

// Existing file in this slot?
$ex = $pdo->prepare('SELECT * FROM application_documents WHERE application_id = ? AND doc_key = ?');
$ex->execute([$appId, $key]);
$existing = $ex->fetch();
if ($existing && $existing['review_status'] === 'received') {
    finish(false, 'This document was already accepted by the branch.', $back, $isAjax);
}

if (!is_dir(doc_storage_dir()) && !mkdir(doc_storage_dir(), 0750, true)) finish(false, 'Storage is not available.', $back, $isAjax);
$stored = bin2hex(random_bytes(16));
if (!move_uploaded_file($f['tmp_name'], doc_file_path($stored))) finish(false, 'Could not save the file. Check that storage/documents is writable.', $back, $isAjax);
@chmod(doc_file_path($stored), 0640);

$orig = mb_substr(preg_replace('/[\x00-\x1F\x7F\/\\\\]/u', '', basename((string)$f['name'])), 0, 150);
if ($orig === '') $orig = 'document.' . $ext;

if ($existing) {
    $pdo->prepare("UPDATE application_documents SET doc_type = ?, file_path = ?, original_name = ?, mime_type = ?, file_size = ?,
                     review_status = 'pending', review_note = NULL, uploaded_by = ?, uploaded_at = NOW() WHERE id = ?")
        ->execute([$label, $stored, $orig, $mime, (int)$f['size'], $user['id'], $existing['id']]);
    @unlink(doc_file_path($existing['file_path']));
} else {
    $pdo->prepare("INSERT INTO application_documents (application_id, doc_key, doc_type, file_path, original_name, mime_type, file_size, review_status, uploaded_by)
                   VALUES (?,?,?,?,?,?,?, 'pending', ?)")
        ->execute([$appId, $key, $label, $stored, $orig, $mime, (int)$f['size'], $user['id']]);
}
audit($pdo, $user['id'], 'document_uploaded', 'loan_application', $appId, $key);
finish(true, '"' . preg_replace('/\s*\(.*?\)\s*$/u', '', $label) . '" uploaded.', $back, $isAjax);
