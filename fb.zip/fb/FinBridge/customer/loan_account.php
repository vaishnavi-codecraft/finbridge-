<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);
page_header('Loan Account');
coming_soon('Stage 9 (loan accounts and EMI)');
page_footer();
