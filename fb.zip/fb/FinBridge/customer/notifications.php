<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$u = current_user();
$s = $pdo->prepare('SELECT id, application_id, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100');
$s->execute([$u['id']]);
$rows = $s->fetchAll();

// mark everything as read (after loading, so unread items are still highlighted below)
$pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0')->execute([$u['id']]);

page_header('Notifications');
?>
<div class="cx-table-card">
  <?php if (!$rows): ?>
    <div class="cx-empty">No notifications yet.</div>
  <?php else: foreach ($rows as $x): ?>
    <div class="cx-notif<?= $x['is_read'] ? '' : ' unread' ?>">
      <span class="cx-s-icon">♧</span>
      <div>
        <?= e($x['message']) ?>
        <small><?= e(date('d M Y, h:i A', strtotime($x['created_at']))) ?>
          <?php if ($x['application_id']): ?> &middot; <a class="cx-link" href="application_details.php?id=<?= (int)$x['application_id'] ?>">View application</a><?php endif; ?></small>
      </div>
    </div>
  <?php endforeach; endif; ?>
</div>
<?php page_footer(); ?>
