<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$custId = customer_id_for_user($pdo, current_user()['id']);
$id = (int)($_GET['id'] ?? 0);

// Only the owner can view their application
$s = $pdo->prepare(
    'SELECT a.*, p.name AS product, p.code AS product_code, b.name AS branch
     FROM loan_applications a
     JOIN loan_products p ON p.id = a.product_id
     LEFT JOIN branches b ON b.id = a.branch_id
     WHERE a.id = ? AND a.customer_id = ?'
);
$s->execute([$id, $custId]);
$a = $s->fetch();
if (!$a) { http_response_code(404); exit('Application not found.'); }
if ($a['status'] === 'draft') { header('Location: complete.php?id=' . $id); exit; }

$dq = $pdo->prepare("SELECT reason, created_at FROM document_requests WHERE application_id = ? AND status = 'open' ORDER BY id");
$dq->execute([$id]);
$openReqs = $dq->fetchAll();

$ds = $pdo->prepare("SELECT decision, approved_amount, reason, decided_at FROM approval_records WHERE application_id = ? AND decision IN ('approved','rejected') ORDER BY id DESC LIMIT 1");
$ds->execute([$id]);
$decision = $ds->fetch();

$details = json_decode($a['details_json'] ?? '{}', true) ?: [];
$labels = all_field_labels($a['product_code']);
$docs = $pdo->prepare('SELECT id, doc_type, original_name, review_status, review_note FROM application_documents WHERE application_id = ? ORDER BY id');
$docs->execute([$id]);
$docs = $docs->fetchAll();

$h = $pdo->prepare('SELECT h.*, u.full_name FROM application_history h JOIN users u ON u.id = h.changed_by WHERE h.application_id = ? ORDER BY h.id DESC');
$h->execute([$id]);
$history = $h->fetchAll();

$emi = calc_emi((float)$a['requested_amount'], (float)$a['interest_rate'], (int)$a['tenure_months']);

page_header('Application ' . $a['application_no']);
if ($flash = get_flash()) echo '<div class="success">' . e($flash) . '</div>';
if (!empty($_GET['new'])) echo '<div class="success">Application submitted. Your application ID is <strong>' . e($a['application_no']) . '</strong>.</div>';
?>
<div class="card">
  <p>Status: <?= status_badge($a['status']) ?> <?= $a['is_fast_track'] ? '<span class="muted">Fast-track review requested</span>' : '' ?></p>
  <?php if ($a['status'] === 'submitted'): ?>
    <div class="notice">Your application is submitted and awaiting review. It is not approved yet.</div>
  <?php endif; ?>
  <table>
    <tr><th>Loan type</th><td><?= e($a['product']) ?></td></tr>
    <tr><th>Branch</th><td><?= e($a['branch'] ?? 'To be assigned') ?></td></tr>
    <tr><th>Amount requested</th><td><?= money($a['requested_amount']) ?></td></tr>
    <tr><th>Tenure</th><td><?= (int)$a['tenure_months'] ?> months</td></tr>
    <tr><th>Indicative rate / EMI</th><td><?= e($a['interest_rate']) ?>% p.a. / <?= money($emi) ?> per month (estimate)</td></tr>
    <?php foreach ($details as $k => $v): ?>
      <tr><th><?= e($labels[$k][0] ?? $k) ?></th><td><?= e(show_value($labels, $k, $v)) ?></td></tr>
    <?php endforeach; ?>
    <?php if ($a['purpose']): ?><tr><th>Purpose</th><td><?= e($a['purpose']) ?></td></tr><?php endif; ?>
  </table>
</div>

<?php if ($decision): ?>
<div class="card" style="margin-top:16px">
  <h2>Decision</h2>
  <?php if ($decision['decision'] === 'approved'): ?>
    <div class="success">Your application has been approved for <strong><?= money($decision['approved_amount']) ?></strong>.</div>
    <p class="muted">Approval is not disbursement. Agreement steps and disbursement status will appear here as the next stages are completed.</p>
  <?php else: ?>
    <div class="error">Your application was not approved.</div>
  <?php endif; ?>
  <p><strong>Reason:</strong> <?= e($decision['reason']) ?></p>
  <p class="muted">Decided on <?= e(date('d M Y, h:i A', strtotime($decision['decided_at']))) ?></p>
</div>
<?php endif; ?>

<?php if ($a['status'] === 'documents_required' && $openReqs): ?>
<div class="card" style="margin-top:16px">
  <div class="notice">Additional information is required to continue reviewing your application.</div>
  <ul>
    <?php foreach ($openReqs as $r): ?>
      <li><?= e($r['reason']) ?> <span class="muted">(<?= e(date('d M Y', strtotime($r['created_at']))) ?>)</span></li>
    <?php endforeach; ?>
  </ul>
  <a class="btn" href="documents.php?app=<?= (int)$a['id'] ?>">Upload documents &amp; respond</a>
</div>
<?php endif; ?>

<div class="card" style="margin-top:16px">
  <h2>Documents</h2>
  <?php if (!$docs): ?><p class="muted">No documents uploaded.</p><?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>Document</th><th>File</th><th>Branch check</th></tr>
    <?php foreach ($docs as $d): ?>
      <tr><td><?= e($d['doc_type']) ?></td>
          <td><a href="<?= BASE_URL ?>/download_document.php?id=<?= (int)$d['id'] ?>" target="_blank" rel="noopener"><?= e($d['original_name']) ?></a></td>
          <td><?= e(DOC_STATUS_LABELS[$d['review_status']] ?? $d['review_status']) ?><?= $d['review_note'] && $d['review_status'] === 'clarification' ? '<br><span class="muted">' . e($d['review_note']) . '</span>' : '' ?></td></tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
  <?php if (can_upload_docs($a)): ?><p><a href="documents.php?app=<?= (int)$a['id'] ?>">Manage documents</a></p><?php endif; ?>
</div>

<div class="card" style="margin-top:16px">
  <h2>Progress</h2>
  <ul class="timeline">
    <?php foreach ($history as $row): ?>
      <li><?= status_badge($row['to_status']) ?> <span class="muted"><?= e(date('d M Y, h:i A', strtotime($row['created_at']))) ?></span>
        <?= $row['note'] ? '<br>' . e($row['note']) : '' ?></li>
    <?php endforeach; ?>
  </ul>
</div>
<p><a href="applications.php">&larr; Back to My Applications</a></p>
<?php page_footer(); ?>
