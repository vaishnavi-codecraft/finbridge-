<?php
// Quick Apply (part 1): a few loan-specific questions, live EMI, indicative eligibility.
// The application is saved as a DRAFT; the rest is collected in complete.php.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['customer']);

$user   = current_user();
$custId = customer_id_for_user($pdo, $user['id']);
if (!$custId) exit('Customer profile not found.');

$products = $pdo->query('SELECT * FROM loan_products WHERE is_active = 1 ORDER BY id')->fetchAll();

// Editing an existing draft?
$draft = null;
$draftId = (int)($_GET['draft'] ?? $_POST['draft'] ?? 0);
if ($draftId) {
    $s = $pdo->prepare("SELECT a.*, p.code AS product_code FROM loan_applications a JOIN loan_products p ON p.id = a.product_id
                        WHERE a.id = ? AND a.customer_id = ? AND a.status = 'draft'");
    $s->execute([$draftId, $custId]);
    $draft = $s->fetch();
    if (!$draft) { http_response_code(404); exit('Draft not found.'); }
}

$code = $draft ? $draft['product_code'] : strtoupper($_GET['p'] ?? $_POST['p'] ?? '');
$product = null;
foreach ($products as $p) { if ($p['code'] === $code) $product = $p; }

// Step 0: choose a loan type
if (!$product) {
    page_header('Choose a Loan');
    echo '<div class="grid">';
    foreach ($products as $p) {
        echo '<a class="product-card" href="apply.php?p=' . e($p['code']) . '"><h3>' . e($p['name']) . '</h3>'
           . '<p class="muted">' . money($p['min_amount']) . ' to ' . money($p['max_amount']) . '<br>'
           . 'From ' . e($p['interest_rate']) . '% p.a. | ' . (int)$p['min_tenure_months'] . '-' . (int)$p['max_tenure_months'] . ' months</p>'
           . '<span class="btn">Quick Apply</span></a>';
    }
    echo '</div><p class="muted" style="margin-top:16px">Rates shown are indicative. Quick Apply takes about a minute; you complete the rest afterwards. Final terms are set at approval.</p>';
    page_footer();
    exit;
}

$quick   = loan_quick_fields($code);
$common  = quick_common_fields();
$derived = loan_derived($code);

// Values to show: posted > draft > customer profile
$prof = $pdo->prepare('SELECT dob, employment_type, monthly_income FROM customers WHERE id = ?');
$prof->execute([$custId]);
$prof = array_filter($prof->fetch() ?: [], fn($v) => $v !== null);
$existing = $draft ? (json_decode($draft['details_json'] ?? '{}', true) ?: []) : [];
$existingAp = $draft ? app_applicant($draft) : [];
$old = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST
     : array_merge($prof, $existingAp, $existing, $draft ? ['requested_amount' => $draft['requested_amount'], 'tenure_months' => $draft['tenure_months']] : []);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $details = parse_fields($quick, $_POST, $errors);
    $applicant = parse_fields($common, $_POST, $errors);

    if ($derived) {
        $amount = (float)($details[$derived[0]] ?? 0) - (float)($details[$derived[1]] ?? 0);
        if ($amount <= 0) $errors[] = 'Down payment must be less than the price.';
    } else {
        $amount = (float)($_POST['requested_amount'] ?? 0);
    }
    $tenure = (int)($_POST['tenure_months'] ?? 0);
    if ($amount < (float)$product['min_amount'] || $amount > (float)$product['max_amount']) {
        $errors[] = 'Loan amount must be between ' . money($product['min_amount']) . ' and ' . money($product['max_amount']) . '.';
    }
    if ($tenure < (int)$product['min_tenure_months'] || $tenure > (int)$product['max_tenure_months']) {
        $errors[] = 'Tenure must be between ' . (int)$product['min_tenure_months'] . ' and ' . (int)$product['max_tenure_months'] . ' months.';
    }

    if (!$errors) {
        $apAll  = array_merge($existingAp, $applicant);
        $detAll = array_merge($existing, $details);
        $elig = compute_eligibility($product, $apAll, $amount, $tenure);
        $dj = json_encode($detAll, JSON_UNESCAPED_UNICODE);
        $aj = json_encode($apAll, JSON_UNESCAPED_UNICODE);
        if ($draft) {
            $pdo->prepare('UPDATE loan_applications SET requested_amount=?, tenure_months=?, interest_rate=?, details_json=?, applicant_json=?, eligibility_result=? WHERE id=?')
                ->execute([$amount, $tenure, $product['interest_rate'], $dj, $aj, $elig['code'], $draft['id']]);
            $appId = (int)$draft['id'];
        } else {
            $pdo->prepare("INSERT INTO loan_applications (application_no, customer_id, product_id, branch_id, created_by, channel, requested_amount, tenure_months,
                              interest_rate, details_json, applicant_json, current_step, eligibility_result, status)
                           VALUES (?,?,?,NULL,?,'online',?,?,?,?,?,0,?,'draft')")
                ->execute(['DR' . bin2hex(random_bytes(6)), $custId, $product['id'], $user['id'], $amount, $tenure, $product['interest_rate'], $dj, $aj, $elig['code']]);
            $appId = (int)$pdo->lastInsertId();
        }
        header('Location: complete.php?id=' . $appId . '&step=0');
        exit;
    }
}

function old(string $k, $default = '') { global $old; return $old[$k] ?? $default; }

page_header('Quick Apply - ' . $product['name']);
?>
<div class="card">
  <?php foreach ($errors as $er): ?><div class="error"><?= e($er) ?></div><?php endforeach; ?>
  <p class="muted">Step 1 of 2: a few quick details. You will complete your application, upload documents and submit in the next step.<br>
    Indicative rate <?= e($product['interest_rate']) ?>% p.a. | Amount <?= money($product['min_amount']) ?> to <?= money($product['max_amount']) ?> | Tenure <?= (int)$product['min_tenure_months'] ?>-<?= (int)$product['max_tenure_months'] ?> months</p>
  <form method="post" id="loanForm">
    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="p" value="<?= e($code) ?>">
    <?php if ($draft): ?><input type="hidden" name="draft" value="<?= (int)$draft['id'] ?>"><?php endif; ?>

    <h3 class="step-h">About the loan</h3>
    <div class="form-grid">
      <?php foreach ($quick as $f) render_field($f, old($f[0])); ?>
      <div>
        <label for="requested_amount">Loan amount needed (₹)</label>
        <?php if ($derived): ?>
          <input type="text" id="requested_amount" value="" readonly placeholder="Price minus down payment">
        <?php else: ?>
          <input type="number" step="any" min="0" id="requested_amount" name="requested_amount" value="<?= e(old('requested_amount')) ?>" required>
        <?php endif; ?>
      </div>
      <div>
        <label for="tenure_months">Tenure (months)</label>
        <input type="number" id="tenure_months" name="tenure_months" min="<?= (int)$product['min_tenure_months'] ?>" max="<?= (int)$product['max_tenure_months'] ?>" value="<?= e(old('tenure_months')) ?>" required>
      </div>
    </div>

    <h3 class="step-h">About you</h3>
    <div class="form-grid">
      <?php foreach ($common as $f) render_field($f, old($f[0])); ?>
    </div>

    <div class="emi-box">Indicative EMI: <strong id="emiOut">-</strong>
      <div class="muted">Reducing-balance estimate at <?= e($product['interest_rate']) ?>% p.a. Final terms are set only at approval.</div>
    </div>
    <button type="submit">Check eligibility &amp; continue</button>
  </form>
</div>

<script>
(function () {
  var rate = <?= json_encode((float)$product['interest_rate']) ?>;
  var derived = <?= json_encode($derived) ?>;
  var amt = document.getElementById('requested_amount');
  var ten = document.getElementById('tenure_months');
  var out = document.getElementById('emiOut');
  function amount() {
    if (derived) {
      var p = parseFloat(document.getElementById(derived[0]).value) || 0;
      var d = parseFloat(document.getElementById(derived[1]).value) || 0;
      var a = Math.max(p - d, 0);
      amt.value = a > 0 ? a : '';
      return a;
    }
    return parseFloat(amt.value) || 0;
  }
  function update() {
    var P = amount(), n = parseInt(ten.value, 10) || 0, r = rate / 12 / 100;
    if (P <= 0 || n <= 0) { out.textContent = '-'; return; }
    var f = Math.pow(1 + r, n);
    var emi = r === 0 ? P / n : P * r * f / (f - 1);
    out.textContent = '₹' + emi.toLocaleString('en-IN', {maximumFractionDigits: 2}) + ' / month';
  }
  document.getElementById('loanForm').addEventListener('input', update);
  update();
})();
</script>
<?php page_footer(); ?>
