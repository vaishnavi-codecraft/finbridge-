<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);
page_header('Repayments');
coming_soon('Stage 9 (simulated repayments)');
page_footer();
