<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);
page_header('Loan Accounts');
coming_soon('Stage 9 (loan accounts and EMI)');
page_footer();
