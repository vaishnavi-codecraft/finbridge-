<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);
page_header('Disbursements');
coming_soon('Stage 8 (simulated disbursement)');
page_footer();
