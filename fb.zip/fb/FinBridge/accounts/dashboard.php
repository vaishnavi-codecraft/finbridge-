<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['accounts_officer']);

$ready = (int)$pdo->query("SELECT COUNT(*) FROM loan_applications WHERE status IN ('approved','agreement_pending','ready_for_disbursement')")->fetchColumn();
$failed = (int)$pdo->query("SELECT COUNT(*) FROM loan_applications WHERE status = 'disbursement_failed'")->fetchColumn();
$active = (int)$pdo->query("SELECT COUNT(*) FROM loan_accounts WHERE status = 'active'")->fetchColumn();
$disbursed = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM disbursement_transactions WHERE status = 'success'")->fetchColumn();
$overdue = (int)$pdo->query("SELECT COUNT(*) FROM repayment_schedule WHERE status = 'overdue'")->fetchColumn();

page_header('Accounts Dashboard');
?>
<div class="stats">
  <div class="stat"><b><?= $ready ?></b>Approved, awaiting disbursement</div>
  <div class="stat"><b><?= $failed ?></b>Disbursement failed</div>
  <div class="stat"><b><?= $active ?></b>Active loan accounts</div>
  <div class="stat"><b><?= money($disbursed) ?></b>Simulated disbursed</div>
  <div class="stat"><b><?= $overdue ?></b>Overdue instalments</div>
</div>
<p>
  <a class="btn" href="disbursements.php">Disbursements</a>
  <a class="btn btn-line" href="loan_accounts.php">Loan accounts</a>
  <a class="btn btn-line" href="repayments.php">Repayments</a>
</p>
<div class="card" style="margin-top:16px">
  <p class="muted">All amounts are simulated demo records. Disbursement is built in Stage 8 and loan accounts with EMI in Stage 9.</p>
</div>
<?php page_footer(); ?>
