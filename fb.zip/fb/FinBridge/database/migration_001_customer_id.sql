USE finbridge;
ALTER TABLE customers ADD COLUMN customer_code VARCHAR(12) NULL UNIQUE AFTER id;
UPDATE customers SET customer_code = CONCAT('FBC', LPAD(id, 6, '0')) WHERE customer_code IS NULL;
ALTER TABLE users ADD UNIQUE KEY uq_users_phone (phone);
UPDATE users SET phone = '9876543210' WHERE email = 'customer@finbridge.test';
