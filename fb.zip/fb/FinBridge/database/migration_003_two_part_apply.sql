-- Migration 003: two-part loan application (Quick Apply -> Complete application),
-- automatic branch matching by PIN code / district, document upload, officer field verification.
-- For an EXISTING database. Written for XAMPP (MariaDB). Run ONCE in phpMyAdmin > SQL (database: finbridge).
-- (Fresh installs: database/finbridge.sql already contains all of this.)
USE finbridge;

ALTER TABLE branches
  ADD COLUMN IF NOT EXISTS district   VARCHAR(60)  NULL AFTER city,
  ADD COLUMN IF NOT EXISTS state      VARCHAR(60)  NULL AFTER district,
  ADD COLUMN IF NOT EXISTS address    VARCHAR(200) NULL AFTER state,
  ADD COLUMN IF NOT EXISTS is_active  TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS is_default TINYINT(1) NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS branch_pincodes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NOT NULL,
  pincode CHAR(6) NOT NULL,
  UNIQUE KEY uq_pincode (pincode),
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
) ENGINE=InnoDB;

UPDATE branches SET district = city, state = 'Tamil Nadu' WHERE district IS NULL;
UPDATE branches SET is_default = 1 WHERE code = 'CHN' AND (SELECT c FROM (SELECT COUNT(*) AS c FROM branches WHERE is_default = 1) x) = 0;

INSERT IGNORE INTO branch_pincodes (branch_id, pincode)
SELECT b.id, p.pin FROM branches b JOIN (
  SELECT 'CHN' AS code, '600001' AS pin UNION ALL SELECT 'CHN','600002' UNION ALL SELECT 'CHN','600017' UNION ALL SELECT 'CHN','600020' UNION ALL SELECT 'CHN','600042'
  UNION ALL SELECT 'CBE','641001' UNION ALL SELECT 'CBE','641002' UNION ALL SELECT 'CBE','641012' UNION ALL SELECT 'CBE','641018' UNION ALL SELECT 'CBE','641035'
  UNION ALL SELECT 'MDU','625001' UNION ALL SELECT 'MDU','625002' UNION ALL SELECT 'MDU','625010' UNION ALL SELECT 'MDU','625016' UNION ALL SELECT 'MDU','625020'
) p ON p.code = b.code;

-- A draft has no branch until the PIN code is entered
ALTER TABLE loan_applications
  MODIFY branch_id INT NULL,
  ADD COLUMN IF NOT EXISTS applicant_json JSON NULL AFTER details_json,
  ADD COLUMN IF NOT EXISTS current_step TINYINT NOT NULL DEFAULT 0 AFTER is_fast_track,
  ADD COLUMN IF NOT EXISTS eligibility_result VARCHAR(20) NULL AFTER current_step,
  ADD COLUMN IF NOT EXISTS declared_at DATETIME NULL AFTER eligibility_result;

ALTER TABLE application_documents
  ADD COLUMN IF NOT EXISTS doc_key VARCHAR(30) NULL AFTER application_id,
  ADD UNIQUE KEY IF NOT EXISTS uq_app_doc (application_id, doc_key);

CREATE TABLE IF NOT EXISTS field_verifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  officer_id INT NOT NULL,
  method ENUM('visit','call','document_check') NOT NULL,
  outcome ENUM('satisfactory','concerns','unable') NOT NULL,
  visit_date DATE NULL,
  address_verified TINYINT(1) NOT NULL DEFAULT 0,
  note TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (officer_id) REFERENCES users(id)
) ENGINE=InnoDB;
