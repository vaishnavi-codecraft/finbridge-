<?php
// Run once: open http://localhost/FinBridge/database/seed_users.php  (then DELETE this file)
require __DIR__ . '/../includes/bootstrap.php';

$password = password_hash('Demo@123', PASSWORD_DEFAULT);
$branches = $pdo->query('SELECT id, code FROM branches')->fetchAll(PDO::FETCH_KEY_PAIR); // id => code

$insert = $pdo->prepare(
    'INSERT IGNORE INTO users (branch_id, full_name, email, employee_code, password_hash, role) VALUES (?,?,?,?,?,?)'
);

// Head office admin and accounts officer
$insert->execute([null, 'Head Office Admin', 'admin@finbridge.test', 'ADM-001', $password, 'admin']);
$insert->execute([array_key_first($branches), 'Accounts Officer', 'accounts@finbridge.test', 'ACC-001', $password, 'accounts_officer']);

// One manager + one officer per branch
foreach ($branches as $id => $code) {
    $c = strtolower($code);
    $insert->execute([$id, "$code Manager", "manager.$c@finbridge.test", "MGR-$code-001", $password, 'branch_manager']);
    $insert->execute([$id, "$code Officer", "officer.$c@finbridge.test", "OFF-$code-001", $password, 'branch_officer']);
}

// Demo customer (mobile 9876543210)
$u = $pdo->prepare('INSERT IGNORE INTO users (full_name, email, password_hash, role) VALUES (?,?,?,?)');
$u->execute(['Demo Customer', 'customer@finbridge.test', $password, 'customer']);
$uid = $pdo->query("SELECT id FROM users WHERE email='customer@finbridge.test'")->fetchColumn();
$pdo->prepare('UPDATE users SET phone = ? WHERE id = ?')->execute(['9876543210', $uid]);
$pdo->prepare('INSERT IGNORE INTO customers (user_id, home_branch_id, employment_type, monthly_income) VALUES (?,?,?,?)')
    ->execute([$uid, array_key_first($branches), 'salaried', 30000]);
$pdo->prepare("UPDATE customers SET customer_code = CONCAT('FBC', LPAD(id, 6, '0')) WHERE user_id = ? AND customer_code IS NULL")
    ->execute([$uid]);

echo 'Seeded. All demo passwords: Demo@123 - now delete database/seed_users.php';
