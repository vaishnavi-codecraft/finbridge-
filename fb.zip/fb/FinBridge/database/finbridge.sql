-- FinBridge Loan Management System - schema (MySQL 5.7+ / MariaDB 10.4+)
-- Import: phpMyAdmin > Import, or: mysql -u root < schema.sql

CREATE DATABASE IF NOT EXISTS finbridge CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE finbridge;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS field_verifications, branch_pincodes, audit_logs, notifications, disbursement_transactions, payments,
  repayment_schedule, loan_accounts, approval_records, review_notes, application_history,
  document_requests, application_documents, loan_applications, loan_products, customers,
  users, branches;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE branches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(10) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  city VARCHAR(60) NOT NULL,
  district VARCHAR(60) NULL,
  state VARCHAR(60) NULL,
  address VARCHAR(200) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  is_default TINYINT(1) NOT NULL DEFAULT 0,      -- fallback branch when no PIN/district matches
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- PIN codes each branch serves: the customer's PIN picks the branch automatically
CREATE TABLE branch_pincodes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NOT NULL,
  pincode CHAR(6) NOT NULL,
  UNIQUE KEY uq_pincode (pincode),
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  branch_id INT NULL,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  employee_code VARCHAR(20) NULL UNIQUE,
  phone VARCHAR(15) NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('customer','branch_officer','branch_manager','accounts_officer','admin') NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  UNIQUE KEY uq_users_phone (phone)
) ENGINE=InnoDB;

CREATE TABLE customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_code VARCHAR(12) NULL UNIQUE,
  user_id INT NOT NULL UNIQUE,
  home_branch_id INT NULL,
  dob DATE NULL,
  address VARCHAR(255) NULL,
  employment_type ENUM('salaried','self_employed','student','other') NULL,
  monthly_income DECIMAL(12,2) NULL,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (home_branch_id) REFERENCES branches(id)
) ENGINE=InnoDB;

CREATE TABLE loan_products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(80) NOT NULL,
  min_amount DECIMAL(12,2) NOT NULL,
  max_amount DECIMAL(12,2) NOT NULL,
  interest_rate DECIMAL(5,2) NOT NULL,
  min_tenure_months INT NOT NULL,
  max_tenure_months INT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE loan_applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_no VARCHAR(20) NOT NULL UNIQUE,
  customer_id INT NOT NULL,
  product_id INT NOT NULL,
  branch_id INT NULL,                  -- set automatically from the customer's PIN code
  assigned_officer_id INT NULL,
  created_by INT NOT NULL,
  channel ENUM('online','branch') NOT NULL DEFAULT 'online',
  requested_amount DECIMAL(12,2) NOT NULL,
  tenure_months INT NOT NULL,
  interest_rate DECIMAL(5,2) NOT NULL,
  purpose VARCHAR(255) NULL,
  details_json JSON NULL,              -- loan-type specific fields
  applicant_json JSON NULL,            -- personal / financial details (two-part application)
  is_fast_track TINYINT(1) NOT NULL DEFAULT 0,
  current_step TINYINT NOT NULL DEFAULT 0,        -- last completed wizard step of a draft
  eligibility_result VARCHAR(20) NULL,            -- may_meet | more_info | not_met (indicative only)
  declared_at DATETIME NULL,
  status ENUM('draft','submitted','documents_required','under_review',
              'pending_manager_decision','approved','rejected','withdrawn',
              'agreement_pending','ready_for_disbursement','disbursement_failed',
              'active','closed') NOT NULL DEFAULT 'draft',
  submitted_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (product_id) REFERENCES loan_products(id),
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  FOREIGN KEY (assigned_officer_id) REFERENCES users(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  INDEX idx_status (status),
  INDEX idx_branch_status (branch_id, status)
) ENGINE=InnoDB;

CREATE TABLE application_documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  doc_key VARCHAR(30) NULL,            -- slot in the checklist, e.g. id_proof, extra_1
  doc_type VARCHAR(60) NOT NULL,       -- readable name
  file_path VARCHAR(255) NOT NULL,
  original_name VARCHAR(150) NOT NULL,
  mime_type VARCHAR(60) NOT NULL,
  file_size INT NOT NULL,
  review_status ENUM('pending','received','missing','clarification') NOT NULL DEFAULT 'pending',
  review_note VARCHAR(255) NULL,
  uploaded_by INT NOT NULL,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_app_doc (application_id, doc_key),
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (uploaded_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- Officer's field verification: a visit, a call or a document check
CREATE TABLE field_verifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  officer_id INT NOT NULL,
  method ENUM('visit','call','document_check') NOT NULL,
  outcome ENUM('satisfactory','concerns','unable') NOT NULL,
  visit_date DATE NULL,
  address_verified TINYINT(1) NOT NULL DEFAULT 0,
  note TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (officer_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE document_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  requested_by INT NOT NULL,
  reason VARCHAR(255) NOT NULL,
  status ENUM('open','fulfilled') NOT NULL DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  fulfilled_at DATETIME NULL,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (requested_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE application_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  from_status VARCHAR(40) NULL,
  to_status VARCHAR(40) NOT NULL,
  changed_by INT NOT NULL,
  note VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (changed_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE review_notes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  officer_id INT NOT NULL,
  note TEXT NOT NULL,
  recommendation ENUM('none','approve','reject') NOT NULL DEFAULT 'none',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (officer_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE approval_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  manager_id INT NOT NULL,
  decision ENUM('approved','rejected','returned') NOT NULL,
  approved_amount DECIMAL(12,2) NULL,
  reason VARCHAR(255) NOT NULL,
  decided_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (manager_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE loan_accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  account_no VARCHAR(20) NOT NULL UNIQUE,
  application_id INT NOT NULL UNIQUE,
  customer_id INT NOT NULL,
  product_id INT NOT NULL,
  principal DECIMAL(12,2) NOT NULL,
  interest_rate DECIMAL(5,2) NOT NULL,
  tenure_months INT NOT NULL,
  emi_amount DECIMAL(12,2) NOT NULL,
  first_emi_date DATE NOT NULL,
  outstanding_balance DECIMAL(12,2) NOT NULL,
  status ENUM('active','closed') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (product_id) REFERENCES loan_products(id)
) ENGINE=InnoDB;

CREATE TABLE repayment_schedule (
  id INT AUTO_INCREMENT PRIMARY KEY,
  loan_account_id INT NOT NULL,
  installment_no INT NOT NULL,
  due_date DATE NOT NULL,
  emi_amount DECIMAL(12,2) NOT NULL,
  principal_part DECIMAL(12,2) NOT NULL,
  interest_part DECIMAL(12,2) NOT NULL,
  balance_after DECIMAL(12,2) NOT NULL,
  status ENUM('due','paid','overdue') NOT NULL DEFAULT 'due',
  paid_on DATE NULL,
  UNIQUE KEY uq_loan_inst (loan_account_id, installment_no),
  FOREIGN KEY (loan_account_id) REFERENCES loan_accounts(id)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  loan_account_id INT NOT NULL,
  schedule_id INT NULL,
  amount DECIMAL(12,2) NOT NULL,
  mode ENUM('cash','upi','bank_transfer','demo') NOT NULL DEFAULT 'demo',
  reference VARCHAR(40) NULL,
  recorded_by INT NOT NULL,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (loan_account_id) REFERENCES loan_accounts(id),
  FOREIGN KEY (schedule_id) REFERENCES repayment_schedule(id),
  FOREIGN KEY (recorded_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE disbursement_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  reference VARCHAR(30) NOT NULL UNIQUE,   -- e.g. SIM-DISB-10001
  status ENUM('processing','success','failed') NOT NULL,
  message VARCHAR(255) NULL,
  initiated_by INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (application_id) REFERENCES loan_applications(id),
  FOREIGN KEY (initiated_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  application_id INT NULL,
  message VARCHAR(255) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (application_id) REFERENCES loan_applications(id)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(60) NOT NULL,
  entity VARCHAR(40) NULL,
  entity_id INT NULL,
  details VARCHAR(255) NULL,
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- Seed data ----------
INSERT INTO branches (code, name, city, district, state, is_default) VALUES
('CHN', 'Chennai Branch', 'Chennai', 'Chennai', 'Tamil Nadu', 1),
('CBE', 'Coimbatore Branch', 'Coimbatore', 'Coimbatore', 'Tamil Nadu', 0),
('MDU', 'Madurai Branch', 'Madurai', 'Madurai', 'Tamil Nadu', 0);

INSERT INTO branch_pincodes (branch_id, pincode)
SELECT b.id, p.pin FROM branches b JOIN (
  SELECT 'CHN' AS code, '600001' AS pin UNION ALL SELECT 'CHN','600002' UNION ALL SELECT 'CHN','600017' UNION ALL SELECT 'CHN','600020' UNION ALL SELECT 'CHN','600042'
  UNION ALL SELECT 'CBE','641001' UNION ALL SELECT 'CBE','641002' UNION ALL SELECT 'CBE','641012' UNION ALL SELECT 'CBE','641018' UNION ALL SELECT 'CBE','641035'
  UNION ALL SELECT 'MDU','625001' UNION ALL SELECT 'MDU','625002' UNION ALL SELECT 'MDU','625010' UNION ALL SELECT 'MDU','625016' UNION ALL SELECT 'MDU','625020'
) p ON p.code = b.code;

INSERT INTO loan_products (code, name, min_amount, max_amount, interest_rate, min_tenure_months, max_tenure_months) VALUES
('PERSONAL',  'Personal Loan',          10000,   1000000, 12.50, 6,  60),
('DURABLE',   'Consumer Durable Loan',   5000,    200000, 14.00, 3,  24),
('BUSINESS',  'Business Loan',          50000,   5000000, 13.00, 12, 84),
('EDUCATION', 'Education Loan',         50000,   3000000, 9.50,  12, 120),
('HOME',      'Home / Construction Loan', 200000, 10000000, 8.75, 60, 240),
('VEHICLE',   'Vehicle Loan',           50000,   2000000, 10.50, 12, 84);
