<?php
// Sends each logged-in user to their own dashboard
require __DIR__ . '/includes/bootstrap.php';
require_login();
redirect_to_home();
