<?php
require __DIR__ . '/includes/bootstrap.php';
require_role(['customer']);

$u = current_user();
$s = $pdo->prepare('SELECT customer_code FROM customers WHERE user_id = ?');
$s->execute([$u['id']]);
$code = (string)$s->fetchColumn();
$next = BASE_URL . '/customer/dashboard.php';

auth_start('customer', 'Welcome');
?>
      <h2 class="au-title">Welcome, <?= e(explode(' ', $u['name'])[0]) ?>!</h2>
      <p class="au-lead">Your FinBridge account is ready.</p>
      <div class="au-idbox"><small>Your Customer ID</small><strong><?= e($code) ?></strong></div>
      <p class="au-lead">Save this ID. Next time you can sign in with it, your mobile number or your email.</p>
      <a class="au-btn" href="<?= e($next) ?>">Go to my dashboard <span>→</span></a>
      <p class="au-hint">Taking you there automatically...</p>
      <script>setTimeout(function () { window.location.href = <?= json_encode($next) ?>; }, 8000);</script>
<?php auth_end();
