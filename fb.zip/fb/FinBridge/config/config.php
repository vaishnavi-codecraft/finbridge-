<?php
// config/config.php - app-wide settings

// BASE_URL is detected automatically (works whatever the folder is named in htdocs)
$__root = str_replace('\\', '/', (string)realpath($_SERVER['DOCUMENT_ROOT'] ?? ''));
$__proj = str_replace('\\', '/', (string)realpath(__DIR__ . '/..'));
define('BASE_URL', rtrim(substr($__proj, strlen($__root)), '/'));
unset($__root, $__proj);

const APP_NAME = 'FinBridge';

// Where each role lands after login
const ROLE_HOME = [
    'customer'         => '/customer/dashboard.php',
    'branch_officer'   => '/staff/officer_dashboard.php',
    'branch_manager'   => '/staff/manager_dashboard.php',
    'accounts_officer' => '/accounts/dashboard.php',
    'admin'            => '/admin/dashboard.php',
];
