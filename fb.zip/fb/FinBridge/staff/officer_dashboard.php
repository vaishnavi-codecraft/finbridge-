<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['branch_officer']);

$u = current_user();
$scope  = "(a.assigned_officer_id = ? OR (a.assigned_officer_id IS NULL AND a.branch_id = ?)) AND a.status <> 'draft'";
$params = [$u['id'], $u['branch_id']];

$c = $pdo->prepare("SELECT a.status, COUNT(*) FROM loan_applications a WHERE $scope GROUP BY a.status");
$c->execute($params);
$counts = $c->fetchAll(PDO::FETCH_KEY_PAIR);
$n = fn($k) => (int)($counts[$k] ?? 0);

$pr = $pdo->prepare("SELECT COUNT(*) FROM loan_applications a WHERE $scope AND a.is_fast_track = 1 AND a.status IN ('submitted','under_review','documents_required')");
$pr->execute($params);
$priority = (int)$pr->fetchColumn();

$q = $pdo->prepare(
    "SELECT a.id, a.application_no, a.requested_amount, a.status, a.is_fast_track, a.submitted_at, p.name AS product, cu.full_name AS customer
     FROM loan_applications a
     JOIN loan_products p ON p.id = a.product_id
     JOIN customers c ON c.id = a.customer_id
     JOIN users cu ON cu.id = c.user_id
     WHERE $scope AND a.status IN ('submitted','under_review')
     ORDER BY a.is_fast_track DESC, a.submitted_at ASC LIMIT 5"
);
$q->execute($params);
$queue = $q->fetchAll();

$nt = $pdo->prepare('SELECT message, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 5');
$nt->execute([$u['id']]);
$notes = $nt->fetchAll();

page_header('Officer Dashboard');
?>
<div class="stats">
  <div class="stat"><b><?= $n('submitted') ?></b>New applications</div>
  <div class="stat"><b><?= $n('under_review') ?></b>Under review</div>
  <div class="stat"><b><?= $n('documents_required') ?></b>Waiting for customer</div>
  <div class="stat"><b><?= $n('pending_manager_decision') ?></b>With manager</div>
  <div class="stat"><b><?= $priority ?></b>Priority open</div>
</div>
<p><a class="btn" href="applications.php">View all applications</a></p>

<div class="card" style="margin-top:16px">
  <h2>Needs your attention</h2>
  <?php if (!$queue): ?><p class="muted">Nothing waiting. New applications will appear here.</p><?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>Application</th><th>Customer</th><th>Loan type</th><th>Amount</th><th>Status</th><th></th></tr>
    <?php foreach ($queue as $r): ?>
      <tr>
        <td><?= e($r['application_no']) ?> <?= $r['is_fast_track'] ? '<span class="badge badge-priority">Priority</span>' : '' ?></td>
        <td><?= e($r['customer']) ?></td><td><?= e($r['product']) ?></td>
        <td><?= money($r['requested_amount']) ?></td><td><?= status_badge($r['status']) ?></td>
        <td><a href="review.php?id=<?= (int)$r['id'] ?>">Open</a></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>

<div class="card" style="margin-top:16px">
  <h2>Notifications</h2>
  <?php if (!$notes): ?><p class="muted">No notifications.</p><?php else: ?>
  <ul class="timeline">
    <?php foreach ($notes as $x): ?>
      <li><?= e($x['message']) ?> <span class="muted"><?= e(date('d M, h:i A', strtotime($x['created_at']))) ?></span></li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>
</div>
<?php page_footer(); ?>
