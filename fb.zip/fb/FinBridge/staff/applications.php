<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['branch_officer', 'branch_manager']);

$u = current_user();
$isOfficer = $u['role'] === 'branch_officer';

// Which applications this user may see
if ($isOfficer) {
    $scope  = "(a.assigned_officer_id = ? OR (a.assigned_officer_id IS NULL AND a.branch_id = ?)) AND a.status <> 'draft'";
    $params = [$u['id'], $u['branch_id']];
} else {
    $scope  = "a.branch_id = ? AND a.status <> 'draft'";
    $params = [$u['branch_id']];
}

// Summary counts
$c = $pdo->prepare("SELECT a.status, COUNT(*) FROM loan_applications a WHERE $scope GROUP BY a.status");
$c->execute($params);
$counts = $c->fetchAll(PDO::FETCH_KEY_PAIR);
$n = fn($k) => (int)($counts[$k] ?? 0);

// Filters
$filter = $_GET['status'] ?? '';
$q = trim($_GET['q'] ?? '');
$where = $scope; $p = $params;
if ($filter !== '' && isset(STATUS_LABELS[$filter])) { $where .= ' AND a.status = ?'; $p[] = $filter; }
if ($q !== '') { $where .= ' AND (a.application_no LIKE ? OR cu.full_name LIKE ?)'; $p[] = "%$q%"; $p[] = "%$q%"; }

$s = $pdo->prepare(
    "SELECT a.id, a.application_no, a.requested_amount, a.tenure_months, a.status, a.is_fast_track, a.submitted_at,
            p.name AS product, cu.full_name AS customer, o.full_name AS officer
     FROM loan_applications a
     JOIN loan_products p ON p.id = a.product_id
     JOIN customers c ON c.id = a.customer_id
     JOIN users cu ON cu.id = c.user_id
     LEFT JOIN users o ON o.id = a.assigned_officer_id
     WHERE $where
     ORDER BY a.is_fast_track DESC, a.submitted_at ASC, a.id ASC LIMIT 200"
);
$s->execute($p);
$rows = $s->fetchAll();

page_header($isOfficer ? 'My Assigned Applications' : 'Branch Applications');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
?>
<div class="stats">
  <div class="stat"><b><?= $n('submitted') ?></b>New</div>
  <div class="stat"><b><?= $n('under_review') ?></b>Under review</div>
  <div class="stat"><b><?= $n('documents_required') ?></b>Waiting for customer</div>
  <div class="stat"><b><?= $n('pending_manager_decision') ?></b>With manager</div>
</div>

<form class="filters" method="get">
  <div><label for="q">Search (application ID or customer)</label>
    <input type="text" id="q" name="q" value="<?= e($q) ?>"></div>
  <div><label for="status">Status</label>
    <select id="status" name="status">
      <option value="">All</option>
      <?php foreach (STATUS_LABELS as $k => $label): if ($k === 'draft') continue; ?>
        <option value="<?= e($k) ?>" <?= $filter === $k ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select></div>
  <button type="submit">Filter</button>
</form>

<?php if (!$rows): ?>
  <div class="card"><p class="muted">No applications found.</p></div>
<?php else: ?>
<div class="table-wrap"><table>
  <tr><th>Application</th><th>Customer</th><th>Loan type</th><th>Amount</th><th>Status</th><th>Officer</th><th>Submitted</th><th></th></tr>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><?= e($r['application_no']) ?> <?= $r['is_fast_track'] ? '<span class="badge badge-priority">Priority</span>' : '' ?></td>
    <td><?= e($r['customer']) ?></td>
    <td><?= e($r['product']) ?></td>
    <td><?= money($r['requested_amount']) ?></td>
    <td><?= status_badge($r['status']) ?></td>
    <td><?= e($r['officer'] ?? 'Unassigned') ?></td>
    <td><?= e(date('d M Y', strtotime($r['submitted_at'] ?? 'now'))) ?></td>
    <td><a href="review.php?id=<?= (int)$r['id'] ?>">Open</a></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php endif;
page_footer();
