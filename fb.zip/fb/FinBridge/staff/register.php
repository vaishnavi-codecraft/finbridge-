<?php
require __DIR__ . '/../includes/bootstrap.php';
if (current_user()) redirect_to_home();

$branches = $pdo->query('SELECT id, name FROM branches WHERE is_active = 1 ORDER BY name')->fetchAll();
$roles = ['branch_officer' => 'Branch Officer', 'branch_manager' => 'Branch Manager', 'accounts_officer' => 'Accounts Officer'];
$error = '';
$done = false;
$old = ['name' => '', 'email' => '', 'phone' => '', 'role' => '', 'branch_id' => 0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old = [
        'name' => trim($_POST['name'] ?? ''), 'email' => trim($_POST['email'] ?? ''), 'phone' => trim($_POST['phone'] ?? ''),
        'role' => $_POST['role'] ?? '', 'branch_id' => (int)($_POST['branch_id'] ?? 0),
    ];
    $pass  = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';
    $validBranch = in_array($old['branch_id'], array_map('intval', array_column($branches, 'id')), true);

    if ($old['name'] === '' || strlen($old['name']) > 100) {
        $error = 'Enter your full name.';
    } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid work email address.';
    } elseif (!preg_match('/^[0-9]{10}$/', $old['phone'])) {
        $error = 'Enter a 10-digit mobile number.';
    } elseif (!isset($roles[$old['role']])) {
        $error = 'Select your role.';
    } elseif (!$validBranch) {
        $error = 'Select your branch.';
    } elseif (strlen($pass) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($pass !== $pass2) {
        $error = 'Password and confirmation do not match.';
    } elseif (empty($_POST['confirm'])) {
        $error = 'Please confirm that you are an authorised FinBridge employee.';
    } else {
        $chk = $pdo->prepare('SELECT 1 FROM users WHERE email = ? OR phone = ?');
        $chk->execute([$old['email'], $old['phone']]);
        if ($chk->fetchColumn()) {
            $error = 'This email or mobile number is already registered.';
        } else {
            // Saved as inactive with no Employee ID: the administrator approves it later
            $pdo->prepare('INSERT INTO users (branch_id, full_name, email, phone, password_hash, role, is_active) VALUES (?,?,?,?,?,?,0)')
                ->execute([$old['branch_id'], $old['name'], $old['email'], $old['phone'], password_hash($pass, PASSWORD_DEFAULT), $old['role']]);
            audit($pdo, null, 'staff_access_requested', 'user', (int)$pdo->lastInsertId(), $old['email']);
            $done = true;
        }
    }
}
auth_start('staff', 'Request Staff Access', ['Sign In', BASE_URL . '/staff/login.php']);
if ($done): ?>
      <h2 class="au-title">Request sent</h2>
      <p class="au-lead">Thank you, <?= e(explode(' ', $old['name'])[0]) ?>. Your access request has been sent to the administrator.</p>
      <div class="au-idbox"><small>What happens next</small>
        <p style="margin:8px 0 0;font-size:13px;color:#55627f">The administrator reviews your request, approves it and shares your <strong>Employee ID</strong>. Then you can sign in with that ID and the password you just created.</p></div>
      <a class="au-btn" href="login.php">Back to Sign In <span>→</span></a>
<?php else: ?>
      <h2 class="au-title">Request Access</h2>
      <p class="au-lead">For FinBridge employees. The administrator approves each request.</p>
      <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="au-field"><label for="name">FULL NAME</label>
          <input type="text" id="name" name="name" value="<?= e($old['name']) ?>" placeholder="Your full name" required autofocus></div>
        <div class="au-field"><label for="email">WORK EMAIL</label>
          <input type="email" id="email" name="email" value="<?= e($old['email']) ?>" placeholder="name@finbridge.test" required></div>
        <div class="au-field"><label for="phone">MOBILE NUMBER</label>
          <input type="tel" id="phone" name="phone" value="<?= e($old['phone']) ?>" maxlength="10" placeholder="10-digit number" required></div>
        <div class="au-field"><label for="role">YOUR ROLE</label>
          <select id="role" name="role" required>
            <option value="">Select role</option>
            <?php foreach ($roles as $k => $l): ?><option value="<?= e($k) ?>" <?= $old['role'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?>
          </select></div>
        <div class="au-field"><label for="branch_id">BRANCH</label>
          <select id="branch_id" name="branch_id" required>
            <option value="">Select branch</option>
            <?php foreach ($branches as $b): ?><option value="<?= (int)$b['id'] ?>" <?= (int)$old['branch_id'] === (int)$b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?>
          </select></div>
        <?php auth_password_field('password', 'CREATE PASSWORD', 'Minimum 8 characters'); ?>
        <?php auth_password_field('password2', 'CONFIRM PASSWORD', 'Re-enter password'); ?>
        <label class="au-check"><input type="checkbox" name="confirm" value="1"> I confirm I am an authorised FinBridge employee.</label>
        <button class="au-btn" type="submit">Send Request <span>→</span></button>
      </form>
      <p class="au-alt">Already approved? <a href="login.php">Sign in</a></p>
<?php endif;
auth_end();
