<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['branch_manager']);

$u = current_user();
$bid = $u['branch_id'];

$c = $pdo->prepare("SELECT status, COUNT(*) FROM loan_applications WHERE branch_id = ? AND status <> 'draft' GROUP BY status");
$c->execute([$bid]);
$counts = $c->fetchAll(PDO::FETCH_KEY_PAIR);
$n = fn($k) => (int)($counts[$k] ?? 0);
$total = array_sum($counts);
$approved = $n('approved') + $n('agreement_pending') + $n('ready_for_disbursement') + $n('disbursement_failed') + $n('active') + $n('closed');

$w = $pdo->prepare(
    "SELECT u.full_name, COUNT(a.id) AS open_apps
     FROM users u
     LEFT JOIN loan_applications a ON a.assigned_officer_id = u.id
          AND a.status IN ('submitted','under_review','documents_required','pending_manager_decision')
     WHERE u.role = 'branch_officer' AND u.branch_id = ? AND u.is_active = 1
     GROUP BY u.id, u.full_name ORDER BY u.full_name"
);
$w->execute([$bid]);
$officers = $w->fetchAll();

$p = $pdo->prepare(
    "SELECT a.id, a.application_no, a.requested_amount, a.is_fast_track, p.name AS product, cu.full_name AS customer
     FROM loan_applications a
     JOIN loan_products p ON p.id = a.product_id
     JOIN customers c ON c.id = a.customer_id
     JOIN users cu ON cu.id = c.user_id
     WHERE a.branch_id = ? AND a.status = 'pending_manager_decision'
     ORDER BY a.is_fast_track DESC, a.id ASC LIMIT 5"
);
$p->execute([$bid]);
$pending = $p->fetchAll();

$nt = $pdo->prepare('SELECT message, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 5');
$nt->execute([$u['id']]);
$notes = $nt->fetchAll();

page_header('Manager Dashboard');
?>
<div class="stats">
  <div class="stat"><b><?= $total ?></b>Branch applications</div>
  <div class="stat"><b><?= $n('pending_manager_decision') ?></b>Awaiting decision</div>
  <div class="stat"><b><?= $approved ?></b>Approved</div>
  <div class="stat"><b><?= $n('rejected') ?></b>Rejected</div>
</div>
<p><a class="btn" href="applications.php">Branch applications</a>
   <a class="btn btn-line" href="manager_queue.php">Decision queue</a></p>

<div class="card" style="margin-top:16px">
  <h2>Awaiting your decision</h2>
  <?php if (!$pending): ?><p class="muted">No applications are waiting for a decision.</p><?php else: ?>
  <div class="table-wrap"><table>
    <tr><th>Application</th><th>Customer</th><th>Loan type</th><th>Amount</th><th></th></tr>
    <?php foreach ($pending as $r): ?>
      <tr>
        <td><?= e($r['application_no']) ?> <?= $r['is_fast_track'] ? '<span class="badge badge-priority">Priority</span>' : '' ?></td>
        <td><?= e($r['customer']) ?></td><td><?= e($r['product']) ?></td><td><?= money($r['requested_amount']) ?></td>
        <td><a href="review.php?id=<?= (int)$r['id'] ?>">Open</a></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>

<div class="card" style="margin-top:16px">
  <h2>Officer workload</h2>
  <div class="table-wrap"><table>
    <tr><th>Officer</th><th>Open applications</th></tr>
    <?php foreach ($officers as $o): ?>
      <tr><td><?= e($o['full_name']) ?></td><td><?= (int)$o['open_apps'] ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="card" style="margin-top:16px">
  <h2>Notifications</h2>
  <?php if (!$notes): ?><p class="muted">No notifications.</p><?php else: ?>
  <ul class="timeline">
    <?php foreach ($notes as $x): ?>
      <li><?= e($x['message']) ?> <span class="muted"><?= e(date('d M, h:i A', strtotime($x['created_at']))) ?></span></li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>
</div>
<?php page_footer(); ?>
