<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['branch_manager']);

$u = current_user();
$s = $pdo->prepare(
    "SELECT a.id, a.application_no, a.requested_amount, a.tenure_months, a.is_fast_track, a.submitted_at,
            p.name AS product, cu.full_name AS customer, o.full_name AS officer,
            (SELECT n.recommendation FROM review_notes n
              WHERE n.application_id = a.id AND n.recommendation <> 'none' ORDER BY n.id DESC LIMIT 1) AS recommendation
     FROM loan_applications a
     JOIN loan_products p ON p.id = a.product_id
     JOIN customers c ON c.id = a.customer_id
     JOIN users cu ON cu.id = c.user_id
     LEFT JOIN users o ON o.id = a.assigned_officer_id
     WHERE a.branch_id = ? AND a.status = 'pending_manager_decision'
     ORDER BY a.is_fast_track DESC, a.id ASC LIMIT 100"
);
$s->execute([$u['branch_id']]);
$rows = $s->fetchAll();

page_header('Decision Queue');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
if (!$rows) {
    echo '<div class="card"><p class="muted">No applications are waiting for a decision.</p></div>';
} else { ?>
<div class="table-wrap"><table>
  <tr><th>Application</th><th>Customer</th><th>Loan type</th><th>Amount</th><th>Officer</th><th>Officer recommends</th><th></th></tr>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><?= e($r['application_no']) ?> <?= $r['is_fast_track'] ? '<span class="badge badge-priority">Priority</span>' : '' ?></td>
    <td><?= e($r['customer']) ?></td>
    <td><?= e($r['product']) ?></td>
    <td><?= money($r['requested_amount']) ?></td>
    <td><?= e($r['officer'] ?? '-') ?></td>
    <td><?= e($r['recommendation'] ?? '-') ?></td>
    <td><a href="review.php?id=<?= (int)$r['id'] ?>">Review &amp; decide</a></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<?php }
page_footer();
