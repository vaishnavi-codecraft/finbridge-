# FinBridge Loan Management System (demo prototype)

Fictional finance company with physical branches (Chennai, Coimbatore, Madurai out of the box; the admin can add more).
PHP + MySQL + HTML/CSS/JS. Uses simulated disbursement only. No real money or real customer data.

## Setup (XAMPP)
1. Start Apache and MySQL.
2. phpMyAdmin > Import > `database/finbridge.sql` (fresh install, includes everything).
   **Already have the database?** Do NOT re-import (it would erase your data). Open phpMyAdmin > `finbridge` > SQL and run
   `database/migration_003_two_part_apply.sql` once. It keeps your data and is safe to run twice. (XAMPP's MariaDB is required;
   plain MySQL does not support `ADD COLUMN IF NOT EXISTS`.)
3. Put this folder in `C:\xampp\htdocs\`.
4. Fresh install only: open `http://localhost/<folder-name>/database/seed_users.php` once, then delete that file.
5. Open `http://localhost/<folder-name>/`.
6. Uploaded documents are saved in `storage/documents/` (blocked from the web by `storage/.htaccess`; files are only
   served through `download_document.php` after a permission check). The folder must be writable (it is by default on XAMPP).

## Login pages (password for all demo users: Demo@123)
- Customers: `/login.php` - Customer ID (FBC000001), mobile 9876543210, or customer@finbridge.test
- Staff: `/staff/login.php` - OFF-CHN-001 (officer), MGR-CHN-001 (manager), ACC-001 (accounts); same pattern for CBE and MDU
- Admin: `/admin/login.php` - ADM-001

## How a loan application works
1. **Quick Apply** (`customer/apply.php`): a few loan-specific questions, live EMI and an indicative eligibility result
   ("May meet initial criteria" / "More information required" / "Does not meet the current demo criteria").
   Saved as a **draft**. The customer is never asked to pick a branch.
2. **Complete your application** (`customer/complete.php`): personal details (the **PIN code picks the branch** automatically),
   financial details, loan details, documents, then a review page with Edit links and the declaration. **Submit** gives the
   application number (FB2026-00001), sets the status to Submitted and assigns an officer of the matched branch.
3. **Branch officer** checks each document (accept / ask for re-upload), records **field verification** (in-person visit, call or
   document check, with notes) and forwards the case with a recommendation. A home loan cannot be forwarded without a recorded visit,
   and nothing can be forwarded while required documents are missing or marked "re-upload needed".
4. **Branch manager** reads the officer's findings and verification, then approves, rejects or returns it.
5. If the officer asks for more documents, the customer uploads them in **My Documents** and sends a response; the case goes back to the officer.
6. Disbursement, loan accounts, EMI and repayments are the next stages (the pages exist as stubs).

Branch matching order: PIN code, then district, then city, then state, then the default branch (set by the admin in **Admin > Branches**).

## Build stages
1. Database + connection: done
2. Login, roles, branches (with PIN codes): done
3. Customer portal, Quick Apply and the application wizard (6 loan types): done
4. Document upload and secure download: done
5. Officer portal: document review, field verification, forward to manager: done
6. Manager approval: done
7. Staff registration + admin approval, admin Branches page: done
8. Notifications across portals: in place for every status change above; reviewed again after disbursement is added
9. Dummy bank disbursement: next
10. Loan accounts, EMI schedule, repayments: next
11. Admin loan products, overview/reports, UI polish: next
