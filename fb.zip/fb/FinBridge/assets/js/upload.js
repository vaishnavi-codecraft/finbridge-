// Uploads one document in the background and refreshes the checklist. Without JS the form posts normally.
(function () {
  document.querySelectorAll('form.doc-form').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      if (!window.fetch || !window.FormData) return;
      ev.preventDefault();
      var msg = form.querySelector('.doc-msg'), btn = form.querySelector('button');
      var file = form.querySelector('input[type=file]').files[0];
      if (!file) { msg.textContent = 'Choose a file first.'; return; }
      if (file.size > 5 * 1024 * 1024) { msg.textContent = 'File is larger than 5 MB.'; return; }
      btn.disabled = true; msg.textContent = 'Uploading…';
      fetch(form.action, { method: 'POST', body: new FormData(form), headers: { 'X-Requested-With': 'XMLHttpRequest' }, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          msg.textContent = j.message;
          if (j.ok) setTimeout(function () { window.location.reload(); }, 600); else btn.disabled = false;
        })
        .catch(function () { msg.textContent = 'Upload failed. Please try again.'; btn.disabled = false; });
    });
  });
})();
