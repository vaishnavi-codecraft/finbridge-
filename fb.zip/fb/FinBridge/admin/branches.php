<?php
// Branches: add / edit / deactivate branches and the PIN codes each one serves.
// Customers are routed to a branch automatically: PIN code, then district, city, state, then the default branch.
require __DIR__ . '/../includes/bootstrap.php';
require_role(['admin']);

$me = current_user();
$error = '';
$editId = (int)($_GET['edit'] ?? $_POST['id'] ?? 0);
$pipeline = "'submitted','documents_required','under_review','pending_manager_decision','approved','agreement_pending','ready_for_disbursement','disbursement_failed'";

function parse_pins(string $raw, array &$errors): array {
    $pins = [];
    foreach (preg_split('/[\s,;]+/', trim($raw), -1, PREG_SPLIT_NO_EMPTY) as $p) {
        if (!preg_match('/^[0-9]{6}$/', $p)) { $errors[] = "\"$p\" is not a 6-digit PIN code."; continue; }
        $pins[$p] = $p;
    }
    return array_values($pins);
}

$form = ['code' => '', 'name' => '', 'city' => '', 'district' => '', 'state' => 'Tamil Nadu', 'address' => '', 'pincodes' => '', 'is_default' => 0, 'is_active' => 1];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $id  = (int)($_POST['id'] ?? 0);

    if ($act === 'toggle') {
        $b = $pdo->prepare('SELECT * FROM branches WHERE id = ?'); $b->execute([$id]); $b = $b->fetch();
        if (!$b) { $error = 'Branch not found.'; }
        elseif ($b['is_active']) {
            $open = $pdo->prepare("SELECT COUNT(*) FROM loan_applications WHERE branch_id = ? AND status IN ($pipeline)");
            $open->execute([$id]);
            if ($b['is_default']) $error = 'This is the default branch. Make another branch the default first.';
            elseif ((int)$open->fetchColumn() > 0) $error = 'This branch still has applications in progress. Finish or move them before deactivating it.';
        }
        if (!$error) {
            $pdo->prepare('UPDATE branches SET is_active = 1 - is_active WHERE id = ?')->execute([$id]);
            audit($pdo, $me['id'], 'branch_toggled', 'branch', $id);
            set_flash('Branch status updated.');
            header('Location: branches.php'); exit;
        }
    } elseif ($act === 'save') {
        $editId = $id;
        $form = [
            'code' => strtoupper(trim($_POST['code'] ?? '')), 'name' => trim($_POST['name'] ?? ''), 'city' => trim($_POST['city'] ?? ''),
            'district' => trim($_POST['district'] ?? ''), 'state' => trim($_POST['state'] ?? ''), 'address' => trim($_POST['address'] ?? ''),
            'pincodes' => trim($_POST['pincodes'] ?? ''), 'is_default' => empty($_POST['is_default']) ? 0 : 1, 'is_active' => empty($_POST['is_active']) ? 0 : 1,
        ];
        $existing = null;
        if ($id) { $q = $pdo->prepare('SELECT * FROM branches WHERE id = ?'); $q->execute([$id]); $existing = $q->fetch(); if (!$existing) $error = 'Branch not found.'; }
        if ($existing) $form['code'] = $existing['code'];       // the code never changes (it appears in Employee IDs)
        if (!$id) $form['is_active'] = 1;

        $errs = [];
        if (!$error) {
            if (!preg_match('/^[A-Z0-9]{2,6}$/', $form['code'])) $errs[] = 'Branch code must be 2 to 6 letters or digits.';
            if ($form['name'] === '' || mb_strlen($form['name']) > 80) $errs[] = 'Enter the branch name (up to 80 characters).';
            foreach (['city' => 'city', 'district' => 'district', 'state' => 'state'] as $k => $l) {
                if ($form[$k] === '' || mb_strlen($form[$k]) > 60) $errs[] = "Enter the $l (up to 60 characters).";
            }
            if (mb_strlen($form['address']) > 200) $errs[] = 'Address is too long.';
            $pins = parse_pins($form['pincodes'], $errs);
            if (!$pins) $errs[] = 'Add at least one PIN code this branch serves.';
            if (!$id) {
                $d = $pdo->prepare('SELECT 1 FROM branches WHERE code = ?'); $d->execute([$form['code']]);
                if ($d->fetchColumn()) $errs[] = 'That branch code already exists.';
            }
            foreach ($pins as $p) {
                $o = $pdo->prepare('SELECT b.name FROM branch_pincodes bp JOIN branches b ON b.id = bp.branch_id WHERE bp.pincode = ? AND bp.branch_id <> ?');
                $o->execute([$p, $id]);
                if ($n = $o->fetchColumn()) $errs[] = "PIN $p already belongs to $n.";
            }
            if ($existing && $existing['is_default'] && !$form['is_default']) $errs[] = 'This is the default branch. Make another branch the default instead.';
            if ($form['is_default'] && !$form['is_active']) $errs[] = 'The default branch must be active.';
            if ($existing && $existing['is_active'] && !$form['is_active']) {
                $open = $pdo->prepare("SELECT COUNT(*) FROM loan_applications WHERE branch_id = ? AND status IN ($pipeline)"); $open->execute([$id]);
                if ((int)$open->fetchColumn() > 0) $errs[] = 'This branch still has applications in progress, so it cannot be deactivated.';
            }
            $error = implode(' ', $errs);
        }
        if (!$error) {
            $pdo->beginTransaction();
            if ($id) {
                $pdo->prepare('UPDATE branches SET name=?, city=?, district=?, state=?, address=?, is_active=? WHERE id=?')
                    ->execute([$form['name'], $form['city'], $form['district'], $form['state'], $form['address'] ?: null, $form['is_active'], $id]);
            } else {
                $pdo->prepare('INSERT INTO branches (code, name, city, district, state, address, is_active) VALUES (?,?,?,?,?,?,1)')
                    ->execute([$form['code'], $form['name'], $form['city'], $form['district'], $form['state'], $form['address'] ?: null]);
                $id = (int)$pdo->lastInsertId();
            }
            if ($form['is_default']) {
                $pdo->exec('UPDATE branches SET is_default = 0');
                $pdo->prepare('UPDATE branches SET is_default = 1 WHERE id = ?')->execute([$id]);
            }
            $pdo->prepare('DELETE FROM branch_pincodes WHERE branch_id = ?')->execute([$id]);
            $ins = $pdo->prepare('INSERT INTO branch_pincodes (branch_id, pincode) VALUES (?,?)');
            foreach ($pins as $p) $ins->execute([$id, $p]);
            $pdo->commit();
            audit($pdo, $me['id'], $existing ? 'branch_updated' : 'branch_created', 'branch', $id, $form['code']);
            set_flash('Branch saved (' . count($pins) . ' PIN codes).');
            header('Location: branches.php'); exit;
        }
    }
} elseif ($editId) {
    $q = $pdo->prepare('SELECT * FROM branches WHERE id = ?'); $q->execute([$editId]);
    if ($b = $q->fetch()) {
        $p = $pdo->prepare('SELECT pincode FROM branch_pincodes WHERE branch_id = ? ORDER BY pincode'); $p->execute([$editId]);
        $form = ['code' => $b['code'], 'name' => $b['name'], 'city' => $b['city'], 'district' => (string)$b['district'], 'state' => (string)$b['state'],
                 'address' => (string)$b['address'], 'pincodes' => implode(', ', $p->fetchAll(PDO::FETCH_COLUMN)),
                 'is_default' => (int)$b['is_default'], 'is_active' => (int)$b['is_active']];
    } else $editId = 0;
}

$list = $pdo->query(
    "SELECT b.*, (SELECT COUNT(*) FROM branch_pincodes p WHERE p.branch_id = b.id) AS pins,
            (SELECT COUNT(*) FROM users u WHERE u.branch_id = b.id AND u.role <> 'customer' AND u.is_active = 1) AS staff,
            (SELECT COUNT(*) FROM loan_applications a WHERE a.branch_id = b.id AND a.status IN ($pipeline)) AS open_apps
     FROM branches b ORDER BY b.is_active DESC, b.name"
)->fetchAll();

page_header('Branches');
if ($f = get_flash()) echo '<div class="success">' . e($f) . '</div>';
if ($error) echo '<div class="error">' . e($error) . '</div>';
$csrf = e(csrf_token());
?>
<div class="stack">
<div class="card">
  <h2>All branches</h2>
  <p class="muted">A customer's PIN code decides which branch handles their application. If no PIN matches, the district, city and state are tried, then the default branch.</p>
  <div class="table-wrap"><table>
    <tr><th>Code</th><th>Branch</th><th>District</th><th>PIN codes</th><th>Active staff</th><th>Open applications</th><th>Status</th><th></th></tr>
    <?php foreach ($list as $b): ?>
      <tr>
        <td><?= e($b['code']) ?></td>
        <td><?= e($b['name']) ?> <?= $b['is_default'] ? '<span class="badge badge-submitted">Default</span>' : '' ?></td>
        <td><?= e($b['district']) ?>, <?= e($b['state']) ?></td><td><?= (int)$b['pins'] ?></td><td><?= (int)$b['staff'] ?></td><td><?= (int)$b['open_apps'] ?></td>
        <td><?= $b['is_active'] ? '<span class="badge badge-approved">Active</span>' : '<span class="badge badge-rejected">Inactive</span>' ?></td>
        <td>
          <a class="btn btn-sm btn-line" style="display:inline-block" href="branches.php?edit=<?= (int)$b['id'] ?>">Edit</a>
          <form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><input type="hidden" name="action" value="toggle">
            <button class="btn-sm btn-line" type="submit"><?= $b['is_active'] ? 'Deactivate' : 'Activate' ?></button></form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="card" id="form">
  <h2><?= $editId ? 'Edit branch ' . e($form['code']) : 'Add a branch' ?></h2>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= $csrf ?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)$editId ?>">
    <div class="form-grid">
      <div><label for="code">Branch code (2-6 letters/digits)</label><input type="text" id="code" name="code" maxlength="6" value="<?= e($form['code']) ?>" <?= $editId ? 'readonly' : 'required' ?> style="text-transform:uppercase"></div>
      <div><label for="name">Branch name</label><input type="text" id="name" name="name" maxlength="80" value="<?= e($form['name']) ?>" required></div>
      <div><label for="city">City</label><input type="text" id="city" name="city" maxlength="60" value="<?= e($form['city']) ?>" required></div>
      <div><label for="district">District</label><input type="text" id="district" name="district" maxlength="60" value="<?= e($form['district']) ?>" required></div>
      <div><label for="state">State</label><input type="text" id="state" name="state" maxlength="60" value="<?= e($form['state']) ?>" required></div>
      <div><label for="address">Address (optional)</label><input type="text" id="address" name="address" maxlength="200" value="<?= e($form['address']) ?>"></div>
    </div>
    <label for="pincodes">PIN codes served (6 digits each, separated by commas, spaces or new lines)</label>
    <textarea id="pincodes" name="pincodes" rows="3" required><?= e($form['pincodes']) ?></textarea>
    <label class="check"><input type="checkbox" name="is_default" value="1" <?= $form['is_default'] ? 'checked' : '' ?>> Default branch (used when no PIN code or district matches)</label>
    <?php if ($editId): ?><label class="check"><input type="checkbox" name="is_active" value="1" <?= $form['is_active'] ? 'checked' : '' ?>> Active</label><?php endif; ?>
    <button type="submit" style="width:auto;padding:10px 20px"><?= $editId ? 'Save changes' : 'Add branch' ?></button>
    <?php if ($editId): ?> <a href="branches.php">Cancel</a><?php endif; ?>
  </form>
</div>
</div>
<?php page_footer(); ?>
