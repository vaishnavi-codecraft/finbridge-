<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['admin']);
page_header('Administrator Overview');
coming_soon('Stage 10 (reports)');
page_footer();
