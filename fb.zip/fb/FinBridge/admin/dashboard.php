<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['admin']);

$totalApps = (int)$pdo->query("SELECT COUNT(*) FROM loan_applications WHERE status <> 'draft'")->fetchColumn();
$customers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$staff     = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role <> 'customer'")->fetchColumn();
$active    = (int)$pdo->query("SELECT COUNT(*) FROM loan_accounts WHERE status = 'active'")->fetchColumn();

$inProg = "'submitted','under_review','documents_required','pending_manager_decision'";
$appr   = "'approved','agreement_pending','ready_for_disbursement','disbursement_failed','active','closed'";

$branches = $pdo->query(
    "SELECT b.name, COUNT(a.id) AS total,
            COALESCE(SUM(a.status IN ($inProg)), 0) AS in_progress,
            COALESCE(SUM(a.status IN ($appr)), 0) AS approved,
            COALESCE(SUM(a.status = 'rejected'), 0) AS rejected
     FROM branches b LEFT JOIN loan_applications a ON a.branch_id = b.id AND a.status <> 'draft'
     GROUP BY b.id, b.name ORDER BY b.name"
)->fetchAll();

$products = $pdo->query(
    "SELECT p.name, COUNT(a.id) AS total, COALESCE(SUM(a.requested_amount), 0) AS amount
     FROM loan_products p LEFT JOIN loan_applications a ON a.product_id = p.id AND a.status <> 'draft'
     GROUP BY p.id, p.name ORDER BY p.id"
)->fetchAll();

$team = $pdo->query(
    "SELECT u.full_name, u.email, u.employee_code, u.role, b.name AS branch
     FROM users u LEFT JOIN branches b ON b.id = u.branch_id
     WHERE u.role <> 'customer' ORDER BY u.role, u.full_name"
)->fetchAll();

page_header('Administrator Dashboard');
?>
<div class="stats">
  <div class="stat"><b><?= $totalApps ?></b>Applications (all branches)</div>
  <div class="stat"><b><?= $customers ?></b>Customers</div>
  <div class="stat"><b><?= $staff ?></b>Staff accounts</div>
  <div class="stat"><b><?= $active ?></b>Active loan accounts</div>
</div>

<div class="card">
  <h2>Branches</h2>
  <div class="table-wrap"><table>
    <tr><th>Branch</th><th>Total</th><th>In progress</th><th>Approved</th><th>Rejected</th></tr>
    <?php foreach ($branches as $b): ?>
      <tr><td><?= e($b['name']) ?></td><td><?= (int)$b['total'] ?></td><td><?= (int)$b['in_progress'] ?></td>
          <td><?= (int)$b['approved'] ?></td><td><?= (int)$b['rejected'] ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="card" style="margin-top:16px">
  <h2>Loan products</h2>
  <div class="table-wrap"><table>
    <tr><th>Product</th><th>Applications</th><th>Total requested</th></tr>
    <?php foreach ($products as $p): ?>
      <tr><td><?= e($p['name']) ?></td><td><?= (int)$p['total'] ?></td><td><?= money($p['amount']) ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="card" style="margin-top:16px">
  <h2>Staff</h2>
  <div class="table-wrap"><table>
    <tr><th>Employee ID</th><th>Name</th><th>Role</th><th>Branch</th><th>Email</th></tr>
    <?php foreach ($team as $t): ?>
      <tr><td><?= e($t['employee_code']) ?></td><td><?= e($t['full_name']) ?></td><td><?= e(str_replace('_', ' ', $t['role'])) ?></td>
          <td><?= e($t['branch'] ?? 'Head office') ?></td><td><?= e($t['email']) ?></td></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php page_footer(); ?>
