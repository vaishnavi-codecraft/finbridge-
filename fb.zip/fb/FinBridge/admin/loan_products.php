<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role(['admin']);
page_header('Loan Products');
coming_soon('Stage 10');
page_footer();
