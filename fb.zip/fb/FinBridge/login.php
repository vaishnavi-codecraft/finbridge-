<?php
require __DIR__ . '/includes/bootstrap.php';
if (current_user()) redirect_to_home();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $error = attempt_login($pdo, trim($_POST['identifier'] ?? ''), $_POST['password'] ?? '', 'customer');
}
auth_start('customer', 'Sign In', ['Sign Up', BASE_URL . '/register.php']);
?>
      <h2 class="au-title">Sign In</h2>
      <p class="au-lead">Welcome back. Log in to track your loans.</p>
      <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="au-field">
          <label for="identifier">CUSTOMER ID, MOBILE OR EMAIL</label>
          <input type="text" id="identifier" name="identifier" placeholder="e.g. FBC000001" required autofocus>
        </div>
        <?php auth_password_field('password', 'PASSWORD', 'Enter your password'); ?>
        <a class="au-forgot" href="#" data-modal="forgot">Forgot password?</a>
        <button class="au-btn" type="submit">Sign In <span>→</span></button>
      </form>
      <p class="au-alt">New to FinBridge? <a href="register.php">Create an account</a></p>
<?php auth_end();
