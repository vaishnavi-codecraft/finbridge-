<?php
require __DIR__ . '/includes/bootstrap.php';
if (current_user()) redirect_to_home();

$error = '';
$old = ['name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $old = [
        'name'  => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
    ];
    $pass  = $_POST['password'] ?? '';
    $pass2 = $_POST['password2'] ?? '';

    if ($old['name'] === '' || strlen($old['name']) > 100) {
        $error = 'Enter your full name.';
    } elseif (!preg_match('/^[0-9]{10}$/', $old['phone'])) {
        $error = 'Enter a 10-digit mobile number.';
    } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif (strlen($pass) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($pass !== $pass2) {
        $error = 'Password and confirmation do not match.';
    } elseif (empty($_POST['terms'])) {
        $error = 'Please accept the Terms and Privacy Policy.';
    } else {
        $chk = $pdo->prepare('SELECT 1 FROM users WHERE email = ? OR phone = ?');
        $chk->execute([$old['email'], $old['phone']]);
        if ($chk->fetchColumn()) {
            $error = 'This email or mobile number is already registered. Please sign in.';
        } else {
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?,?,?,?,?)')
                ->execute([$old['name'], $old['email'], $old['phone'], password_hash($pass, PASSWORD_DEFAULT), 'customer']);
            $uid = (int)$pdo->lastInsertId();
            $pdo->prepare('INSERT INTO customers (user_id) VALUES (?)')->execute([$uid]);
            $cid = (int)$pdo->lastInsertId();
            $pdo->prepare('UPDATE customers SET customer_code = ? WHERE id = ?')->execute([sprintf('FBC%06d', $cid), $cid]);
            $pdo->commit();
            audit($pdo, $uid, 'register', 'user', $uid);

            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $uid, 'name' => $old['name'], 'role' => 'customer', 'branch_id' => null];
            header('Location: ' . BASE_URL . '/welcome.php');
            exit;
        }
    }
}
auth_start('customer', 'Create account', ['Sign In', BASE_URL . '/login.php']);
?>
      <h2 class="au-title">Sign Up</h2>
      <p class="au-lead">Just a few details to create your account.</p>
      <?php if ($error): ?><div class="au-error"><?= e($error) ?></div><?php endif; ?>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="au-field"><label for="name">FULL NAME</label>
          <input type="text" id="name" name="name" value="<?= e($old['name']) ?>" placeholder="Your full name" required autofocus></div>
        <div class="au-field"><label for="phone">MOBILE NUMBER</label>
          <input type="tel" id="phone" name="phone" value="<?= e($old['phone']) ?>" maxlength="10" placeholder="10-digit number" required></div>
        <div class="au-field"><label for="email">EMAIL ADDRESS</label>
          <input type="email" id="email" name="email" value="<?= e($old['email']) ?>" placeholder="name@example.com" required></div>
        <?php auth_password_field('password', 'CREATE PASSWORD', 'Minimum 8 characters'); ?>
        <?php auth_password_field('password2', 'CONFIRM PASSWORD', 'Re-enter password'); ?>
        <label class="au-check"><input type="checkbox" name="terms" value="1"> I agree to the Terms and Privacy Policy.</label>
        <button class="au-btn" type="submit">Create Account <span>→</span></button>
      </form>
      <p class="au-alt">Already a customer? <a href="login.php">Sign in</a></p>
<?php auth_end();
