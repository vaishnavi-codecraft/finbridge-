<?php
// includes/functions.php - helpers: output, auth, CSRF, audit, loans

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function current_user(): ?array { return $_SESSION['user'] ?? null; }

function require_login(): void {
    if (!current_user()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function require_role(array $roles): void {
    if (!current_user()) {
        // send people to the right login page for the area they tried to open
        $to = '/login.php';
        if ($roles === ['admin']) $to = '/admin/login.php';
        elseif (!in_array('customer', $roles, true)) $to = '/staff/login.php';
        header('Location: ' . BASE_URL . $to);
        exit;
    }
    if (!in_array(current_user()['role'], $roles, true)) {
        http_response_code(403);
        exit('Access denied.');
    }
}

function redirect_to_home(): void {
    $role = current_user()['role'] ?? '';
    header('Location: ' . BASE_URL . (ROLE_HOME[$role] ?? '/login.php'));
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400);
        exit('Invalid request.');
    }
}

function audit(PDO $pdo, ?int $userId, string $action, ?string $entity = null, ?int $entityId = null, ?string $details = null): void {
    $pdo->prepare('INSERT INTO audit_logs (user_id, action, entity, entity_id, details, ip_address) VALUES (?,?,?,?,?,?)')
        ->execute([$userId, $action, $entity, $entityId, $details, $_SERVER['REMOTE_ADDR'] ?? null]);
}

function coming_soon(string $stage): void {
    echo '<div class="card"><p>This page will be built in ' . e($stage) . '.</p></div>';
}

// ---------- Loan helpers ----------
// includes/loan_helpers.php - shared loan logic

const STATUS_LABELS = [
    'draft' => 'Draft', 'submitted' => 'Submitted', 'documents_required' => 'Documents Required',
    'under_review' => 'Under Review', 'pending_manager_decision' => 'Pending Manager Decision',
    'approved' => 'Approved', 'rejected' => 'Rejected', 'withdrawn' => 'Withdrawn',
    'agreement_pending' => 'Agreement Pending', 'ready_for_disbursement' => 'Ready for Disbursement',
    'disbursement_failed' => 'Disbursement Failed', 'active' => 'Active Loan', 'closed' => 'Closed',
];

function status_badge(string $s): string {
    return '<span class="badge badge-' . e($s) . '">' . e(STATUS_LABELS[$s] ?? $s) . '</span>';
}

function money($v): string { return '₹' . number_format((float)$v, 2); }

// Reducing-balance EMI: P*r*(1+r)^n / ((1+r)^n - 1)
function calc_emi(float $principal, float $annualRate, int $months): float {
    if ($months <= 0) return 0;
    $r = $annualRate / 12 / 100;
    if ($r == 0) return round($principal / $months, 2);
    $f = pow(1 + $r, $months);
    return round($principal * $r * $f / ($f - 1), 2);
}

function customer_id_for_user(PDO $pdo, int $userId): ?int {
    $s = $pdo->prepare('SELECT id FROM customers WHERE user_id = ?');
    $s->execute([$userId]);
    $id = $s->fetchColumn();
    return $id ? (int)$id : null;
}

// Officer in the branch with the fewest open applications
function pick_officer(PDO $pdo, int $branchId): ?int {
    $s = $pdo->prepare(
        "SELECT u.id FROM users u
         LEFT JOIN loan_applications a ON a.assigned_officer_id = u.id
              AND a.status IN ('submitted','documents_required','under_review')
         WHERE u.role = 'branch_officer' AND u.branch_id = ? AND u.is_active = 1
         GROUP BY u.id ORDER BY COUNT(a.id), u.id LIMIT 1"
    );
    $s->execute([$branchId]);
    $id = $s->fetchColumn();
    return $id ? (int)$id : null;
}

function log_status(PDO $pdo, int $appId, ?string $from, string $to, int $by, ?string $note = null): void {
    $pdo->prepare('INSERT INTO application_history (application_id, from_status, to_status, changed_by, note) VALUES (?,?,?,?,?)')
        ->execute([$appId, $from, $to, $by, $note]);
}

function notify(PDO $pdo, int $userId, ?int $appId, string $message): void {
    $pdo->prepare('INSERT INTO notifications (user_id, application_id, message) VALUES (?,?,?)')
        ->execute([$userId, $appId, mb_substr($message, 0, 250)]);
}

// For these loans the financed amount = price - down payment
function loan_derived(string $code): ?array {
    return ['DURABLE' => ['product_price', 'down_payment'], 'VEHICLE' => ['vehicle_price', 'down_payment']][$code] ?? null;
}


// ---------- Flash messages (shown once) ----------
function set_flash(string $msg): void { $_SESSION['flash'] = $msg; }
function get_flash(): ?string {
    $m = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $m;
}

// Update an application's status, record who did it, and assign the officer if none yet
function change_status(PDO $pdo, array $app, string $to, int $by, ?string $note = null): void {
    $pdo->prepare('UPDATE loan_applications SET status = ?, assigned_officer_id = COALESCE(assigned_officer_id, ?) WHERE id = ?')
        ->execute([$to, $by, $app['id']]);
    log_status($pdo, (int)$app['id'], $app['status'], $to, $by, $note);
}


// Coloured status pill for the customer portal
function cx_pill(string $status): string {
    $groups = [
        'review' => ['submitted', 'under_review', 'pending_manager_decision'],
        'docs'   => ['documents_required'],
        'good'   => ['approved', 'agreement_pending', 'ready_for_disbursement', 'active', 'closed'],
        'bad'    => ['rejected', 'disbursement_failed', 'withdrawn'],
    ];
    $cls = '';
    foreach ($groups as $g => $list) { if (in_array($status, $list, true)) $cls = ' cx-st-' . $g; }
    return '<span class="cx-status' . $cls . '">' . e(STATUS_LABELS[$status] ?? $status) . '</span>';
}


// ---------- Login (used by the customer, staff and admin login pages) ----------
// $kind: 'customer' | 'staff' | 'admin'. Returns an error message, or redirects on success.
function attempt_login(PDO $pdo, string $ident, string $pass, string $kind): string {
    $roles = $kind === 'customer' ? ['customer']
           : ($kind === 'admin' ? ['admin'] : ['branch_officer', 'branch_manager', 'accounts_officer']);

    // Simple brute-force limit: 10 failed attempts per IP in 15 minutes
    $t = $pdo->prepare("SELECT COUNT(*) FROM audit_logs WHERE action = 'login_failed' AND ip_address = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)");
    $t->execute([$_SERVER['REMOTE_ADDR'] ?? '']);
    if ((int)$t->fetchColumn() >= 10) return 'Too many failed attempts. Please try again in 15 minutes.';

    $cols = 'u.id, u.full_name, u.role, u.branch_id, u.password_hash';
    if ($kind === 'customer') {
        if (preg_match('/^FBC[0-9]{6}$/i', $ident)) {            // Customer ID
            $sql = "SELECT $cols FROM users u JOIN customers c ON c.user_id = u.id WHERE c.customer_code = ? AND u.is_active = 1";
            $key = strtoupper($ident);
        } elseif (preg_match('/^[0-9]{10}$/', $ident)) {         // Mobile number
            $sql = "SELECT $cols FROM users u WHERE u.phone = ? AND u.is_active = 1";
            $key = $ident;
        } else {                                                 // Email
            $sql = "SELECT $cols FROM users u WHERE u.email = ? AND u.is_active = 1";
            $key = $ident;
        }
    } else {
        $cols .= ', u.is_active, u.employee_code';
        if (preg_match('/^[A-Za-z]{3}-[A-Za-z0-9-]+$/', $ident)) { // Employee ID
            $sql = "SELECT $cols FROM users u WHERE u.employee_code = ?";
            $key = strtoupper($ident);
        } else {                                                 // Work email
            $sql = "SELECT $cols FROM users u WHERE u.email = ?";
            $key = $ident;
        }
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$key]);
    $user = $stmt->fetch();

    // wrong role gets the same message, so the page never reveals who has an account
    if ($user && in_array($user['role'], $roles, true) && password_verify($pass, $user['password_hash'])) {
        if (isset($user['is_active']) && !(int)$user['is_active']) {
            return $user['employee_code'] === null
                ? 'Your access request is awaiting administrator approval.'
                : 'This account is disabled. Please contact the administrator.';
        }
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'        => (int)$user['id'],
            'name'      => $user['full_name'],
            'role'      => $user['role'],
            'branch_id' => $user['branch_id'] ? (int)$user['branch_id'] : null,
        ];
        audit($pdo, (int)$user['id'], 'login');
        redirect_to_home();
    }
    audit($pdo, null, 'login_failed', 'user', null, substr($ident, 0, 100));
    return 'Invalid login details.';
}


// ---------- Employee IDs ----------
// e.g. OFF-CHN-002 (officer, Chennai, 2nd)
function next_employee_code(PDO $pdo, string $role, ?int $branchId): string {
    $prefix = ['branch_officer' => 'OFF', 'branch_manager' => 'MGR', 'accounts_officer' => 'ACC', 'admin' => 'ADM'][$role] ?? 'EMP';
    $bc = 'HO';
    if ($branchId) {
        $s = $pdo->prepare('SELECT code FROM branches WHERE id = ?');
        $s->execute([$branchId]);
        $bc = (string)($s->fetchColumn() ?: 'HO');
    }
    $s = $pdo->prepare("SELECT MAX(CAST(SUBSTRING_INDEX(employee_code, '-', -1) AS UNSIGNED)) FROM users WHERE employee_code LIKE ?");
    $s->execute(["$prefix-$bc-%"]);
    return sprintf('%s-%s-%03d', $prefix, $bc, (int)$s->fetchColumn() + 1);
}
