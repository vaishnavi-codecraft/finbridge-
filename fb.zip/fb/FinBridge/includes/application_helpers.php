<?php
// includes/application_helpers.php
// Two-part application: field definitions, validation, indicative eligibility,
// automatic branch matching, document checklist and "can this be forwarded?" checks.

const EMPLOYMENT_TYPES = ['salaried' => 'Salaried', 'self_employed' => 'Self-employed / business owner', 'student' => 'Student', 'other' => 'Other'];
const MARITAL_STATUSES = ['single' => 'Single', 'married' => 'Married', 'other' => 'Other'];
const DOC_STATUS_LABELS = ['pending' => 'Uploaded - awaiting check', 'received' => 'Accepted', 'missing' => 'Missing', 'clarification' => 'Re-upload needed'];
const UPLOAD_MAX_BYTES = 5242880;                       // 5 MB
const UPLOAD_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png'];
const WIZARD_STEPS = [1 => 'Personal', 2 => 'Financial', 3 => 'Loan details', 4 => 'Documents', 5 => 'Review & submit'];
const NUMBER_ZERO_OK = ['down_payment', 'existing_emi', 'monthly_income', 'employment_years', 'years_in_business'];
const DOC_UPLOAD_STATUSES = ['draft', 'submitted', 'under_review', 'documents_required'];   // customer may add / replace files
const EXTRA_DOC_SLOTS = 3;

// ---------- Loan-specific fields: [key, label, type, options|null, optional?, asked in Quick Apply?] ----------
function loan_fields(string $code): array {
    $all = [
        'PERSONAL' => [
            ['purpose_type', 'What is the loan for?', 'select', ['medical' => 'Medical expenses', 'wedding' => 'Wedding / family event', 'travel' => 'Travel', 'home_improvement' => 'Home improvement', 'debt' => 'Consolidating other debts', 'other' => 'Other'], false, true],
            ['purpose_details', 'Tell us a little more about the purpose', 'text', null, true, false],
        ],
        'DURABLE' => [
            ['product_name', 'Product (e.g. Refrigerator, TV)', 'text', null, false, true],
            ['product_price', 'Invoice / quotation price (₹)', 'number', null, false, true],
            ['down_payment', 'Down payment (₹)', 'number', null, false, true],
            ['dealer', 'Dealer / shop name', 'text', null, false, false],
            ['quotation_no', 'Invoice / quotation number', 'text', null, true, false],
        ],
        'BUSINESS' => [
            ['business_type', 'Business type', 'select', ['retail' => 'Retail', 'manufacturing' => 'Manufacturing', 'services' => 'Services', 'other' => 'Other'], false, true],
            ['business_purpose', 'Purpose of the loan', 'select', ['working_capital' => 'Working capital', 'equipment' => 'Equipment / machinery', 'expansion' => 'Expansion', 'other' => 'Other'], false, true],
            ['years_in_business', 'Years in business', 'number', null, false, true],
            ['annual_turnover', 'Annual turnover (₹)', 'number', null, false, true],
            ['business_name', 'Business name', 'text', null, false, false],
        ],
        'EDUCATION' => [
            ['course', 'Course', 'text', null, false, true],
            ['course_years', 'Course duration (years)', 'number', null, false, true],
            ['total_fee', 'Total course fee (₹)', 'number', null, false, true],
            ['institution', 'Institution name', 'text', null, false, false],
        ],
        'HOME' => [
            ['property_type', 'Purpose', 'select', ['purchase' => 'Home purchase', 'construction' => 'Construction', 'renovation' => 'Renovation'], false, true],
            ['property_value', 'Property / project value (₹)', 'number', null, false, true],
            ['property_stage', 'Property stage', 'select', ['ready' => 'Ready to move in', 'under_construction' => 'Under construction', 'plot' => 'Plot / land'], false, false],
            ['property_location', 'Property location (address / area)', 'text', null, false, false],
        ],
        'VEHICLE' => [
            ['vehicle_type', 'Vehicle type', 'select', ['two_wheeler' => 'Two-wheeler', 'car' => 'Car', 'commercial' => 'Commercial vehicle'], false, true],
            ['vehicle_condition', 'New or used', 'select', ['new' => 'New', 'used' => 'Used'], false, true],
            ['vehicle_price', 'Vehicle price (₹)', 'number', null, false, true],
            ['down_payment', 'Down payment (₹)', 'number', null, false, true],
            ['vehicle_model', 'Make and model', 'text', null, false, false],
            ['dealer', 'Dealer / seller name', 'text', null, false, false],
        ],
    ];
    return $all[$code] ?? [];
}
function loan_quick_fields(string $code): array { return array_values(array_filter(loan_fields($code), fn($f) => !empty($f[5]))); }
function loan_detail_fields(string $code): array { return array_values(array_filter(loan_fields($code), fn($f) => empty($f[5]))); }

// Asked in Quick Apply for every loan
function quick_common_fields(): array {
    return [
        ['dob', 'Date of birth', 'date', null, false],
        ['employment_type', 'Employment type', 'select', EMPLOYMENT_TYPES, false],
        ['employment_years', 'Years in current job / business', 'number', null, false],
        ['monthly_income', 'Monthly income (₹)', 'number', null, false],
        ['existing_emi', 'Total EMIs you already pay each month (₹, 0 if none)', 'number', null, false],
    ];
}

// Step 1 (personal) and step 2 (financial) of the wizard
function personal_fields(): array {
    return [
        ['dob', 'Date of birth', 'date', null, false],
        ['marital_status', 'Marital status', 'select', MARITAL_STATUSES, true],
        ['address', 'Current address', 'text', null, false],
        ['city', 'City / town', 'text', null, false],
        ['district', 'District', 'text', null, false],
        ['state', 'State', 'text', null, false],
        ['pincode', 'PIN code', 'pin', null, false],
    ];
}
function financial_fields(bool $student): array {
    return [
        ['employment_type', 'Employment type', 'select', EMPLOYMENT_TYPES, false],
        ['employer', $student ? 'Institution / guardian\'s employer (optional)' : 'Employer / business name', 'text', null, $student],
        ['designation', 'Designation / role', 'text', null, true],
        ['employment_years', 'Years in current job / business', 'number', null, false],
        ['monthly_income', 'Monthly income (₹)', 'number', null, false],
        ['existing_emi', 'Existing monthly EMIs (₹, 0 if none)', 'number', null, false],
        ['bank_name', 'Bank name (for disbursement)', 'text', null, false],
        ['account_number', 'Account number', 'account', null, false],
    ];
}

// Validates $src against $defs. Returns cleaned values; messages are appended to $errors.
function parse_fields(array $defs, array $src, array &$errors): array {
    $out = [];
    foreach ($defs as $f) {
        [$k, $label, $type] = $f; $opts = $f[3] ?? null; $optional = !empty($f[4]);
        $v = trim((string)($src[$k] ?? ''));
        if ($v === '') { if (!$optional) $errors[] = "$label is required."; continue; }
        if ($type === 'number') {
            if (!is_numeric($v) || (float)$v < 0 || (float)$v > 1e10 || ((float)$v == 0 && !in_array($k, NUMBER_ZERO_OK, true))) {
                $errors[] = "$label must be a valid number."; continue;
            }
            $v = (float)$v;
        } elseif ($type === 'select') {
            if (!isset($opts[$v])) { $errors[] = "Select a valid option for $label."; continue; }
        } elseif ($type === 'date') {
            $d = DateTime::createFromFormat('!Y-m-d', $v);
            if (!$d || $d->format('Y-m-d') !== $v || $d > new DateTime('today')) { $errors[] = "$label must be a valid date."; continue; }
            if ($k === 'dob') {
                $age = (int)$d->diff(new DateTime('today'))->y;
                if ($age < 18 || $age > 100) { $errors[] = 'You must be at least 18 years old to apply.'; continue; }
            }
        } elseif ($type === 'pin') {
            if (!preg_match('/^[0-9]{6}$/', $v)) { $errors[] = 'PIN code must be 6 digits.'; continue; }
        } elseif ($type === 'account') {
            if (!preg_match('/^[0-9]{9,18}$/', $v)) { $errors[] = 'Account number must be 9 to 18 digits.'; continue; }
        } elseif (mb_strlen($v) > 200) { $errors[] = "$label is too long."; continue; }
        $out[$k] = $v;
    }
    return $out;
}

// key => [label, options|null] for showing stored answers (includes keys used by older applications)
function all_field_labels(string $code): array {
    $m = [];
    foreach (['employer' => 'Employer / business name', 'designation' => 'Designation', 'marital_status' => 'Marital status', 'permanent_address' => 'Permanent address',
              'bank_name' => 'Bank name', 'account_number' => 'Account number', 'existing_emi' => 'Existing monthly EMIs (₹)',
              'employment_years' => 'Years in current job / business', 'monthly_income' => 'Monthly income (₹)', 'dob' => 'Date of birth',
              'address' => 'Current address', 'city' => 'City / town', 'district' => 'District', 'state' => 'State', 'pincode' => 'PIN code',
              'employment_type' => 'Employment type', 'full_name' => 'Name', 'phone' => 'Mobile', 'email' => 'Email'] as $k => $l) $m[$k] = [$l, null];
    $m['employment_type'][1] = EMPLOYMENT_TYPES;
    $m['marital_status'][1] = MARITAL_STATUSES;
    foreach (loan_fields($code) as $f) $m[$f[0]] = [$f[1], $f[3] ?? null];
    return $m;
}
function show_value(array $labels, string $k, $v): string {
    $opts = $labels[$k][1] ?? null;
    if ($opts && isset($opts[$v])) return (string)$opts[$v];
    if (is_numeric($v) && preg_match('/(income|price|value|fee|turnover|payment|emi|amount)/', $k)) return money($v);
    return (string)$v;
}

// ---------- Indicative eligibility (demo rules, NOT a decision) ----------
function elig_rules(string $code): array {
    // min_age, max_age, min_income, max_emi_ratio %, min_experience years
    return [
        'PERSONAL'  => [21, 60, 15000, 50, 1],
        'DURABLE'   => [21, 60, 12000, 50, 0.5],
        'BUSINESS'  => [23, 65, 20000, 55, 1],
        'EDUCATION' => [18, 65, 0, 50, 0],
        'HOME'      => [21, 65, 25000, 55, 1],
        'VEHICLE'  => [21, 65, 20000, 50, 1],
    ][$code] ?? [21, 60, 15000, 50, 1];
}
const ELIG_LABELS = ['may_meet' => 'May meet initial criteria', 'more_info' => 'More information required', 'not_met' => 'Does not meet the current demo criteria'];

function compute_eligibility(array $product, array $ap, float $amount, int $tenure): array {
    [$minAge, $maxAge, $minInc, $maxRatio, $minExp] = elig_rules($product['code']);
    $hard = []; $soft = [];
    $student = ($ap['employment_type'] ?? '') === 'student' || $product['code'] === 'EDUCATION';

    $age = null;
    if (!empty($ap['dob']) && ($d = DateTime::createFromFormat('!Y-m-d', $ap['dob']))) $age = (int)$d->diff(new DateTime('today'))->y;
    if ($age === null) $soft[] = 'Date of birth is needed.';
    else {
        if ($age < $minAge || $age > $maxAge) $hard[] = "Age must be between $minAge and $maxAge for this loan.";
        elseif ($age + $tenure / 12 > 70) $hard[] = 'Your age at the end of the loan would be above 70. Try a shorter tenure.';
    }
    $income = isset($ap['monthly_income']) ? (float)$ap['monthly_income'] : null;
    if (!$student) {
        if ($income === null) $soft[] = 'Monthly income is needed.';
        else {
            if ($income < $minInc) $hard[] = 'Monthly income is below the demo minimum of ' . money($minInc) . '.';
            if ($income > 0) {
                $ratio = (((float)($ap['existing_emi'] ?? 0)) + calc_emi($amount, (float)$product['interest_rate'], $tenure)) / $income * 100;
                if ($ratio > $maxRatio) $hard[] = 'Total EMIs would be about ' . round($ratio) . "% of income (demo limit $maxRatio%). Try a smaller amount or longer tenure.";
            }
        }
        if (isset($ap['employment_years']) && (float)$ap['employment_years'] < $minExp) {
            $soft[] = 'This loan usually needs at least ' . $minExp . ' year(s) in the current job or business.';
        }
    }
    $code = $hard ? 'not_met' : ($soft ? 'more_info' : 'may_meet');
    return ['code' => $code, 'label' => ELIG_LABELS[$code], 'reasons' => array_merge($hard, $soft)];
}

// ---------- Branch matching: PIN code -> district -> city -> state -> default branch ----------
function match_branch(PDO $pdo, string $pin, string $district = '', string $city = '', string $state = ''): ?int {
    $q = function (string $sql, array $p) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($p); $v = $s->fetchColumn(); return $v ? (int)$v : null; };
    if ($pin !== '' && ($b = $q('SELECT b.id FROM branch_pincodes bp JOIN branches b ON b.id = bp.branch_id WHERE bp.pincode = ? AND b.is_active = 1', [$pin]))) return $b;
    if ($district !== '' && ($b = $q('SELECT id FROM branches WHERE is_active = 1 AND LOWER(district) = LOWER(?) ORDER BY is_default DESC, id LIMIT 1', [$district]))) return $b;
    if ($city !== '' && ($b = $q('SELECT id FROM branches WHERE is_active = 1 AND (LOWER(city) = LOWER(?) OR LOWER(district) = LOWER(?)) ORDER BY is_default DESC, id LIMIT 1', [$city, $city]))) return $b;
    if ($state !== '' && ($b = $q('SELECT id FROM branches WHERE is_active = 1 AND LOWER(state) = LOWER(?) ORDER BY is_default DESC, id LIMIT 1', [$state]))) return $b;
    return $q('SELECT id FROM branches WHERE is_active = 1 ORDER BY is_default DESC, id LIMIT 1', []);
}

// ---------- Document checklist: key => [label, required?] ----------
function doc_requirements(string $code, array $ap = []): array {
    $self = ($ap['employment_type'] ?? '') === 'self_employed';
    $income = $self ? 'Income proof (ITR / business income proof)' : 'Income proof (salary slips / income statement)';
    $d = ['id_proof' => ['Identity proof', true], 'address_proof' => ['Address proof', true]];
    switch ($code) {
        case 'PERSONAL':  $d += ['income_proof' => [$income, true], 'bank_statement' => ['Bank statement (last 6 months)', false]]; break;
        case 'DURABLE':   $d += ['income_proof' => [$income, true], 'quotation' => ['Invoice / quotation for the product', true]]; break;
        case 'BUSINESS':  $d += ['business_proof' => ['Business registration / GST proof', true], 'income_proof' => ['Income proof (ITR / financials)', true], 'bank_statement' => ['Bank statement (last 6 months)', true]]; break;
        case 'EDUCATION': $d += ['admission_letter' => ['Admission letter', true], 'fee_structure' => ['Fee structure', true], 'income_proof' => ['Income proof (applicant / co-applicant)', true]]; break;
        case 'HOME':      $d += ['income_proof' => [$income, true], 'bank_statement' => ['Bank statement (last 6 months)', true], 'property_docs' => ['Property documents / sale agreement', true]]; break;
        case 'VEHICLE':   $d += ['income_proof' => [$income, true], 'quotation' => ['Vehicle quotation / proforma invoice', true]]; break;
    }
    return $d;
}
function doc_label(string $key, array $reqs): string {
    if (isset($reqs[$key])) return $reqs[$key][0];
    if (preg_match('/^extra_([0-9]+)$/', $key, $m)) return 'Additional document ' . $m[1];
    return '';   // unknown key
}
function app_applicant(array $app): array { return json_decode($app['applicant_json'] ?? '{}', true) ?: []; }

// Labels of required checklist documents that have not been uploaded yet
function missing_required_documents(PDO $pdo, array $app): array {
    $code = $app['product_code'] ?? '';
    if ($code === '') { $s = $pdo->prepare('SELECT code FROM loan_products WHERE id = ?'); $s->execute([$app['product_id']]); $code = (string)$s->fetchColumn(); }
    $have = $pdo->prepare('SELECT doc_key FROM application_documents WHERE application_id = ?');
    $have->execute([$app['id']]);
    $have = $have->fetchAll(PDO::FETCH_COLUMN);
    $miss = [];
    foreach (doc_requirements($code, app_applicant($app)) as $k => [$label, $req]) {
        if ($req && !in_array($k, $have, true)) $miss[] = preg_replace('/\s*\(.*?\)\s*$/u', '', $label);
    }
    return $miss;
}

// Why can't this application be forwarded to the manager yet? ('' = it can)
function forward_blockers(PDO $pdo, array $a): string {
    if (!empty($a['applicant_json'])) {                       // two-part applications only (older ones have no checklist)
        $miss = missing_required_documents($pdo, $a);
        if ($miss) return 'Required documents are still missing: ' . implode(', ', $miss) . '. Request them from the customer first.';
        $c = $pdo->prepare("SELECT COUNT(*) FROM application_documents WHERE application_id = ? AND review_status = 'clarification'");
        $c->execute([$a['id']]);
        if ((int)$c->fetchColumn() > 0) return 'Some documents are marked "Re-upload needed". Wait for the customer to replace them.';
    }
    if (($a['product_code'] ?? '') === 'HOME') {
        $v = $pdo->prepare("SELECT COUNT(*) FROM field_verifications WHERE application_id = ? AND method = 'visit' AND outcome <> 'unable'");
        $v->execute([$a['id']]);
        if ((int)$v->fetchColumn() === 0) return 'A home loan needs a recorded in-person visit (field verification) before it can be forwarded.';
    }
    return '';
}

// Can the customer open / change documents of this application?
function can_upload_docs(array $app): bool { return in_array($app['status'], DOC_UPLOAD_STATUSES, true); }

// Who may open an application's files / pages (staff)
function staff_can_see_application(array $user, array $app): bool {
    if ($app['status'] === 'draft') return false;
    if ($user['role'] === 'branch_manager') return (int)$app['branch_id'] === (int)$user['branch_id'];
    if ($user['role'] === 'branch_officer') {
        return (int)$app['assigned_officer_id'] === (int)$user['id']
            || (empty($app['assigned_officer_id']) && (int)$app['branch_id'] === (int)$user['branch_id']);
    }
    return false;
}

// Prints one labelled form control for a field definition
function render_field(array $f, $value = '', bool $readonly = false): void {
    [$k, $label, $type] = $f; $opts = $f[3] ?? null; $optional = !empty($f[4]);
    $req = $optional ? '' : ' required'; $ro = $readonly ? ' readonly' : '';
    $v = e($value);
    echo '<div><label for="' . e($k) . '">' . e($label) . '</label>';
    if ($type === 'select') {
        echo '<select id="' . e($k) . '" name="' . e($k) . '"' . $req . '><option value="">Select</option>';
        foreach ($opts as $ov => $ol) echo '<option value="' . e($ov) . '"' . ((string)$value === (string)$ov ? ' selected' : '') . '>' . e($ol) . '</option>';
        echo '</select>';
    } elseif ($type === 'number') {
        echo '<input type="number" step="any" min="0" id="' . e($k) . '" name="' . e($k) . '" value="' . $v . '"' . $req . $ro . '>';
    } elseif ($type === 'date') {
        echo '<input type="date" id="' . e($k) . '" name="' . e($k) . '" max="' . date('Y-m-d') . '" value="' . $v . '"' . $req . '>';
    } elseif ($type === 'pin') {
        echo '<input type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" id="' . e($k) . '" name="' . e($k) . '" value="' . $v . '"' . $req . '>';
    } elseif ($type === 'account') {
        echo '<input type="text" inputmode="numeric" pattern="[0-9]{9,18}" maxlength="18" id="' . e($k) . '" name="' . e($k) . '" value="' . $v . '"' . $req . '>';
    } else {
        echo '<input type="text" id="' . e($k) . '" name="' . e($k) . '" maxlength="200" value="' . $v . '"' . $req . '>';
    }
    echo '</div>';
}

// The coloured eligibility box
function render_eligibility(?string $code, array $reasons = []): void {
    if (!$code || !isset(ELIG_LABELS[$code])) return;
    echo '<div class="elig elig-' . e($code) . '"><strong>' . e(ELIG_LABELS[$code]) . '</strong>';
    if ($reasons) { echo '<ul>'; foreach ($reasons as $r) echo '<li>' . e($r) . '</li>'; echo '</ul>'; }
    echo '<div class="muted" style="margin-top:6px">This is only an indicative check using demo rules. It is not an approval or a rejection.</div></div>';
}

// ---------- Document storage / checklist UI ----------
function doc_storage_dir(): string { return __DIR__ . '/../storage/documents'; }
function doc_file_path(string $stored): string { return doc_storage_dir() . '/' . basename($stored); }

// One checklist row with its upload form. $back = 'wizard' | 'documents'
function render_doc_slot(array $app, string $key, string $label, bool $required, ?array $doc, string $back, bool $canUpload): void {
    $st = $doc['review_status'] ?? null;
    $locked = $doc && $st === 'received';
    echo '<div class="doc-row"><div class="doc-info"><strong>' . e($label) . '</strong> '
       . ($required ? '<span class="badge badge-documents_required">Required</span>' : '<span class="badge">Optional</span>');
    if ($doc) {
        echo '<div class="doc-file"><a href="' . BASE_URL . '/download_document.php?id=' . (int)$doc['id'] . '" target="_blank" rel="noopener">' . e($doc['original_name']) . '</a> '
           . '<span class="badge ' . ($st === 'received' ? 'badge-approved' : ($st === 'clarification' ? 'badge-rejected' : 'badge-submitted')) . '">' . e(DOC_STATUS_LABELS[$st] ?? $st) . '</span></div>';
        if (!empty($doc['review_note']) && $st === 'clarification') echo '<div class="doc-note">Branch note: ' . e($doc['review_note']) . '</div>';
    } else {
        echo '<div class="doc-file muted">Not uploaded yet</div>';
    }
    echo '</div>';
    if ($canUpload && !$locked) {
        echo '<form class="doc-form" method="post" enctype="multipart/form-data" action="' . BASE_URL . '/customer/upload_document.php">'
           . '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '"><input type="hidden" name="app" value="' . (int)$app['id'] . '">'
           . '<input type="hidden" name="doc_key" value="' . e($key) . '"><input type="hidden" name="back" value="' . e($back) . '">'
           . '<input type="file" name="file" accept=".pdf,.jpg,.jpeg,.png" required>'
           . '<button class="btn-sm" type="submit">' . ($doc ? 'Replace' : 'Upload') . '</button><span class="doc-msg muted"></span></form>';
    }
    echo '</div>';
}
