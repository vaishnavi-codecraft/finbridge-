<?php
// includes/footer.php - page_footer() closes the page
function page_footer(): void {
    if (!empty($GLOBALS['cx_layout'])) { customer_layout_footer(); return; }
    echo '</main></body></html>';
}


// closes the customer portal layout
function customer_layout_footer(): void {
    ?>
      <footer class="cx-footer">© <?= date('Y') ?> <?= APP_NAME ?>. Demo interface for project development.<br>Loan approval and disbursement are not guaranteed.</footer>
    </div>
  </main>
</div>
<div class="cx-toast" id="cxToast" role="status" aria-live="polite" hidden></div>
<script>
(function () {
  var toast = document.getElementById('cxToast'), t;
  document.querySelectorAll('[data-message]').forEach(function (el) {
    el.addEventListener('click', function (ev) {
      ev.preventDefault();
      toast.textContent = el.dataset.message; toast.hidden = false;
      clearTimeout(t); t = setTimeout(function () { toast.hidden = true; }, 3500);
    });
  });
  var sb = document.getElementById('cxSidebar'), ov = document.getElementById('cxOverlay');
  function close() { sb.classList.remove('open'); ov.classList.remove('show'); }
  document.getElementById('cxMenuBtn').addEventListener('click', function () {
    sb.classList.add('open'); ov.classList.add('show');
  });
  ov.addEventListener('click', close);
})();
</script>
</body></html>
<?php
}
