<?php
// Serves an uploaded document after checking who is asking.
// Customer: only their own files. Branch officer: assigned to them / unassigned in their branch. Branch manager: their branch.
require __DIR__ . '/includes/bootstrap.php';
require_login();

$u  = current_user();
$id = (int)($_GET['id'] ?? 0);
$s = $pdo->prepare('SELECT d.*, a.customer_id, a.status, a.branch_id, a.assigned_officer_id
                    FROM application_documents d JOIN loan_applications a ON a.id = d.application_id WHERE d.id = ?');
$s->execute([$id]);
$d = $s->fetch();
if (!$d) { http_response_code(404); exit('File not found.'); }

$allowed = false;
if ($u['role'] === 'customer') {
    $allowed = customer_id_for_user($pdo, $u['id']) === (int)$d['customer_id'];
} else {
    $allowed = staff_can_see_application($u, $d);
}
if (!$allowed) { http_response_code(403); exit('Access denied.'); }

$path = doc_file_path($d['file_path']);
if (!is_file($path)) { http_response_code(404); exit('File not found.'); }

$mimes = ['application/pdf', 'image/jpeg', 'image/png'];
$mime = in_array($d['mime_type'], $mimes, true) ? $d['mime_type'] : 'application/octet-stream';
$name = preg_replace('/[^A-Za-z0-9._-]+/', '_', $d['original_name']) ?: 'document';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="' . $name . '"');
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:");
header('Cache-Control: private, no-store');
readfile($path);
